//----------------------------------------------------------------------------------
// File:   Cloth.cpp
// Author: Cyril Zeller
// Email:  sdkfeedback@nvidia.com
// 
// Copyright (c) 2007 NVIDIA Corporation. All rights reserved.
//
// TO  THE MAXIMUM  EXTENT PERMITTED  BY APPLICABLE  LAW, THIS SOFTWARE  IS PROVIDED
// *AS IS*  AND NVIDIA AND  ITS SUPPLIERS DISCLAIM  ALL WARRANTIES,  EITHER  EXPRESS
// OR IMPLIED, INCLUDING, BUT NOT LIMITED  TO, IMPLIED WARRANTIES OF MERCHANTABILITY
// AND FITNESS FOR A PARTICULAR PURPOSE.  IN NO EVENT SHALL  NVIDIA OR ITS SUPPLIERS
// BE  LIABLE  FOR  ANY  SPECIAL,  INCIDENTAL,  INDIRECT,  OR  CONSEQUENTIAL DAMAGES
// WHATSOEVER (INCLUDING, WITHOUT LIMITATION,  DAMAGES FOR LOSS OF BUSINESS PROFITS,
// BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION, OR ANY OTHER PECUNIARY LOSS)
// ARISING OUT OF THE  USE OF OR INABILITY  TO USE THIS SOFTWARE, EVEN IF NVIDIA HAS
// BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
//
//
//----------------------------------------------------------------------------------
// Modified by Sergey Gasanov (sgiman) @ 2013, september
// Sgiman Creative Studio (sgiman.com)
//----------------------------------------------------------------------------------

#include "DXUT.h"
#include "DXUTcamera.h"
#include "DXUTgui.h"
#include "DXUTsettingsdlg.h"
#include "DXUTShapes.h"
#include "SDKmesh.h"
#include "SDKmisc.h"
#include "resource.h"
#include "NVUTMedia.h"
#include "Cloth.h"
#include <stddef.h>

//--------------------------------------------------------------------------------------
// UI control IDs
//--------------------------------------------------------------------------------------
enum {
    IDC_TOGGLEFULLSCREEN,
    IDC_TOGGLEREF,
    IDC_CHANGEDEVICE,
    IDC_RUN_PAUSE_SIMULATION,
    IDC_STEP_SIMULATION,
    IDC_NUM_SIM_PASSES_LABEL,
    IDC_NUM_SIM_PASSES,
    IDC_WIND_HEADING_LABEL,
    IDC_WIND_HEADING,
    IDC_WIND_STRENGTH_LABEL,
    IDC_WIND_STRENGTH,
    IDC_UNCUT,
    IDC_RESET_SIMULATION,
    IDC_SHOW_TANGENT_SPACE,
    IDC_WIREFRAME,
};

//--------------------------------------------------------------------------------------
// Global variables
//--------------------------------------------------------------------------------------
CModelViewerCamera         g_Camera;                // A model viewing camera
CDXUTDialogResourceManager g_DialogResourceManager; // manager for shared resources of dialogs
CD3DSettingsDlg            g_SettingsDlg;           // Device settings dialog
CDXUTDialog                g_HUD;                   // manages the 3D UI
CDXUTDialog                g_SampleUI;              // dialog for sample specific controls
ID3DX10Font*               g_Font;       
ID3DX10Sprite*             g_Sprite;
ID3D10Effect*              g_Effect;
CDXUTTextHelper*           g_TxtHelper;

// Cloth size
const int g_Width = 31;
const int g_Height = 31;
int g_NumVertices = g_Width * g_Height;
const float g_TexCoordScale = 4;

// Position indices
int g_Old = 0;
int g_Current = 1;
int g_New = 2;

// Simulation
enum {
    PASS_SIMULATE_FORCE,
    PASS_SIMULATE_STRUCTURAL_AND_SHEAR_SPRING_0,
    PASS_SIMULATE_STRUCTURAL_AND_SHEAR_SPRING_1,
    PASS_SIMULATE_SHEAR_SPRING_0,
    PASS_SIMULATE_SHEAR_SPRING_1,
    PASS_SIMULATE_COLLISION
};
int g_NumSimPasses = 3;
int g_NumPrimitivesPerBatch = 4;
int g_LastPrimitiveIndex = g_NumVertices / g_NumPrimitivesPerBatch;
int g_LastPrimitiveSize = g_NumVertices % g_NumPrimitivesPerBatch;
int g_NumSimIndices = g_NumPrimitivesPerBatch * (g_LastPrimitiveIndex + (g_LastPrimitiveSize == 0 ? 0 : 1));
#define NUM_SIMULATE_IB (PASS_SIMULATE_COLLISION + 1)
int g_NumSimulatedPrimitives[NUM_SIMULATE_IB];
int g_WindHeading;
int g_WindStrength;
int g_NumCutterTriangles;
int g_FirstCutterTriangle;

// Rendering
int g_NumIndices;

// Vertex buffers
ID3D10Buffer* g_InitialPositionVB;
ID3D10Buffer* g_TexCoordVB;
ID3D10Buffer* g_AnchorVB;
ID3D10Buffer* g_ParticleVB[3];
ID3D10Buffer* g_NormalTangentVB;
ID3D10Buffer* g_CutterEdgeVB;

// Constant buffers
ID3D10Buffer* g_CutterEdgeCB;

// Index buffers
ID3D10Buffer* g_SimulateIB[NUM_SIMULATE_IB];
ID3D10Buffer* g_NormalTangentIB;
ID3D10Buffer* g_RenderIB;

// Vertex layouts
ID3D10InputLayout* g_ApplyForcesIL;
ID3D10InputLayout* g_SatisfyConstraintsIL;
ID3D10InputLayout* g_RenderTangentSpaceIL;
ID3D10InputLayout* g_AnchorIL;
ID3D10InputLayout* g_RenderClothIL;
ID3D10InputLayout* g_RenderMeshIL;

// Render target view
ID3D10RenderTargetView* g_ParticleRTV[3];
ID3D10RenderTargetView* g_CutterEdgeRTV;

// Shader resource view
ID3D10ShaderResourceView* g_ParticleSRV[3];

// Render state
ID3D10RasterizerState* g_WireframeRS;
ID3D10RasterizerState* g_SolidRS;

// Anchor points
D3DXVECTOR2 g_AnchorPoint[] = {
    D3DXVECTOR2(0, 0),
    D3DXVECTOR2(g_Width / 2, 0),
    D3DXVECTOR2(g_Width - 1, 0)
};
int g_NumAnchorPoints = sizeof(g_AnchorPoint) / sizeof(g_AnchorPoint[0]);
D3DXVECTOR3 g_Center;
bool g_TransformAnchorPoints;
D3DXMATRIX g_Transform;

// Transforms
D3DXMATRIX g_Projection;
D3DXMATRIX g_View;
D3DXMATRIX g_ViewProjection;
D3DXVECTOR3 g_Eye;

// Scene
Plane g_Plane[] = {
    { D3DXVECTOR3(0, 1, 0), 3 },
    { D3DXVECTOR3(0, -1, 0), 6 },
    { D3DXVECTOR3(1, 0, 0), 7 },
    { D3DXVECTOR3(-1, 0, 0), 7 },
    { D3DXVECTOR3(0, 0, 1), 7 },
    { D3DXVECTOR3(0, 0, -1), 7 }
};
const int g_NumPlanes = sizeof(g_Plane) / sizeof(g_Plane[0]);
D3DXMATRIX g_PlaneWorld[g_NumPlanes];
ID3D10ShaderResourceView* g_PlaneDiffuseTexture[g_NumPlanes];
ID3D10ShaderResourceView* g_PlaneNormalMap[g_NumPlanes];
ID3DX10Mesh* g_PlaneMesh;

Sphere g_Sphere[] = {
    { D3DXVECTOR3(0, 0, 0), 0.4f },
};
const int g_NumSpheres = sizeof(g_Sphere) / sizeof(g_Sphere[0]);
D3DXMATRIX g_SphereWorld[g_NumSpheres];
ID3DX10Mesh* g_SphereMesh;

Capsule g_Capsule[] = {
    { D3DXVECTOR3(-0.8f, -0.3f, 0), 0.5, D3DXVECTOR4(0, 1, 0, 0), D3DXVECTOR4(0.3f, 0.2f, 0, 0) },
};
const int g_NumCapsules = sizeof(g_Capsule) / sizeof(g_Capsule[0]);
D3DXMATRIX g_CapsuleWorld[g_NumCapsules];
ID3DX10Mesh* g_CapsuleMesh[g_NumCapsules];

Ellipsoid g_Ellipsoid[] = {
    { D3DXVECTOR4(0.8f, 0, 0, 0), D3DXVECTOR4(0.35f, 0.5f, 0.25f, 0) },
};
const int g_NumEllipsoids = sizeof(g_Ellipsoid) / sizeof(g_Ellipsoid[0]);
D3DXMATRIX g_EllipsoidWorld[g_NumEllipsoids];

// Textures
ID3D10ShaderResourceView* g_CellDiffuseTexture[3];
ID3D10ShaderResourceView* g_CellNormalMap[3];
ID3D10ShaderResourceView* g_ClothDiffuseTexture;
ID3D10ShaderResourceView* g_ClothNormalMap;

// Commands
bool g_Help = true;
bool g_Reset;
bool g_Run = true;
int  g_StepSimulation;
bool g_Uncut;
bool g_Wireframe;
bool g_ShowTangentSpace;
bool g_ShiftDown;
bool g_CtrlDown;

// Backbuffer attributes
ID3D10RenderTargetView*    g_BackBufferRTV;
ID3D10DepthStencilView*    g_BackBufferDSV;
D3D10_VIEWPORT             g_BackBufferVP;
int                        g_BackBufferWidth;
int                        g_BackBufferHeight;

//--------------------------------------------------------------------------------------
// Forward declarations 
//--------------------------------------------------------------------------------------
bool    CALLBACK ModifyDeviceSettings(DXUTDeviceSettings* pDeviceSettings, void* pUserContext);
void    CALLBACK OnFrameMove(double time_d, float elapsedTime, void* pUserContext);
LRESULT CALLBACK MsgProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam, bool* pbNoFurtherProcessing, void* pUserContext);
void    CALLBACK OnKeyboard(UINT nChar, bool bKeyDown, bool bAltDown, void* pUserContext);
void    CALLBACK OnGUIEvent(UINT nEvent, int nControlID, CDXUTControl* pControl, void* pUserContext);

bool    CALLBACK IsD3D10DeviceAcceptable(UINT Adapter, UINT Output, D3D10_DRIVER_TYPE DeviceType, DXGI_FORMAT BackBufferFormat, bool bWindowed, void* pUserContext);
HRESULT CALLBACK OnD3D10CreateDevice(ID3D10Device* pd3dDevice, const DXGI_SURFACE_DESC* pBackBufferSurfaceDesc, void* pUserContext);
HRESULT CALLBACK OnD3D10ResizedSwapChain(ID3D10Device* pd3dDevice, IDXGISwapChain *pSwapChain, const DXGI_SURFACE_DESC* pBackBufferSurfaceDesc, void* pUserContext);
void    CALLBACK OnD3D10FrameRender(ID3D10Device* pd3dDevice, double time_d, float elapsedTime, void* pUserContext);
void    CALLBACK OnD3D10SwapChainReleasing(void* pUserContext);
void    CALLBACK OnD3D10DestroyDevice(void* pUserContext);

void    InitApp();
void    SimulateCloth(ID3D10Device*, float, float);
void    ComputeNormalTangent(ID3D10Device*);
void    RenderScene(ID3D10Device*, D3DXMATRIX&, D3DXMATRIX* = 0);
void    SetRenderState(D3DXMATRIX&, ID3D10ShaderResourceView*, ID3D10ShaderResourceView*, const D3DXMATRIX&, const D3DXMATRIX*);
void    SetMatrices(D3DXMATRIX&, const D3DXMATRIX&, const D3DXMATRIX*);
void    SetMaterial(bool);
void    ComputeThinningMatrix(D3DXMATRIX&, float, D3DXMATRIX&);
void    RenderTangentSpace(ID3D10Device*);
void    RenderText();

void    RenderPosition(ID3D10Device*, ID3D10RenderTargetView*, int, int, int, D3DXMATRIX*);
D3DXMATRIX GetPixelTargetTransform(int, int);
void    WorldToScreen(const D3DXVECTOR3&, float&, float&);
D3DXVECTOR3 ScreenToTrackballPoint(float, float);
void    MoveCloth(HWND, int, WPARAM, LPARAM);
bool    CutCloth(ID3D10Device*, HWND = 0, int = 0, LPARAM = 0);
void    RenderCutterEdge(ID3D10Device*, int, int, int, int);

void    InitializePositions(Particle*);

HRESULT CreateIndexBuffers(ID3D10Device*, Particle*);
HRESULT CreateSimulationIB(ID3D10Device*, Particle*);
HRESULT CreateTangentSpaceIB(ID3D10Device*);
HRESULT CreateRenderingIB(ID3D10Device*);

HRESULT CreateVertexBuffers(ID3D10Device*, Particle*);
HRESULT CreatePositionVB(ID3D10Device*, Particle*);
HRESULT CreateTexCoordVB(ID3D10Device*);
HRESULT CreateParticleVB(ID3D10Device*);
HRESULT CreateTangentSpaceVB(ID3D10Device*);
HRESULT CreateCutterEdgeVB(ID3D10Device*);
HRESULT CreateAnchorVB(ID3D10Device*);

HRESULT CreateInputLayouts(ID3D10Device*);
HRESULT CreateApplyForcesIL(ID3D10Device*);
HRESULT CreateSatisfyConstraintsIL(ID3D10Device*);
HRESULT CreateRenderClothIL(ID3D10Device*);
HRESULT CreateRenderTangentSpaceIL(ID3D10Device*);

HRESULT CreateTextures(ID3D10Device*);

HRESULT CreateRasterizerStates(ID3D10Device*);

void    InitPlanes();
HRESULT CreatePlaneMesh(ID3D10Device*);
void    InitSpheres();
HRESULT CreateSphereMesh(ID3D10Device*);
void    InitCapsules();
HRESULT CreateCapsuleMeshes(ID3D10Device*);
void    InitEllipsoids();
HRESULT CreateCapsuleMesh(ID3D10Device*, float, float[2], WORD, WORD, ID3DX10Mesh**);
HRESULT CreateShapeMesh(ID3D10Device*, ID3DX10Mesh**, MeshVertex* vertices, UINT, WORD*, UINT);

//--------------------------------------------------------------------------------------
// Entry point to the program. Initializes everything and goes into a message processing 
// loop. Idle time is used to render the scene.
//--------------------------------------------------------------------------------------
int WINAPI wWinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPWSTR lpCmdLine, int nCmdShow)
{
    // Enable run-time memory check for debug builds.
#if defined(DEBUG) | defined(_DEBUG)
    _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
#endif

    // DXUT will create and use the best device (either D3D9 or D3D10) 
    // that is available on the system depending on which D3D callbacks are set below

    // Set DXUT callbacks
    DXUTSetCallbackDeviceChanging(ModifyDeviceSettings);
    DXUTSetCallbackMsgProc(MsgProc);
    DXUTSetCallbackKeyboard(OnKeyboard);
    DXUTSetCallbackFrameMove(OnFrameMove);
    DXUTSetCallbackD3D10DeviceAcceptable(IsD3D10DeviceAcceptable);
    DXUTSetCallbackD3D10DeviceCreated(OnD3D10CreateDevice);
    DXUTSetCallbackD3D10SwapChainResized(OnD3D10ResizedSwapChain);
    DXUTSetCallbackD3D10FrameRender(OnD3D10FrameRender);
    DXUTSetCallbackD3D10SwapChainReleasing(OnD3D10SwapChainReleasing);
    DXUTSetCallbackD3D10DeviceDestroyed(OnD3D10DestroyDevice);

    InitApp();
    DXUTInit(true, true, NULL); // Parse the command line, show msgboxes on error, no extra command line params
    DXUTSetCursorSettings(true, true); // Show the cursor and clip it when in full screen
    DXUTCreateWindow(L"Cloth");
    DXUTCreateDevice(true, 1024, 768); // ******** SCREEN SIZE ********
    DXUTMainLoop(); // Enter into the DXUT render loop

    return DXUTGetExitCode();
}

//--------------------------------------------------------------------------------------
// Initialize the app 
//--------------------------------------------------------------------------------------
void InitApp()
{
    g_SettingsDlg.Init(&g_DialogResourceManager);
    g_HUD.Init(&g_DialogResourceManager);
    g_SampleUI.Init(&g_DialogResourceManager);

    g_HUD.SetCallback(OnGUIEvent);
    int iY = 10; 
    int width = 150;
    int height = 22;
    g_HUD.AddButton(IDC_TOGGLEFULLSCREEN, L"Toggle full screen", 0, iY, width, height);
    g_HUD.AddButton(IDC_TOGGLEREF, L"Toggle REF (F3)", 0, iY += 24, width, height, VK_F3);
    g_HUD.AddButton(IDC_CHANGEDEVICE, L"Change device (F2)", 0, iY += 24, width, height, VK_F2);
    
    WCHAR label[MAX_PATH];
    g_SampleUI.SetCallback(OnGUIEvent);
    iY = 10;
    int sliderOffset = 15;
    int sliderWidth = 130;
    g_SampleUI.AddButton(IDC_RESET_SIMULATION, L"Reset (0)", 0, iY, width, height);
    g_SampleUI.AddButton(IDC_RUN_PAUSE_SIMULATION, L"Run/Pause (Space)", 0, iY += 24, width, height);
    g_SampleUI.AddButton(IDC_STEP_SIMULATION, L"Step (S)", 0, iY += 24, width, height);
    StringCchPrintf(label, MAX_PATH, L"Simulation passes: %d", g_NumSimPasses);
    g_SampleUI.AddStatic(IDC_NUM_SIM_PASSES_LABEL, label, 0, iY += 24, width, height);
    g_SampleUI.AddSlider(IDC_NUM_SIM_PASSES, sliderOffset, iY += 24, sliderWidth, height, 1, 10, g_NumSimPasses);
    StringCchPrintf(label, MAX_PATH, L"Wind heading: %d", g_WindHeading);
    g_SampleUI.AddStatic(IDC_WIND_HEADING_LABEL, label, 0, iY += 24, width, height);
    g_SampleUI.AddSlider(IDC_WIND_HEADING, sliderOffset, iY += 24, sliderWidth, height, 1, 360, g_WindHeading);
    StringCchPrintf(label, MAX_PATH, L"Wind strength: %d", g_WindStrength);
    g_SampleUI.AddStatic(IDC_WIND_STRENGTH_LABEL, label, 0, iY += 24, width, height);
    g_SampleUI.AddSlider(IDC_WIND_STRENGTH, sliderOffset, iY += 24, sliderWidth, height, 0, 60, g_WindStrength);
    g_SampleUI.AddButton(IDC_UNCUT, L"Uncut (Z)", 0, iY += 24, width, height);
    g_SampleUI.AddButton(IDC_SHOW_TANGENT_SPACE, L"Show/Hide tangent space", 0, iY += 24, width, height);
    g_SampleUI.AddButton(IDC_WIREFRAME, L"Solid/Wireframe (W)", 0, iY += 24, width, height);

    InitPlanes();
    InitSpheres();
    InitCapsules();
    InitEllipsoids();
}

//--------------------------------------------------------------------------------------
// Called right before creating a D3D9 or D3D10 device, allowing the app to modify the device settings as needed
//--------------------------------------------------------------------------------------
bool CALLBACK ModifyDeviceSettings(DXUTDeviceSettings* pDeviceSettings, void* pUserContext)
{
    // For the first device created if its a REF device, optionally display a warning dialog box
    static bool s_bFirstTime = true;
    if(s_bFirstTime)
    {
        s_bFirstTime = false;
        if((DXUT_D3D9_DEVICE == pDeviceSettings->ver && pDeviceSettings->d3d9.DeviceType == D3DDEVTYPE_REF) ||
            (DXUT_D3D10_DEVICE == pDeviceSettings->ver && pDeviceSettings->d3d10.DriverType == D3D10_DRIVER_TYPE_REFERENCE))
            DXUTDisplaySwitchingToREFWarning(pDeviceSettings->ver);
    }

	pDeviceSettings->d3d10.SyncInterval = 0;	// turn off vsync
#ifdef _DEBUG
	pDeviceSettings->d3d10.CreateFlags |= D3D10_CREATE_DEVICE_DEBUG;
#endif

	return true;
}

//--------------------------------------------------------------------------------------
// Handle updates to the scene.  This is called regardless of which D3D API is used
//--------------------------------------------------------------------------------------
void CALLBACK OnFrameMove(double time_d, float elapsedTime, void* pUserContext)
{
    ID3D10Device* pd3dDevice = DXUTGetD3D10Device();

    // Update the camera's position based on user input 
    g_Camera.FrameMove(elapsedTime);

    // Simulation control
    if (!g_Run)
        return;

    // Time management
    static float g_CurrentTime;
    static float g_OldStateTime = -1;
    static float g_NewStateTime;
    static float g_OldTimeStep = -1;
    float timeStep = 0.01f;
    float time = static_cast<float>(time_d);

    // State time initialization
    if (g_OldStateTime < 0) {
        g_CurrentTime = time;
        g_OldStateTime = g_CurrentTime - timeStep;
        g_NewStateTime = g_CurrentTime;
        return;
    }

    // Time step clamping
    if (time - g_CurrentTime > 0.1f) {
        elapsedTime = timeStep;
        float currentTime = time - elapsedTime;
        g_OldStateTime += currentTime - g_CurrentTime;
        g_NewStateTime += currentTime - g_CurrentTime;
        g_CurrentTime = currentTime;
    }

    // Simulation loop
    while (time - g_CurrentTime >= timeStep) {
        g_CurrentTime += timeStep;

        // Simulate cloth
        SimulateCloth(pd3dDevice, timeStep, g_OldTimeStep < 0 ? timeStep : g_OldTimeStep);

        g_OldTimeStep = timeStep;
        g_OldStateTime = g_NewStateTime;
        g_NewStateTime = g_CurrentTime;
        if (g_StepSimulation > 0) {
            --g_StepSimulation;
            if (g_StepSimulation == 0)
                g_Run = false;
        }
    }
}

void Step(int n)
{
    if (!g_Run) {
        g_StepSimulation = n;
        g_Run = true;
    }
}

void SimulateCloth(ID3D10Device* pd3dDevice, float timeStep, float oldTimeStep)
{
	HRESULT hr = S_OK;

    // Effect variables
    V(g_Effect->GetVariableByName("TimeStep")->AsScalar()->SetFloat(timeStep));
    V(g_Effect->GetVariableByName("OldTimeStep")->AsScalar()->SetFloat(oldTimeStep));
    D3DXVECTOR2 springConstraint(2.0f / (g_Width - 1), 2.0f / (g_Height - 1));
    V(g_Effect->GetVariableByName("DistanceAtRestX")->AsScalar()->SetFloat(springConstraint.x));
    V(g_Effect->GetVariableByName("DistanceAtRestY")->AsScalar()->SetFloat(springConstraint.y));
    float springConstraintLength = D3DXVec2Length(&springConstraint);
    V(g_Effect->GetVariableByName("DistanceAtRestXY")->AsScalar()->SetFloat(springConstraintLength));
    V(g_Effect->GetVariableByName("LastPrimitiveIndex")->AsScalar()->SetInt(g_LastPrimitiveIndex));
    V(g_Effect->GetVariableByName("LastPrimitiveSize")->AsScalar()->SetInt(g_LastPrimitiveSize));

    // Planes
    V(g_Effect->GetVariableByName("NumPlanes")->AsScalar()->SetInt(g_NumPlanes));
    V(g_Effect->GetVariableByName("PlaneList")->SetRawValue(g_Plane, 0, sizeof(g_Plane)));

    // Spheres
    V(g_Effect->GetVariableByName("NumSpheres")->AsScalar()->SetInt(g_NumSpheres));
    V(g_Effect->GetVariableByName("SphereList")->SetRawValue(g_Sphere, 0, sizeof(g_Sphere)));

    // Capsules
    V(g_Effect->GetVariableByName("NumCapsules")->AsScalar()->SetInt(g_NumCapsules));
    V(g_Effect->GetVariableByName("CapsuleList")->SetRawValue(g_Capsule, 0, sizeof(g_Capsule)));

    // Ellipsoids
    V(g_Effect->GetVariableByName("NumEllipsoids")->AsScalar()->SetInt(g_NumEllipsoids));
    V(g_Effect->GetVariableByName("EllipsoidList")->SetRawValue(g_Ellipsoid, 0, sizeof(g_Ellipsoid)));


    ID3D10EffectTechnique* technique;
    ID3D10Buffer* buffers[] = { 0, 0, 0 };
    UINT strides[] = { 0, 0, 0 };
    UINT offset[] = { 0, 0, 0 };

    // Forces
    if (g_Reset) {
        pd3dDevice->CopyResource(g_ParticleVB[g_Old], g_InitialPositionVB);
        pd3dDevice->CopyResource(g_ParticleVB[g_Current], g_InitialPositionVB);
        ComputeNormalTangent(pd3dDevice);
        InitializePositions(0);
        g_Reset = false;
    }
    buffers[0] = g_ParticleVB[g_Current];
    buffers[1] = g_ParticleVB[g_Old];
    buffers[2] = g_NormalTangentVB;
    strides[0] = strides[1] = sizeof(Particle);
    strides[2] = sizeof(NormalTangent);
    pd3dDevice->IASetVertexBuffers(0, 3, buffers, strides, offset);
    pd3dDevice->IASetInputLayout(g_ApplyForcesIL);
    pd3dDevice->SOSetTargets(1, &g_ParticleVB[g_New], offset);
    technique = g_Effect->GetTechniqueByName("SimulateCloth");
    pd3dDevice->IASetPrimitiveTopology(D3D10_PRIMITIVE_TOPOLOGY_POINTLIST);
    float heading = D3DXToRadian(g_WindHeading);
    D3DXVECTOR3 wind(sinf(heading), 0, cosf(heading));
    wind *= (float)g_WindStrength;
    V(g_Effect->GetVariableByName("Wind")->AsVector()->SetFloatVector(wind));
    technique->GetPassByName("ApplyForces")->Apply(0);
    pd3dDevice->Draw(g_NumVertices, 0);
    pd3dDevice->SOSetTargets(0, 0, 0);

    // Rotate buffers
    int discard = g_Old;
    g_Old = g_Current;
    g_Current = g_New;
    g_New = discard;

    // Move anchor points
    if (g_TransformAnchorPoints) {
        UINT strides = sizeof(AnchorPoint);
        UINT offset = 0;
        pd3dDevice->IASetVertexBuffers(0, 1, &g_AnchorVB, &strides, &offset);
        V(g_Effect->GetVariableByName("AnchorPoints")->AsShaderResource()->SetResource(g_ParticleSRV[g_Old]));
        V(g_Effect->GetVariableByName("AnchorPointTransform")->AsMatrix()->SetMatrix(g_Transform));
        technique->GetPassByName("TransformAnchorPoints")->Apply(0);
        pd3dDevice->IASetInputLayout(g_AnchorIL);
        pd3dDevice->IASetPrimitiveTopology(D3D10_PRIMITIVE_TOPOLOGY_POINTLIST);
        pd3dDevice->OMSetRenderTargets(1, &g_ParticleRTV[g_Current], 0);
        D3D10_VIEWPORT viewPort;
        viewPort.TopLeftX = 0;
        viewPort.TopLeftY = 0;
        viewPort.Width = g_NumVertices;
        viewPort.Height = 1;
        viewPort.MinDepth = 0;
        viewPort.MaxDepth = 1;
        pd3dDevice->RSSetViewports(1, &viewPort);
        pd3dDevice->Draw(g_NumAnchorPoints, 0);
        V(g_Effect->GetVariableByName("AnchorPoints")->AsShaderResource()->SetResource(0));
        pd3dDevice->RSSetViewports(1, &g_BackBufferVP);
        pd3dDevice->OMSetRenderTargets(1, &g_BackBufferRTV, g_BackBufferDSV);
        g_TransformAnchorPoints = false;
        D3DXVECTOR3 newClothCenter;
        D3DXVec3TransformCoord(&newClothCenter, &g_Center, &g_Transform);
        g_Center = newClothCenter;
    }

    // Compute cutter
    if (CutCloth(pd3dDevice)) {
        V(g_Effect->GetVariableByName("Eye")->SetRawValue(&g_Eye, 0, sizeof(D3DXVECTOR3)));
        pd3dDevice->CopyResource(g_CutterEdgeCB, g_CutterEdgeVB);
        V(g_Effect->GetVariableByName("Cut")->AsScalar()->SetBool(true));
        V(g_Effect->GetVariableByName("NumCutterTriangles")->AsScalar()->SetInt(g_NumCutterTriangles));
        V(g_Effect->GetVariableByName("FirstCutterTriangle")->AsScalar()->SetInt(g_FirstCutterTriangle));
   }

    // Uncut
    if (g_Uncut) {
        buffers[0] = g_ParticleVB[g_Current];
        buffers[1] = 0;
        buffers[2] = 0;
        strides[0] = sizeof(Particle);
        pd3dDevice->IASetVertexBuffers(0, 3, buffers, strides, offset);
        pd3dDevice->IASetInputLayout(g_SatisfyConstraintsIL);
        pd3dDevice->SOSetTargets(1, &g_ParticleVB[g_New], offset);
        technique = g_Effect->GetTechniqueByName("SimulateCloth");
		assert(technique->IsValid());
        pd3dDevice->IASetPrimitiveTopology(D3D10_PRIMITIVE_TOPOLOGY_POINTLIST);
        technique->GetPassByName("Uncut")->Apply(0);
        pd3dDevice->Draw(g_NumVertices, 0);
        pd3dDevice->SOSetTargets(0, 0, 0);
        g_Uncut = false;

        // Rotate buffers
        discard = g_Current;
        g_Current = g_New;
        g_New = discard;
    }

    // Constraints
    pd3dDevice->IASetInputLayout(g_SatisfyConstraintsIL);
    for (int simPass = 0; simPass < g_NumSimPasses; ++simPass) {
        for (int p = PASS_SIMULATE_STRUCTURAL_AND_SHEAR_SPRING_0; p <= PASS_SIMULATE_COLLISION; ++p) {

            // Swap VBs
            pd3dDevice->SOSetTargets(0, 0, 0);
            buffers[0] = g_ParticleVB[g_Current];
            buffers[1] = 0;
            buffers[2] = 0;
            pd3dDevice->IASetVertexBuffers(0, 3, buffers, strides, offset);
            pd3dDevice->SOSetTargets(1, &g_ParticleVB[g_New], offset);

            int indexCount;
            if (p == PASS_SIMULATE_COLLISION) {
                pd3dDevice->IASetPrimitiveTopology(D3D10_PRIMITIVE_TOPOLOGY_POINTLIST);
                indexCount = g_NumVertices;
            }
            else {
                pd3dDevice->IASetPrimitiveTopology(D3D10_PRIMITIVE_TOPOLOGY_LINELIST_ADJ);
                indexCount = g_NumSimIndices;
            }

            // Draw
            pd3dDevice->IASetIndexBuffer(g_SimulateIB[p], DXGI_FORMAT_R16_UINT, 0);
            V(g_Effect->GetVariableByName("NumSimulatedPrimitives")->AsScalar()->SetInt(g_NumSimulatedPrimitives[p]));

			ID3D10EffectPass* pPass = NULL;
            if (p <= PASS_SIMULATE_STRUCTURAL_AND_SHEAR_SPRING_1) {
                V(g_Effect->GetVariableByName("ConnectionConfigOffset")->AsScalar()->SetInt(p == PASS_SIMULATE_STRUCTURAL_AND_SHEAR_SPRING_0 ? 0 : 8));
                pPass = technique->GetPassByName("SatisfyStructuralAndShearSpringConstraints");
            }
            else if (p <= PASS_SIMULATE_SHEAR_SPRING_1)
			{
                pPass = technique->GetPassByName("SatisfyShearSpringConstraints");
			}
            else
			{
                pPass = technique->GetPassByName("SatisfyCollisionConstraints");
			}

			assert(pPass != NULL);
			assert(pPass->IsValid());
			pPass->Apply(0);
            pd3dDevice->DrawIndexed(indexCount, 0, 0);

            // Rotate buffers
            discard = g_Current;
            g_Current = g_New;
            g_New = discard;
        }
        V(g_Effect->GetVariableByName("Cut")->AsScalar()->SetBool(false));
    }
    pd3dDevice->SOSetTargets(0, 0, 0);

    // Normals and tangents
    ComputeNormalTangent(pd3dDevice);
}

void ComputeNormalTangent(ID3D10Device* pd3dDevice)
{
    ID3D10EffectTechnique* technique;
    ID3D10Buffer* buffers[] = { 0, 0, 0 };
    UINT strides[] = { 0, 0, 0 };
    UINT offset[] = { 0, 0, 0 };
    strides[0] = sizeof(Particle);
    buffers[0] = g_ParticleVB[g_Current];
    buffers[1] = 0;
    buffers[2] = 0;
    pd3dDevice->IASetVertexBuffers(0, 3, buffers, strides, offset);
    pd3dDevice->IASetIndexBuffer(g_NormalTangentIB, DXGI_FORMAT_R16_UINT, 0);
    pd3dDevice->IASetInputLayout(g_SatisfyConstraintsIL);
    pd3dDevice->SOSetTargets(1, &g_NormalTangentVB, offset);
    technique = g_Effect->GetTechniqueByName("SimulateCloth");
	assert(technique->IsValid());
    pd3dDevice->IASetPrimitiveTopology(D3D10_PRIMITIVE_TOPOLOGY_TRIANGLELIST_ADJ);
    technique->GetPassByName("ComputeNormalTangent")->Apply(0);
    pd3dDevice->DrawIndexed(6 * g_NumVertices, 0, 0);
    pd3dDevice->SOSetTargets(0, 0, 0);
}

//--------------------------------------------------------------------------------------
// Render
//--------------------------------------------------------------------------------------
void CALLBACK OnD3D10FrameRender(ID3D10Device* pd3dDevice, double time_d, float elapsedTime, void* pUserContext)
{
    // Clear the depth stencil
    float clearColor[] = { 0.176f, 0.196f, 0.667f, 0 };
    pd3dDevice->ClearRenderTargetView(DXUTGetD3D10RenderTargetView(), clearColor);
    pd3dDevice->ClearDepthStencilView(DXUTGetD3D10DepthStencilView(), D3D10_CLEAR_DEPTH, 1.0, 0);
    
    // If the settings dialog is being shown, then render it instead of rendering the app's scene
    if(g_SettingsDlg.IsActive())
    {
        g_SettingsDlg.OnRender(elapsedTime);
        return;
    }

    // Get the projection & view matrix from the camera class
    g_Projection = *g_Camera.GetProjMatrix();
    g_View = *g_Camera.GetViewMatrix();
    D3DXMATRIX viewInv;
    D3DXMatrixInverse(&viewInv, 0, &g_View);
    g_Eye = D3DXVECTOR3(viewInv(3, 0), viewInv(3, 1), viewInv(3, 2));

    // View projection matrix
    g_ViewProjection = g_View * g_Projection;

    // Render scene
    RenderScene(pd3dDevice, g_ViewProjection);

    // Render tangent space
    if (g_ShowTangentSpace)
        RenderTangentSpace(pd3dDevice);

    // HUD
    DXUT_BeginPerfEvent( DXUT_PERFEVENTCOLOR, L"HUD / Stats" );
    g_SampleUI.OnRender( elapsedTime );
    g_HUD.OnRender( elapsedTime );
    DXUT_EndPerfEvent();
    RenderText();
}

void RenderScene(ID3D10Device* pd3dDevice, D3DXMATRIX& viewProjection, D3DXMATRIX* renderPositionTransform)
{
    // Render scene
    pd3dDevice->IASetInputLayout(g_RenderMeshIL);
    for (int i = 0; i < g_NumPlanes; ++i) {
        SetRenderState(g_PlaneWorld[i], g_PlaneDiffuseTexture[i], g_PlaneNormalMap[i], viewProjection, renderPositionTransform);
        g_PlaneMesh->DrawSubset(0);
    }
    for (int i = 0; i < g_NumSpheres; ++i) {
        SetRenderState(g_SphereWorld[i], 0, 0, viewProjection, renderPositionTransform);
        g_SphereMesh->DrawSubset(0);
    }
    for (int i = 0; i < g_NumCapsules; ++i) {
        SetRenderState(g_CapsuleWorld[i], 0, 0, viewProjection, renderPositionTransform);
        g_CapsuleMesh[i]->DrawSubset(0);
    }
    for (int i = 0; i < g_NumEllipsoids; ++i) {
        SetRenderState(g_EllipsoidWorld[i], 0, 0, viewProjection, renderPositionTransform);
        g_SphereMesh->DrawSubset(0);
    }

	HRESULT hr = S_OK;

    // Render cloth
    ID3D10Buffer* buffers[] = { 0, 0, 0 };
    UINT strides[] = { 0, 0, 0 };
    UINT offset[] = { 0, 0, 0 };
    V(g_Effect->GetVariableByName("ViewProjection")->AsMatrix()->SetMatrix(viewProjection));
    if (renderPositionTransform)
        V(g_Effect->GetVariableByName("Transform")->AsMatrix()->SetMatrix(*renderPositionTransform));
    V(g_Effect->GetVariableByName("DiffuseCoeff")->AsScalar()->SetFloat(1.0f));
    V(g_Effect->GetVariableByName("SpecularCoeff")->AsScalar()->SetFloat(0.1f));
    V(g_Effect->GetVariableByName("SpecularPower")->AsScalar()->SetFloat(10));
    V(g_Effect->GetVariableByName("Color")->AsVector()->SetFloatVector(D3DXVECTOR3(1, 1, 1)));
    buffers[0] = g_ParticleVB[g_Current];
    buffers[1] = g_NormalTangentVB;
    buffers[2] = g_TexCoordVB;
    strides[0] = sizeof(Particle);
    strides[1] = sizeof(NormalTangent);
    strides[2] = sizeof(TexCoord);
    pd3dDevice->IASetVertexBuffers(0, 3, buffers, strides, offset);
    pd3dDevice->IASetInputLayout(g_RenderClothIL);
    pd3dDevice->IASetIndexBuffer(g_RenderIB, DXGI_FORMAT_R16_UINT, 0);
    pd3dDevice->IASetPrimitiveTopology(D3D10_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
    ID3D10EffectTechnique* technique = g_Effect->GetTechniqueByName("RenderCloth");
	assert(technique->IsValid());
    V(g_Effect->GetVariableByName("PositionStepX")->AsScalar()->SetFloat(1.0f / (g_Width - 1)));
    V(g_Effect->GetVariableByName("PositionStepY")->AsScalar()->SetFloat(1.0f / (g_Height - 1)));
    V(g_Effect->GetVariableByName("TexCoordStepX")->AsScalar()->SetFloat(0.5f * g_TexCoordScale / (g_Width - 1)));
    V(g_Effect->GetVariableByName("TexCoordStepY")->AsScalar()->SetFloat(0.5f * g_TexCoordScale / (g_Height - 1)));
    if (renderPositionTransform)
        technique->GetPassByName("Position")->Apply(0);
    else if (g_Wireframe)
        technique->GetPassByName("Colored")->Apply(0);
    else {
        V(g_Effect->GetVariableByName("DiffuseTexture")->AsShaderResource()->SetResource(g_ClothDiffuseTexture));
        V(g_Effect->GetVariableByName("NormalMap")->AsShaderResource()->SetResource(g_ClothNormalMap));
        technique->GetPassByName("Textured")->Apply(0);
    }
    bool renderInWireframe = (renderPositionTransform == 0 && g_Wireframe);
    if (renderInWireframe)
        pd3dDevice->RSSetState(g_WireframeRS);
    pd3dDevice->DrawIndexed(g_NumIndices, 0, 0);
    if (renderInWireframe)
        pd3dDevice->RSSetState(g_SolidRS);
}


void SetRenderState(D3DXMATRIX& world, ID3D10ShaderResourceView* diffuseTexture, ID3D10ShaderResourceView* normalMap,
                    const D3DXMATRIX& viewProjection, const D3DXMATRIX* renderPositionTransform)
{
	HRESULT hr = S_OK;

    SetMatrices(world, viewProjection, renderPositionTransform);
    V(g_Effect->GetVariableByName("Eye")->SetRawValue(&g_Eye, 0, sizeof(D3DXVECTOR3)));
    SetMaterial(diffuseTexture == 0);
    ID3D10EffectTechnique* technique = g_Effect->GetTechniqueByName("RenderMesh");
	assert(technique->IsValid());
    if (renderPositionTransform)
        technique->GetPassByName("Position")->Apply(0);
    else if (diffuseTexture) {
        V(g_Effect->GetVariableByName("DiffuseTexture")->AsShaderResource()->SetResource(diffuseTexture));
        V(g_Effect->GetVariableByName("NormalMap")->AsShaderResource()->SetResource(normalMap));
        technique->GetPassByName("Textured")->Apply(0);
    }
    else
        technique->GetPassByName("Untextured")->Apply(0);
}

void SetMatrices(D3DXMATRIX& world, const D3DXMATRIX& viewProjection, const D3DXMATRIX* renderPositionTransform)
{
	HRESULT hr = S_OK;

    V(g_Effect->GetVariableByName("World")->AsMatrix()->SetMatrix(world));
    D3DXMATRIX worldI;
    D3DXMatrixInverse(&worldI, 0, &world);
    D3DXMATRIX worldIT;
    D3DXMatrixTranspose(&worldIT, &worldI);
    V(g_Effect->GetVariableByName("WorldIT")->AsMatrix()->SetMatrix(worldIT));
    D3DXMATRIX thinningMatrix;
    ComputeThinningMatrix(world, -0.065f, thinningMatrix);
    D3DXMATRIX worldViewProjection = thinningMatrix * world * viewProjection;
    V(g_Effect->GetVariableByName("WorldViewProjection")->AsMatrix()->SetMatrix(worldViewProjection));
    if (renderPositionTransform) {
        D3DXMATRIX transform = world * *renderPositionTransform;
        V(g_Effect->GetVariableByName("Transform")->AsMatrix()->SetMatrix(transform));
    }
}

void SetMaterial(bool shiny)
{
	HRESULT hr = S_OK;

    if (shiny) {
        V(g_Effect->GetVariableByName("DiffuseCoeff")->AsScalar()->SetFloat(1.0f));
        V(g_Effect->GetVariableByName("SpecularCoeff")->AsScalar()->SetFloat(0.4f));
        V(g_Effect->GetVariableByName("SpecularPower")->AsScalar()->SetFloat(1000));
    }
    else {
        V(g_Effect->GetVariableByName("DiffuseCoeff")->AsScalar()->SetFloat(0.6f));
        V(g_Effect->GetVariableByName("SpecularCoeff")->AsScalar()->SetFloat(0.2f));
        V(g_Effect->GetVariableByName("SpecularPower")->AsScalar()->SetFloat(10.0f));
    }
    V(g_Effect->GetVariableByName("Color")->AsVector()->SetFloatVector(D3DXVECTOR3(1, 1, 1)));
}

void ComputeThinningMatrix(D3DXMATRIX& world, float thinning, D3DXMATRIX& mat)
{
    D3DXVECTOR3 dim;
    for (int i = 0; i < 3; ++i) {
        D3DXVECTOR3 row(world(i, 0), world(i, 1), world(i, 2));
        dim[i] = D3DXVec3Length(&row);
    }
    D3DXMatrixScaling(&mat, max(1 + thinning / dim[0], 0), max(1 + thinning / dim[1], 0), max(1 + thinning / dim[2], 0));
}

void RenderTangentSpace(ID3D10Device* pd3dDevice)
{
    ID3D10EffectTechnique* technique;
    ID3D10Buffer* buffers[] = { 0, 0, 0 };
    UINT strides[] = { 0, 0, 0 };
    UINT offset[] = { 0, 0, 0 };

	HRESULT hr = S_OK;

    buffers[0] = g_ParticleVB[g_Current];
    buffers[1] = g_NormalTangentVB;
    buffers[2] = 0;
    strides[0] = sizeof(Particle);
    strides[1] = sizeof(NormalTangent);
    pd3dDevice->IASetVertexBuffers(0, 2, buffers, strides, offset);
    technique = g_Effect->GetTechniqueByName("RenderTangentSpace");
	assert(technique->IsValid());
    V(g_Effect->GetVariableByName("ViewProjection")->AsMatrix()->SetMatrix(g_ViewProjection));
    pd3dDevice->IASetInputLayout(g_RenderTangentSpaceIL);
    pd3dDevice->IASetPrimitiveTopology(D3D10_PRIMITIVE_TOPOLOGY_POINTLIST);
    technique->GetPassByIndex(0)->Apply(0);
    pd3dDevice->Draw(g_NumVertices, 0);
}

//--------------------------------------------------------------------------------------
// Render the help and statistics text
//--------------------------------------------------------------------------------------
void RenderText()
{

	long w,h;
	w =  DXUTGetWindowWidth();
	h =  DXUTGetWindowHeight();

	g_TxtHelper->Begin();
    g_TxtHelper->SetInsertionPos(2, 0);
    g_TxtHelper->SetForegroundColor(D3DXCOLOR(1.0f, 1.0f, 0.0f, 1.0f));
    g_TxtHelper->DrawTextLine(DXUTGetFrameStats(true)); // Statics FPS
    g_TxtHelper->DrawTextLine(DXUTGetDeviceStats());	// Statics Device
    
	if (g_Help) {
	    g_TxtHelper->SetInsertionPos(2, h-200);
        g_TxtHelper->SetForegroundColor(D3DXCOLOR(1.0f, 1.0f, 1.0f, 1.0f));
		g_TxtHelper->DrawTextLine(L"HELP :");
		g_TxtHelper->DrawTextLine(L"-----------------------------------------------");
        g_TxtHelper->SetForegroundColor(D3DXCOLOR(1.0f, 0.75f, 0.0f, 1.0f));
        g_TxtHelper->DrawTextLine(L"Mouse controls (F1 to hide):");
        g_TxtHelper->DrawTextLine(L"- Mouse Left+Ctrl = Cut cloth");
        g_TxtHelper->DrawTextLine(L"- Mouse Left+Shift = Dolly cloth");
        g_TxtHelper->DrawTextLine(L"- Mouse Left = Pan cloth");
        g_TxtHelper->DrawTextLine(L"- Mouse Middle = Rotate cloth");
        g_TxtHelper->DrawTextLine(L"- Mouse Right = Rotate camera");
        g_TxtHelper->SetForegroundColor(D3DXCOLOR(1.0f, 1.0f, 1.0f, 1.0f));
		g_TxtHelper->DrawTextLine(L"----------------------------------------------");
    }
    else {
        g_TxtHelper->SetForegroundColor(D3DXCOLOR( 1.0f, 1.0f, 1.0f, 1.0f));
        g_TxtHelper->DrawTextLine( L"Press F1 for help" );
    }

	/**************************************************************************/
	// Sgiman Creative Studio (sgiman.com)
	g_TxtHelper->SetInsertionPos(2, h-35);
	g_TxtHelper->SetForegroundColor(D3DXCOLOR( 0.0f, 1.0f, 1.0f, 1.0f));
	g_TxtHelper->DrawTextLine(L"Test Dynamic Cloth");
	g_TxtHelper->SetForegroundColor(D3DXCOLOR( 1.0f, 1.0f, 1.0f, 1.0f));
	g_TxtHelper->DrawTextLine(L"Sgiman Creative Studio (sgiman.com)");
	/**************************************************************************/
  
	g_TxtHelper->End();
}

//--------------------------------------------------------------------------------------
// Handle messages to the application
//--------------------------------------------------------------------------------------
LRESULT CALLBACK MsgProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam, bool* pbNoFurtherProcessing, void* pUserContext)
{
    // Pass messages to dialog resource manager calls so GUI state is updated correctly
    *pbNoFurtherProcessing = g_DialogResourceManager.MsgProc(hWnd, uMsg, wParam, lParam);
    if(*pbNoFurtherProcessing)
        return 0;

    // Pass messages to settings dialog if its active
    if(g_SettingsDlg.IsActive())
    {
        g_SettingsDlg.MsgProc(hWnd, uMsg, wParam, lParam);
        return 0;
    }

    // Give the dialogs a chance to handle the message first
    *pbNoFurtherProcessing = g_HUD.MsgProc(hWnd, uMsg, wParam, lParam);
    if(*pbNoFurtherProcessing)
        return 0;
    *pbNoFurtherProcessing = g_SampleUI.MsgProc(hWnd, uMsg, wParam, lParam);
    if(*pbNoFurtherProcessing)
        return 0;

    // Pass all remaining windows messages to camera so it can respond to user input
    g_Camera.HandleMessages(hWnd, uMsg, wParam, lParam);

    // Move cloth
    MoveCloth(hWnd, g_CtrlDown ? WM_LBUTTONUP : uMsg, wParam, lParam);

    // Process cut mode
    CutCloth(0, hWnd, g_CtrlDown ? uMsg : WM_LBUTTONUP, lParam);

    return 0;
}

void MoveCloth(HWND hWnd, int msg, WPARAM wParam, LPARAM lParam)
{
    static LPARAM g_LastMouse;
    static D3DXVECTOR3 g_LastTrackballPoint;
    static bool g_ClothIsMoved;
    static D3DXMATRIX g_PivotMatrix, g_PivotMatrixInv;
    static float g_ScreenClothCenterX, g_ScreenClothCenterY;

    int mouseX = (short)LOWORD(lParam);
    int mouseY = (short)HIWORD(lParam);
    switch (msg) {
        case WM_LBUTTONDOWN:
        case WM_MBUTTONDOWN:
            // Pivot transform
            {
                D3DXMATRIX pivotTranslation;
                D3DXMatrixTranslation(&pivotTranslation, -g_Center.x, -g_Center.y, -g_Center.z);
                D3DXMATRIX pivotRotation = g_View;
                pivotRotation(3, 0) = pivotRotation(3, 1) = pivotRotation(3, 2) = 0;
                g_PivotMatrix = pivotTranslation * pivotRotation;
                D3DXMatrixInverse(&g_PivotMatrixInv, 0, &g_PivotMatrix);
            }

            WorldToScreen(g_Center, g_ScreenClothCenterX, g_ScreenClothCenterY);
            g_LastTrackballPoint = ScreenToTrackballPoint(mouseX - g_ScreenClothCenterX, mouseY - g_ScreenClothCenterY);
            g_LastMouse = lParam;
            g_ClothIsMoved = true;
            break;
        case WM_MOUSEMOVE:
            if (g_ClothIsMoved) {
                D3DXMATRIX transform;
                D3DXMatrixIdentity(&transform);

                // Translate
                if (wParam & MK_LBUTTON) {
                    float scale = 2;
                    float dx = (scale * ((short)LOWORD(g_LastMouse) - mouseX)) / g_BackBufferWidth;
                    float dy = (scale * ((short)HIWORD(g_LastMouse) - mouseY)) / g_BackBufferHeight;
                    if (g_ShiftDown)
                        D3DXMatrixTranslation(&transform, 0, 0, dy);
                    else
                        D3DXMatrixTranslation(&transform, -dx, dy, 0);
                    g_LastMouse = lParam;
                }

                // Rotate
                else if (wParam & MK_MBUTTON) {
                    D3DXVECTOR3 trackballPoint = ScreenToTrackballPoint(mouseX - g_ScreenClothCenterX, mouseY - g_ScreenClothCenterY);
                    D3DXVECTOR3 cross;
                    D3DXVec3Cross(&cross, &g_LastTrackballPoint, &trackballPoint);
                    float dot = D3DXVec3Dot(&g_LastTrackballPoint, &trackballPoint);
                    D3DXQUATERNION dq(cross.x, cross.y, cross.z, dot);
                    D3DXMatrixRotationQuaternion(&transform, &dq);
                    g_LastTrackballPoint = trackballPoint;
                }

                // Final transform
                g_Transform = g_PivotMatrix * transform * g_PivotMatrixInv;
                g_TransformAnchorPoints = true;
            }
            break;
        case WM_LBUTTONUP:
        case WM_MBUTTONUP:
            g_ClothIsMoved = false;
            break;
        default:
            break;
    }
}

void WorldToScreen(const D3DXVECTOR3& position, float& x, float& y)
{
    D3DXVECTOR3 screenPosition;
    D3DXVec3TransformCoord(&screenPosition, &position, &g_ViewProjection);
    x = ( screenPosition.x + 1) * g_BackBufferWidth  / 2;
    y = (-screenPosition.y + 1) * g_BackBufferHeight / 2;
}

D3DXVECTOR3 ScreenToTrackballPoint(float x, float y)
{
    float scale = 1;
    x = - x / (scale * g_BackBufferWidth / 2);
    y =   y / (scale * g_BackBufferHeight / 2);
    float z = 0;
    float mag = x * x + y * y;
    if (mag > 1) {
        float scale = 1.0f / sqrtf(mag);
        x *= scale;
        y *= scale;
    }
    else
        z = sqrtf(1.0f - mag);
    return D3DXVECTOR3(x, y, z);
}

bool CutCloth(ID3D10Device* pd3dDevice, HWND hWnd, int msg, LPARAM lParam)
{
    static bool g_IsCut;
    static LPARAM g_LastMouse;
    static LPARAM g_CurrentMouse;

    if (pd3dDevice) {
        if (g_LastMouse != g_CurrentMouse) {
            RenderCutterEdge(pd3dDevice,
                             LOWORD(g_LastMouse), HIWORD(g_LastMouse),
                             LOWORD(g_CurrentMouse), HIWORD(g_CurrentMouse));
            g_LastMouse = g_CurrentMouse;
            return true;
        }
    }
    else
        switch (msg) {
        case WM_LBUTTONDOWN:
            g_IsCut = true;
            g_LastMouse = lParam;
            g_CurrentMouse = lParam;
            break;
        case WM_MOUSEMOVE:
            if (g_IsCut)
                g_CurrentMouse = lParam;
            break;
        case WM_LBUTTONUP:
            g_IsCut = false;
            g_NumCutterTriangles = 0;
           break;
        default:
            break;
        }
    return false;
}



void RenderCutterEdge(ID3D10Device* pd3dDevice, int x0, int y0, int x1, int y1)
{
    D3DXMATRIX eyeTrans;
    D3DXMatrixTranslation(&eyeTrans, - g_Eye.x, - g_Eye.y, - g_Eye.z);
    if (g_NumCutterTriangles == 0) {
        RenderPosition(pd3dDevice, g_CutterEdgeRTV, x0, y0, 0, &eyeTrans);
        g_FirstCutterTriangle = 0;
    }
    int offset;
    if (g_NumCutterTriangles == MAX_CUTTER_TRIANGLES) {
        offset = g_FirstCutterTriangle;
        ++g_FirstCutterTriangle;
        if (g_FirstCutterTriangle > MAX_CUTTER_TRIANGLES)
            g_FirstCutterTriangle = 0;
    }
    else {
        ++g_NumCutterTriangles;
        offset = g_NumCutterTriangles;
    }
    RenderPosition(pd3dDevice, g_CutterEdgeRTV, x1, y1, offset, &eyeTrans);
}

void RenderPosition(ID3D10Device* pd3dDevice, ID3D10RenderTargetView* rtv, int x, int y,
                    int offset, D3DXMATRIX* renderPositionTransform)
{
    pd3dDevice->OMSetRenderTargets(1, &rtv, 0);
    pd3dDevice->ClearDepthStencilView(g_BackBufferDSV, D3D10_CLEAR_DEPTH, 1.0, 0);
    D3D10_VIEWPORT viewPort;
    viewPort.TopLeftX = offset;
    viewPort.TopLeftY = 0;
    viewPort.Width = 1;
    viewPort.Height = 1;
    viewPort.MinDepth = 0;
    viewPort.MaxDepth = 1;
    pd3dDevice->RSSetViewports(1, &viewPort);
    D3DXMATRIX viewProjection = g_ViewProjection * GetPixelTargetTransform(x, y);
    RenderScene(pd3dDevice, viewProjection, renderPositionTransform);
    pd3dDevice->RSSetViewports(1, &g_BackBufferVP);
    pd3dDevice->OMSetRenderTargets(1, &g_BackBufferRTV, g_BackBufferDSV);
}

D3DXMATRIX GetPixelTargetTransform(int x, int y)
{
    float w = static_cast<float>(g_BackBufferWidth);
    float h = static_cast<float>(g_BackBufferHeight);
    D3DXVECTOR3 translation(2 * x / w - 1, 1 - 2 * y / h, 0);
    D3DXVECTOR3 scaling(w, h, 1);
    D3DXVECTOR3 translationInv = - translation;
    D3DXMATRIX mouseTargetTransform;
    D3DXMatrixTransformation(&mouseTargetTransform, &translation, 0, &scaling, 0, 0, &translationInv);
    return mouseTargetTransform;
}

//--------------------------------------------------------------------------------------
// Handle key presses
//--------------------------------------------------------------------------------------
void CALLBACK OnKeyboard(UINT nChar, bool bKeyDown, bool bAltDown, void* pUserContext)
{
    if (bKeyDown)
        switch(nChar)
        {
            case '0':
                g_Reset = true;
                Step(1);
                break;
            case 'S':
                Step(1);
                break;
            case VK_F1:
                g_Help = !g_Help;
                break;
            case VK_SPACE:
                g_Run = !g_Run;
                break;
            case 'Z':
                g_Uncut = true;
                break;
            case 'W':
                g_Wireframe = !g_Wireframe;
                break;
            case VK_SHIFT:
                g_ShiftDown = true;
                break;
            case VK_CONTROL:
                g_CtrlDown = true;
                break;
        }
    else
        switch(nChar)
        {
            case VK_SHIFT:
                g_ShiftDown = false;
                break;
            case VK_CONTROL:
                g_CtrlDown = false;
                break;
        }
}

//--------------------------------------------------------------------------------------
// Handles the GUI events
//--------------------------------------------------------------------------------------
void CALLBACK OnGUIEvent(UINT nEvent, int nControlID, CDXUTControl* pControl, void* pUserContext)
{
    WCHAR label[MAX_PATH];
    switch(nControlID)
    {
        case IDC_TOGGLEFULLSCREEN:     DXUTToggleFullScreen(); break;
        case IDC_TOGGLEREF:            DXUTToggleREF(); break;
        case IDC_CHANGEDEVICE:         g_SettingsDlg.SetActive(!g_SettingsDlg.IsActive()); break;
        case IDC_RESET_SIMULATION:     g_Reset = true; break;
        case IDC_RUN_PAUSE_SIMULATION: g_Run = !g_Run; break;
        case IDC_STEP_SIMULATION:      Step(1); break;
        case IDC_NUM_SIM_PASSES:    
            g_NumSimPasses = g_SampleUI.GetSlider(IDC_NUM_SIM_PASSES)->GetValue(); 
            StringCchPrintf(label, MAX_PATH, L"Simulation passes: %d", g_NumSimPasses);
            g_SampleUI.GetStatic(IDC_NUM_SIM_PASSES_LABEL)->SetText(label);
            break;
        case IDC_WIND_HEADING:    
            g_WindHeading = g_SampleUI.GetSlider(IDC_WIND_HEADING)->GetValue(); 
            StringCchPrintf(label, MAX_PATH, L"Wind heading: %d", g_WindHeading);
            g_SampleUI.GetStatic(IDC_WIND_HEADING_LABEL)->SetText(label);
            break;
        case IDC_WIND_STRENGTH:    
            g_WindStrength = g_SampleUI.GetSlider(IDC_WIND_STRENGTH)->GetValue(); 
            StringCchPrintf(label, MAX_PATH, L"Wind strength: %d", g_WindStrength);
            g_SampleUI.GetStatic(IDC_WIND_STRENGTH_LABEL)->SetText(label);
            break;
        case IDC_UNCUT:                g_Uncut = true; break;
        case IDC_SHOW_TANGENT_SPACE:   g_ShowTangentSpace = !g_ShowTangentSpace; break;
        case IDC_WIREFRAME:            g_Wireframe = !g_Wireframe; break;
    }    
}

//--------------------------------------------------------------------------------------
// Reject any D3D10 devices that aren't acceptable by returning false
//--------------------------------------------------------------------------------------
bool CALLBACK IsD3D10DeviceAcceptable(UINT Adapter, UINT Output, D3D10_DRIVER_TYPE DeviceType, DXGI_FORMAT BackBufferFormat, bool bWindowed, void* pUserContext)
{
    return true;
}

//--------------------------------------------------------------------------------------
// Create any D3D10 resources that aren't dependant on the back buffer
//--------------------------------------------------------------------------------------
HRESULT CALLBACK OnD3D10CreateDevice(ID3D10Device* pd3dDevice, const DXGI_SURFACE_DESC *pBackBufferSurfaceDesc, void* pUserContext)
{
    HRESULT hr;

    V_RETURN(g_DialogResourceManager.OnD3D10CreateDevice(pd3dDevice));
    V_RETURN(g_SettingsDlg.OnD3D10CreateDevice(pd3dDevice));
    V_RETURN(D3DX10CreateFont(pd3dDevice, 17, 0, FW_BOLD, 1, FALSE, DEFAULT_CHARSET, 
                              OUT_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, 
                              L"Arial", &g_Font));
    V_RETURN(D3DX10CreateSprite(pd3dDevice, 512, &g_Sprite));
    g_TxtHelper = new CDXUTTextHelper( NULL, NULL, g_Font, g_Sprite, 15 );

    // Read the D3DX effect file
    WCHAR str[MAX_PATH];
    V_RETURN(NVUTFindDXSDKMediaFileCch(str, MAX_PATH, L".\\fx\\Cloth.fx"));
    V_RETURN(D3DX10CreateEffectFromFile(str, NULL, NULL, "fx_4_0", D3D10_SHADER_ENABLE_STRICTNESS, 0, pd3dDevice, NULL, NULL, &g_Effect, NULL, &hr));
    V(g_Effect->GetConstantBufferByName("CutterEdgeBuffer")->GetConstantBuffer(&g_CutterEdgeCB));

    // Setup the camera's view parameters
    D3DXVECTOR3 eye(0, 0, - 3.0f);
    D3DXVECTOR3 at(0, 0, 0);
    g_Camera.SetViewParams(&eye, &at);

    // Initialize particles
    Particle* particles = new Particle[g_NumVertices];
    InitializePositions(particles);
    V_RETURN(CreateIndexBuffers(pd3dDevice, particles));
    V_RETURN(CreateVertexBuffers(pd3dDevice, particles));
    delete [] particles;

    // Create various resources
    V_RETURN(CreateInputLayouts(pd3dDevice));
    V_RETURN(CreateTextures(pd3dDevice));
    V_RETURN(CreateRasterizerStates(pd3dDevice));

    // Create scene objects
    V_RETURN(CreatePlaneMesh(pd3dDevice));
    V_RETURN(CreateSphereMesh(pd3dDevice));
    V_RETURN(CreateCapsuleMeshes(pd3dDevice));

    g_Reset = true;

    return S_OK;
}

//--------------------------------------------------------------------------------------
// Create any D3D10 resources that depend on the back buffer
//--------------------------------------------------------------------------------------
HRESULT CALLBACK OnD3D10ResizedSwapChain( ID3D10Device* pd3dDevice, IDXGISwapChain *pSwapChain, const DXGI_SURFACE_DESC* pBackBufferSurfaceDesc, void* pUserContext )
{
    HRESULT hr;

    V_RETURN(g_DialogResourceManager.OnD3D10ResizedSwapChain( pd3dDevice, pBackBufferSurfaceDesc));
    V_RETURN(g_SettingsDlg.OnD3D10ResizedSwapChain(pd3dDevice, pBackBufferSurfaceDesc));

    pd3dDevice->OMGetRenderTargets(1, &g_BackBufferRTV, &g_BackBufferDSV);
    unsigned int n = 1;
    pd3dDevice->RSGetViewports(&n, &g_BackBufferVP);
    g_BackBufferWidth = pBackBufferSurfaceDesc->Width;
    g_BackBufferHeight = pBackBufferSurfaceDesc->Height;

    // Setup the camera's projection parameters
    float fAspectRatio = pBackBufferSurfaceDesc->Width / (float)pBackBufferSurfaceDesc->Height;
    g_Camera.SetProjParams(D3DX_PI/3, fAspectRatio, 0.1f, 5000.0f);
    g_Camera.SetWindow(pBackBufferSurfaceDesc->Width, pBackBufferSurfaceDesc->Height);

    g_HUD.SetLocation(pBackBufferSurfaceDesc->Width - 155, 0);
    g_HUD.SetSize(170, 170);
    g_SampleUI.SetLocation(pBackBufferSurfaceDesc->Width - 155, 110);
    g_SampleUI.SetSize(170, 300);

    return S_OK;
}

//--------------------------------------------------------------------------------------
// Initialize positions 
//--------------------------------------------------------------------------------------
void InitializePositions(Particle* particles)
{
    g_Center = D3DXVECTOR3(0, 0, 0);
    int v = 0;
    for (int z = 0; z < g_Height; ++z)
        for (int x = 0; x < g_Width; ++x) {
            D3DXVECTOR3 position;
            position.x = 2 * x / static_cast<float>(g_Width - 1) - 1;
            position.y = 1;
            position.z = 2 * z / static_cast<float>(g_Height - 1) - 1;
            if (particles) {
                particles[v].Position = position;
                particles[v].State = 0;
                SetFree(particles[v]);
                ResetConnectivity(particles[v]);
            }
            for (int i = 0; i < g_NumAnchorPoints; ++i)
                if (g_AnchorPoint[i].x == x && g_AnchorPoint[i].y == z) {
                    if (particles)
                        UnsetFree(particles[v]);
                    g_Center += position;
                }
            ++v;
        }
    g_Center /= (float)g_NumAnchorPoints;
    D3DXMatrixIdentity(&g_Transform);
    g_TransformAnchorPoints = false;
}

//--------------------------------------------------------------------------------------
// Create index buffers 
//--------------------------------------------------------------------------------------
HRESULT CreateIndexBuffers(ID3D10Device* pd3dDevice, Particle* particles)
{
    HRESULT hr;
    V_RETURN(CreateSimulationIB(pd3dDevice, particles));
    V_RETURN(CreateTangentSpaceIB(pd3dDevice));
    V_RETURN(CreateRenderingIB(pd3dDevice));
    return S_OK;
}

HRESULT CreateSimulationIB(ID3D10Device* pd3dDevice, Particle* particles)
{
    HRESULT hr;
    WORD* simIndex[NUM_SIMULATE_IB];
    simIndex[PASS_SIMULATE_FORCE] = 0;
    simIndex[PASS_SIMULATE_COLLISION] = 0;
    for (int b = PASS_SIMULATE_STRUCTURAL_AND_SHEAR_SPRING_0; b <= PASS_SIMULATE_SHEAR_SPRING_1; ++b) {
        simIndex[b] = new WORD[g_NumSimIndices];
        g_NumSimulatedPrimitives[b] = 0;
        int index = b - PASS_SIMULATE_STRUCTURAL_AND_SHEAR_SPRING_0;
        int n = 0;
        WORD x = 0, y, i;
        switch (b) {
            case PASS_SIMULATE_STRUCTURAL_AND_SHEAR_SPRING_0:
                // Top left quadrant
                for (y = 0; y < g_Height - 1; y += 2)
                    for (x = 0; x < g_Width - 1; x += 2) {
                        simIndex[b][n] = (y + 0) * g_Width + (x + 0);
                        SetConnectionConfig(particles[simIndex[b][n]], index, STATE_CONNECTION_CONFIG_0);
                        ++n;
                        simIndex[b][n] = (y + 0) * g_Width + (x + 1); ++n;
                        simIndex[b][n] = (y + 1) * g_Width + (x + 0); ++n;
                        simIndex[b][n] = (y + 1) * g_Width + (x + 1); ++n;
                    }
                if (y == g_Height - 1)
                    for (x = 0; x < g_Width - 1; x += 2) {
                        simIndex[b][n] = y * g_Width + (x + 0);
                        if (n % 4 == 0) {
                            if (x + 2 < g_Width - 1)
                                SetConnectionConfig(particles[simIndex[b][n]], index, STATE_CONNECTION_CONFIG_1);
                            else
                                SetConnectionConfig(particles[simIndex[b][n]], index, STATE_CONNECTION_CONFIG_2);
                        }
                        ++n;
                        simIndex[b][n] = y * g_Width + (x + 1); ++n;
                    }
                if (x == g_Width - 1)
                    for (y = 0; y < g_Height - 1; y += 2) {
                        simIndex[b][n] = (y + 0) * g_Width + x;
                        if (n % 4 == 0) {
                            if (y + 2 < g_Height - 1)
                                SetConnectionConfig(particles[simIndex[b][n]], index, STATE_CONNECTION_CONFIG_3);
                            else
                                SetConnectionConfig(particles[simIndex[b][n]], index, STATE_CONNECTION_CONFIG_4);
                        }
                        ++n;
                        simIndex[b][n] = (y + 1) * g_Width + x; ++n;
                    }
                if (x == g_Width - 1 && y == g_Height - 1) {
                    simIndex[b][n] = y * g_Width + x;
                    if (n % 4 == 0)
                        SetConnectionConfig(particles[simIndex[b][n]], index, STATE_CONNECTION_CONFIG_5);
                    ++n;
                }
                break;
            case PASS_SIMULATE_STRUCTURAL_AND_SHEAR_SPRING_1:
                // Bottom right quadrant
                for (y = 1; y < g_Height - 1; y += 2)
                    for (x = 1; x < g_Width - 1; x += 2) {
                        simIndex[b][n] = (y + 0) * g_Width + (x + 0);
                        SetConnectionConfig(particles[simIndex[b][n]], index, STATE_CONNECTION_CONFIG_0);
                        ++n;
                        simIndex[b][n] = (y + 0) * g_Width + (x + 1); ++n;
                        simIndex[b][n] = (y + 1) * g_Width + (x + 0); ++n;
                        simIndex[b][n] = (y + 1) * g_Width + (x + 1); ++n;
                    }
                for (x = 1; x < g_Width - 1; x += 2) {
                    simIndex[b][n] = (x + 0);
                    if (n % 4 == 0) {
                        if (x + 2 < g_Width - 1)
                            SetConnectionConfig(particles[simIndex[b][n]], index, STATE_CONNECTION_CONFIG_1);
                        else if (y == g_Height - 1)
                            SetConnectionConfig(particles[simIndex[b][n]], index, STATE_CONNECTION_CONFIG_1);
                        else
                            SetConnectionConfig(particles[simIndex[b][n]], index, STATE_CONNECTION_CONFIG_2);
                    }
                    ++n;
                    simIndex[b][n] = (x + 1); ++n;
                }
                if (y == g_Height - 1)
                    for (x = 1; x < g_Width - 1; x += 2) {
                        simIndex[b][n] = y * g_Width + (x + 0);
                        if (n % 4 == 0)
                            SetConnectionConfig(particles[simIndex[b][n]], index, STATE_CONNECTION_CONFIG_1);
                        ++n;
                        simIndex[b][n] = y * g_Width + (x + 1); ++n;
                    }
                for (y = 1; y < g_Height - 1; y += 2) {
                    simIndex[b][n] = (y + 0) * g_Width;
                    if (n % 4 == 0) {
                        if (y + 2 < g_Height - 1)
                            SetConnectionConfig(particles[simIndex[b][n]], index, STATE_CONNECTION_CONFIG_3);
                        else if (x == g_Width - 1)
                            SetConnectionConfig(particles[simIndex[b][n]], index, STATE_CONNECTION_CONFIG_4);
                        else
                            SetConnectionConfig(particles[simIndex[b][n]], index, STATE_CONNECTION_CONFIG_4);
                    }
                    ++n;
                    simIndex[b][n] = (y + 1) * g_Width; ++n;
                }
                if (x == g_Width - 1) {
                    for (y = 1; y < g_Height - 1; y += 2) {
                        simIndex[b][n] = (y + 0) * g_Width + x;
                        if (n % 4 == 0)
                            SetConnectionConfig(particles[simIndex[b][n]], index, STATE_CONNECTION_CONFIG_3);
                        ++n;
                        simIndex[b][n] = (y + 1) * g_Width + x; ++n;
                    }
                }
                simIndex[b][n] = 0 * g_Width + 0;
                if (n % 4 == 0)
                    SetConnectionConfig(particles[simIndex[b][n]], index, STATE_CONNECTION_CONFIG_5);
                ++n;
                if (x == g_Width - 1) {
                    simIndex[b][n] = 0 * g_Width + x; ++n;
                    if (y == g_Height - 1) {
                        simIndex[b][n] = y * g_Width + 0;
                        if (n % 4 == 0)
                            SetConnectionConfig(particles[simIndex[b][n]], index, STATE_CONNECTION_CONFIG_5);
                        ++n;
                        simIndex[b][n] = y * g_Width + x; ++n;
                    }
                }
                else if (y == g_Height - 1) {
                    simIndex[b][n] = y * g_Width + 0; ++n;
                }
                break;
            case PASS_SIMULATE_SHEAR_SPRING_0:
                // Top right quadrant
                for (y = 0; y < g_Height - 1; y += 2)
                    for (x = 1; x < g_Width - 1; x += 2) {
                        simIndex[b][n] = (y + 0) * g_Width + (x + 0); ++n;
                        simIndex[b][n] = (y + 0) * g_Width + (x + 1); ++n;
                        simIndex[b][n] = (y + 1) * g_Width + (x + 0); ++n;
                        simIndex[b][n] = (y + 1) * g_Width + (x + 1); ++n;
                        ++g_NumSimulatedPrimitives[b];
                    }
                if (y == g_Height - 1)
                    for (i = 1; i < g_Width; ++i, ++n)
                        simIndex[b][n] = y * g_Width + i;
                if (x == g_Width - 1)
                    for (i = 0; i < y; ++i, ++n)
                        simIndex[b][n] = i * g_Width + x;
                for (y = 0; y < g_Height; ++y, ++n)
                    simIndex[b][n] = y * g_Width;
                break;
            case PASS_SIMULATE_SHEAR_SPRING_1:
                // Bottom left quadrant
                for (y = 1; y < g_Height - 1; y += 2)
                    for (x = 0; x < g_Width - 1; x += 2) {
                        simIndex[b][n] = (y + 0) * g_Width + (x + 0); ++n;
                        simIndex[b][n] = (y + 0) * g_Width + (x + 1); ++n;
                        simIndex[b][n] = (y + 1) * g_Width + (x + 0); ++n;
                        simIndex[b][n] = (y + 1) * g_Width + (x + 1); ++n;
                        ++g_NumSimulatedPrimitives[b];
                    }
                if (y == g_Height - 1)
                    for (i = 0; i < g_Width; ++i, ++n)
                        simIndex[b][n] = y * g_Width + i;
                if (x == g_Width - 1)
                    for (i = 1; i < y; ++i, ++n)
                        simIndex[b][n] = i * g_Width + x;
                for (x = 0; x < g_Width; ++x, ++n)
                    simIndex[b][n] = x;
                break;
            default:
                break;
        }
        assert(n == g_NumVertices);
        for (int u = 0; u < n; ++u) {
            int v;
            for (v = 0; v < n; ++v)
                if (u == simIndex[b][v])
                    break;
            assert(v < n);
        }
        for (; n < g_NumSimIndices; ++n)
            simIndex[b][n] = simIndex[b][n - 1];
        assert(n == g_NumSimIndices);
    }
    for (int b = PASS_SIMULATE_STRUCTURAL_AND_SHEAR_SPRING_0; b <= PASS_SIMULATE_COLLISION; ++b) {
        int size = b == PASS_SIMULATE_COLLISION ? g_NumVertices : g_NumSimIndices;
        D3D10_BUFFER_DESC bufferDesc;
        bufferDesc.ByteWidth = size * sizeof(WORD);
        bufferDesc.Usage = D3D10_USAGE_IMMUTABLE;
        bufferDesc.BindFlags = D3D10_BIND_INDEX_BUFFER;
        bufferDesc.CPUAccessFlags = 0;
        bufferDesc.MiscFlags = 0;
        WORD* indices = new WORD[size];
        if (b == PASS_SIMULATE_STRUCTURAL_AND_SHEAR_SPRING_0)
            memcpy(indices, simIndex[b], bufferDesc.ByteWidth);
        else for (short j = 0; j < size; ++j) {
            short v;
            for (v = 0; v < g_NumSimIndices; ++v)
                if (simIndex[b - 1][v] == (b == PASS_SIMULATE_COLLISION ? j : simIndex[b][j]))
                    break;
            assert(v < g_NumSimIndices);
            indices[j] = v;
        }
        D3D10_SUBRESOURCE_DATA initialData;
        initialData.pSysMem = indices;
        V_RETURN(pd3dDevice->CreateBuffer(&bufferDesc, &initialData, &g_SimulateIB[b]));
        delete [] indices;
    }
    for (int b = PASS_SIMULATE_STRUCTURAL_AND_SHEAR_SPRING_0; b <= PASS_SIMULATE_SHEAR_SPRING_1; ++b)
        delete [] simIndex[b];

    return S_OK;
}

HRESULT CreateTangentSpaceIB(ID3D10Device* pd3dDevice)
{
    HRESULT hr;
    int size = 6 * g_NumVertices;
    D3D10_BUFFER_DESC bufferDesc;
    bufferDesc.ByteWidth = size * sizeof(WORD);
    bufferDesc.Usage = D3D10_USAGE_IMMUTABLE;
    bufferDesc.BindFlags = D3D10_BIND_INDEX_BUFFER;
    bufferDesc.CPUAccessFlags = 0;
    bufferDesc.MiscFlags = 0;
    WORD (*indices)[6] = new WORD[size / 6][6];
    int n = 0;
    for (short y = 0; y < g_Height; ++y)
        for (short x = 0; x < g_Width; ++x) {
            indices[n][0] =                         (y + 0) * g_Width +                        (x + 0);
            indices[n][1] =                         (y + 0) * g_Width +           (x == 0 ? x : x - 1);
            indices[n][2] =            (y == 0 ? y : y - 1) * g_Width +                        (x + 0);
            indices[n][3] =                         (y + 0) * g_Width + (x == g_Width - 1 ? x : x + 1);
            indices[n][4] = (y == g_Height - 1 ? y : y + 1) * g_Width +                        (x + 0);
            indices[n][5] = 0;
            ++n;
        }
    D3D10_SUBRESOURCE_DATA initialData;
    initialData.pSysMem = indices;
    V_RETURN(pd3dDevice->CreateBuffer(&bufferDesc, &initialData, &g_NormalTangentIB));
    delete [] indices;
    return S_OK;
}

HRESULT CreateRenderingIB(ID3D10Device* pd3dDevice)
{
    HRESULT hr;
    g_NumIndices = 2 * (g_Width - 1) * (g_Height - 1) * 3;
    int size = g_NumIndices;
    D3D10_BUFFER_DESC bufferDesc;
    bufferDesc.ByteWidth = size * sizeof(WORD);
    bufferDesc.Usage = D3D10_USAGE_IMMUTABLE;
    bufferDesc.BindFlags = D3D10_BIND_INDEX_BUFFER;
    bufferDesc.CPUAccessFlags = 0;
    bufferDesc.MiscFlags = 0;
    WORD (*indices)[3] = new WORD[size / 3][3];
    const int swathWidth = 10;
    int n = 0;
    for (short x0 = 0; x0 < g_Width - 1; x0 += swathWidth) {
        short x1 = x0 + swathWidth;
        for (short y = 0; y < g_Height - 1; ++y)
            for (short x = x0; (x < g_Width - 1) && (x < x1); ++x) {
                indices[n][0] = (y + 1) * g_Width + (x + 0);
                indices[n][1] = (y + 0) * g_Width + (x + 0);
                indices[n][2] = (y + 1) * g_Width + (x + 1);
                ++n;
                indices[n][0] = (y + 0) * g_Width + (x + 0);
                indices[n][1] = (y + 0) * g_Width + (x + 1);
                indices[n][2] = (y + 1) * g_Width + (x + 1);
                ++n;
            }
    }
    D3D10_SUBRESOURCE_DATA initialData;
    initialData.pSysMem = indices;
    V_RETURN(pd3dDevice->CreateBuffer(&bufferDesc, &initialData, &g_RenderIB));
    delete [] indices;
    return S_OK;
}

//--------------------------------------------------------------------------------------
// Create vertex buffers 
//--------------------------------------------------------------------------------------
HRESULT CreateVertexBuffers(ID3D10Device* pd3dDevice, Particle* particles)
{
    HRESULT hr;
    V_RETURN(CreatePositionVB(pd3dDevice, particles));
    V_RETURN(CreateTexCoordVB(pd3dDevice));
    V_RETURN(CreateParticleVB(pd3dDevice));
    V_RETURN(CreateTangentSpaceVB(pd3dDevice));
    V_RETURN(CreateCutterEdgeVB(pd3dDevice));    
    V_RETURN(CreateAnchorVB(pd3dDevice));  
    return S_OK;
}

HRESULT CreatePositionVB(ID3D10Device* pd3dDevice, Particle* particles)
{
    HRESULT hr;
    D3D10_BUFFER_DESC bufferDesc;
    bufferDesc.ByteWidth = g_NumVertices * sizeof(Particle);
    bufferDesc.Usage = D3D10_USAGE_IMMUTABLE;
    bufferDesc.BindFlags = D3D10_BIND_VERTEX_BUFFER;
    bufferDesc.CPUAccessFlags = 0;
    bufferDesc.MiscFlags = 0;
    D3D10_SUBRESOURCE_DATA initialData;
    initialData.pSysMem = particles;
    V_RETURN(pd3dDevice->CreateBuffer(&bufferDesc, &initialData, &g_InitialPositionVB));
    return S_OK;
}

HRESULT CreateTexCoordVB(ID3D10Device* pd3dDevice)
{
    HRESULT hr;
    D3D10_BUFFER_DESC bufferDesc;
    bufferDesc.ByteWidth = g_NumVertices * sizeof(TexCoord);
    bufferDesc.Usage = D3D10_USAGE_IMMUTABLE;
    bufferDesc.BindFlags = D3D10_BIND_VERTEX_BUFFER;
    bufferDesc.CPUAccessFlags = 0;
    bufferDesc.MiscFlags = 0;
    TexCoord* texCoords = new TexCoord[g_NumVertices];
    int v = 0;
    for (int y = 0; y < g_Height; ++y)
        for (int x = 0; x < g_Width; ++x) {
            texCoords[v][0] = g_TexCoordScale * x / (float)(g_Width - 1);
            texCoords[v][1] = g_TexCoordScale * y / (float)(g_Height - 1);
            ++v;
        }
    D3D10_SUBRESOURCE_DATA initialData;
    initialData.pSysMem = texCoords;
    V_RETURN(pd3dDevice->CreateBuffer(&bufferDesc, &initialData, &g_TexCoordVB));
    delete [] texCoords;
    return S_OK;
}

HRESULT CreateParticleVB(ID3D10Device* pd3dDevice)
{
    HRESULT hr;
    D3D10_BUFFER_DESC bufferDesc;
    bufferDesc.ByteWidth = g_NumVertices * sizeof(Particle);
    bufferDesc.Usage = D3D10_USAGE_DEFAULT;
    bufferDesc.BindFlags = D3D10_BIND_VERTEX_BUFFER | D3D10_BIND_STREAM_OUTPUT | D3D10_BIND_SHADER_RESOURCE | D3D10_BIND_RENDER_TARGET;
    bufferDesc.CPUAccessFlags = 0;
    bufferDesc.MiscFlags = 0;
    for (int i = 0; i < 3; ++i)
        V_RETURN(pd3dDevice->CreateBuffer(&bufferDesc, 0, &g_ParticleVB[i]));
    D3D10_SHADER_RESOURCE_VIEW_DESC srDesc;
    srDesc.Format = DXGI_FORMAT_R32G32B32A32_FLOAT;
    srDesc.ViewDimension = D3D10_SRV_DIMENSION_BUFFER;
    srDesc.Buffer.ElementOffset = 0;
    srDesc.Buffer.ElementWidth = g_NumVertices;
    for (int i = 0; i < 3; ++i)
        V_RETURN(pd3dDevice->CreateShaderResourceView(g_ParticleVB[i], &srDesc, &g_ParticleSRV[i]));
    D3D10_RENDER_TARGET_VIEW_DESC rtDesc;
    rtDesc.Format = DXGI_FORMAT_R32G32B32A32_FLOAT;
    rtDesc.ViewDimension = D3D10_RTV_DIMENSION_BUFFER;
    rtDesc.Buffer.ElementOffset = 0;
    rtDesc.Buffer.ElementWidth = g_NumVertices;
    for (int i = 0; i < 3; ++i)
        V_RETURN(pd3dDevice->CreateRenderTargetView(g_ParticleVB[i], &rtDesc, &g_ParticleRTV[i]));
    return S_OK;
}

HRESULT CreateTangentSpaceVB(ID3D10Device* pd3dDevice)
{
    HRESULT hr;
    D3D10_BUFFER_DESC bufferDesc;
    bufferDesc.ByteWidth = g_NumVertices * sizeof(NormalTangent);
    bufferDesc.Usage = D3D10_USAGE_DEFAULT;
    bufferDesc.BindFlags = D3D10_BIND_VERTEX_BUFFER | D3D10_BIND_STREAM_OUTPUT;
    bufferDesc.CPUAccessFlags = 0;
    bufferDesc.MiscFlags = 0;
    V_RETURN(pd3dDevice->CreateBuffer(&bufferDesc, 0, &g_NormalTangentVB));
    return S_OK;
}

HRESULT CreateAnchorVB(ID3D10Device* pd3dDevice)
{
    HRESULT hr;
    D3D10_BUFFER_DESC bufferDesc;
    bufferDesc.ByteWidth = g_NumAnchorPoints * sizeof(AnchorPoint);
    bufferDesc.Usage = D3D10_USAGE_DYNAMIC;
    bufferDesc.BindFlags = D3D10_BIND_VERTEX_BUFFER;
    bufferDesc.CPUAccessFlags = D3D10_CPU_ACCESS_WRITE;
    bufferDesc.MiscFlags = 0;
    V_RETURN(pd3dDevice->CreateBuffer(&bufferDesc, 0, &g_AnchorVB));
    AnchorPoint* anchors;
    V_RETURN(g_AnchorVB->Map(D3D10_MAP_WRITE_DISCARD, 0, (void **) &anchors));
    for (int i = 0; i < g_NumAnchorPoints; ++i)
        anchors[i].Coordinate = 2 * (g_AnchorPoint[i].y * g_Width + g_AnchorPoint[i].x + 0.5f) / static_cast<float>(g_NumVertices) - 1;
    g_AnchorVB->Unmap();
    const D3D10_INPUT_ELEMENT_DESC elements[] =
    {
        { "Coordinate", 0, DXGI_FORMAT_R32_FLOAT, 0, offsetof(AnchorPoint, Coordinate), D3D10_INPUT_PER_VERTEX_DATA, 0 },
    };
    D3D10_PASS_DESC passDesc;    
    V_RETURN(g_Effect->GetTechniqueByName("SimulateCloth")->GetPassByName("TransformAnchorPoints")->GetDesc(&passDesc));
    V_RETURN(pd3dDevice->CreateInputLayout(elements, sizeof(elements) / sizeof(D3D10_INPUT_ELEMENT_DESC), passDesc.pIAInputSignature, passDesc.IAInputSignatureSize, &g_AnchorIL));
    return S_OK;
}

HRESULT CreateCutterEdgeVB(ID3D10Device* pd3dDevice)
{
    HRESULT hr;
    int numElements = MAX_CUTTER_TRIANGLES + 1;
    D3D10_BUFFER_DESC bufferDesc;
    bufferDesc.ByteWidth = numElements * sizeof(D3DXVECTOR4);
    bufferDesc.Usage = D3D10_USAGE_DEFAULT;
    bufferDesc.BindFlags = D3D10_BIND_RENDER_TARGET;
    bufferDesc.CPUAccessFlags = 0;
    bufferDesc.MiscFlags = 0;
    V_RETURN(pd3dDevice->CreateBuffer(&bufferDesc, 0, &g_CutterEdgeVB));
    D3D10_RENDER_TARGET_VIEW_DESC rtDesc;
    rtDesc.Format = DXGI_FORMAT_R32G32B32A32_FLOAT;
    rtDesc.ViewDimension = D3D10_RTV_DIMENSION_BUFFER;
    rtDesc.Buffer.ElementOffset = 0;
    rtDesc.Buffer.ElementWidth = numElements;
    V_RETURN(pd3dDevice->CreateRenderTargetView(g_CutterEdgeVB, &rtDesc, &g_CutterEdgeRTV));
    return S_OK;
}

//--------------------------------------------------------------------------------------
// Create input layouts 
//--------------------------------------------------------------------------------------
HRESULT CreateInputLayouts(ID3D10Device* pd3dDevice)
{
    HRESULT hr;
    V_RETURN(CreateApplyForcesIL(pd3dDevice));
    V_RETURN(CreateSatisfyConstraintsIL(pd3dDevice));
    V_RETURN(CreateRenderClothIL(pd3dDevice));
    V_RETURN(CreateRenderTangentSpaceIL(pd3dDevice));
    return S_OK;
}

HRESULT CreateApplyForcesIL(ID3D10Device* pd3dDevice)
{
    HRESULT hr;
    const D3D10_INPUT_ELEMENT_DESC elements[] =
    {
        { "State",       0, DXGI_FORMAT_R32_UINT,        0, offsetof(Particle, State),       D3D10_INPUT_PER_VERTEX_DATA, 0 },
        { "Position",    0, DXGI_FORMAT_R32G32B32_FLOAT, 0, offsetof(Particle, Position),    D3D10_INPUT_PER_VERTEX_DATA, 0 },
        { "OldState",    0, DXGI_FORMAT_R32_UINT,        1, offsetof(Particle, State),       D3D10_INPUT_PER_VERTEX_DATA, 0 },
        { "OldPosition", 0, DXGI_FORMAT_R32G32B32_FLOAT, 1, offsetof(Particle, Position),    D3D10_INPUT_PER_VERTEX_DATA, 0 },
        { "Normal",      0, DXGI_FORMAT_R32G32B32_FLOAT, 2, offsetof(NormalTangent, Normal), D3D10_INPUT_PER_VERTEX_DATA, 0 },
    };
    D3D10_PASS_DESC passDesc;    
    V_RETURN(g_Effect->GetTechniqueByName("SimulateCloth")->GetPassByName("ApplyForces")->GetDesc(&passDesc));
    V_RETURN(pd3dDevice->CreateInputLayout(elements, sizeof(elements) / sizeof(D3D10_INPUT_ELEMENT_DESC), passDesc.pIAInputSignature, passDesc.IAInputSignatureSize, &g_ApplyForcesIL));
    return S_OK;
}

HRESULT CreateSatisfyConstraintsIL(ID3D10Device* pd3dDevice)
{
    HRESULT hr;
    const D3D10_INPUT_ELEMENT_DESC elements[] =
    {
        { "State",    0, DXGI_FORMAT_R32_UINT,        0, offsetof(Particle, State),    D3D10_INPUT_PER_VERTEX_DATA, 0 },
        { "Position", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, offsetof(Particle, Position), D3D10_INPUT_PER_VERTEX_DATA, 0 },
    };
    D3D10_PASS_DESC passDesc;
    V_RETURN(g_Effect->GetTechniqueByName("SimulateCloth")->GetPassByName("SatisfyStructuralAndShearSpringConstraints")->GetDesc(&passDesc));
    V_RETURN(pd3dDevice->CreateInputLayout(elements, sizeof(elements) / sizeof(D3D10_INPUT_ELEMENT_DESC), passDesc.pIAInputSignature, passDesc.IAInputSignatureSize, &g_SatisfyConstraintsIL));
    return S_OK;
}

HRESULT CreateRenderClothIL(ID3D10Device* pd3dDevice)
{
    HRESULT hr;
    const D3D10_INPUT_ELEMENT_DESC elements[] =
    {
        { "State",    0, DXGI_FORMAT_R32_UINT,        0, offsetof(Particle, State),         D3D10_INPUT_PER_VERTEX_DATA, 0 },
        { "Position", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, offsetof(Particle, Position),      D3D10_INPUT_PER_VERTEX_DATA, 0 },
        { "Normal",   0, DXGI_FORMAT_R32G32B32_FLOAT, 1, offsetof(NormalTangent, Normal),   D3D10_INPUT_PER_VERTEX_DATA, 0 },
        { "TangentX", 0, DXGI_FORMAT_R32G32B32_FLOAT, 1, offsetof(NormalTangent, TangentX), D3D10_INPUT_PER_VERTEX_DATA, 0 },
        { "TexCoord", 0, DXGI_FORMAT_R32G32_FLOAT,    2, 0,                                 D3D10_INPUT_PER_VERTEX_DATA, 0 },
    };
    D3D10_PASS_DESC passDesc;    
    V_RETURN(g_Effect->GetTechniqueByName("RenderCloth")->GetPassByIndex(0)->GetDesc(&passDesc));
    V_RETURN(pd3dDevice->CreateInputLayout(elements, sizeof(elements) / sizeof(D3D10_INPUT_ELEMENT_DESC), passDesc.pIAInputSignature, passDesc.IAInputSignatureSize, &g_RenderClothIL));
    return S_OK;
}

HRESULT CreateRenderTangentSpaceIL(ID3D10Device* pd3dDevice)
{
    HRESULT hr;
    const D3D10_INPUT_ELEMENT_DESC elements[] =
    {
        { "State",    0, DXGI_FORMAT_R32_UINT,        0, offsetof(Particle, State),         D3D10_INPUT_PER_VERTEX_DATA, 0 },
        { "Position", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, offsetof(Particle, Position),      D3D10_INPUT_PER_VERTEX_DATA, 0 },
        { "Normal",   0, DXGI_FORMAT_R32G32B32_FLOAT, 1, offsetof(NormalTangent, Normal),   D3D10_INPUT_PER_VERTEX_DATA, 0 },
        { "TangentX", 0, DXGI_FORMAT_R32G32B32_FLOAT, 1, offsetof(NormalTangent, TangentX), D3D10_INPUT_PER_VERTEX_DATA, 0 },
    };
    D3D10_PASS_DESC passDesc;
    V_RETURN(g_Effect->GetTechniqueByName("RenderTangentSpace")->GetPassByIndex(0)->GetDesc(&passDesc));
    V_RETURN(pd3dDevice->CreateInputLayout(elements, sizeof(elements) / sizeof(D3D10_INPUT_ELEMENT_DESC), passDesc.pIAInputSignature, passDesc.IAInputSignatureSize, &g_RenderTangentSpaceIL));
    return S_OK;
}

//--------------------------------------------------------------------------------------
// Create textures 
//--------------------------------------------------------------------------------------
HRESULT CreateTextures(ID3D10Device* pd3dDevice)
{
    HRESULT hr;
    WCHAR str[MAX_PATH];

    // Cloth
    V_RETURN(NVUTFindDXSDKMediaFileCch(str, MAX_PATH,  L".\\Media\\cloth.dds"));
    V_RETURN(D3DX10CreateShaderResourceViewFromFile(pd3dDevice, str, 0, 0, &g_ClothDiffuseTexture, &hr));
    V_RETURN(NVUTFindDXSDKMediaFileCch(str, MAX_PATH,  L".\\Media\\cloth_normal.dds"));
    V_RETURN(D3DX10CreateShaderResourceViewFromFile(pd3dDevice, str, 0, 0, &g_ClothNormalMap, &hr));

    // Floor
    V_RETURN(NVUTFindDXSDKMediaFileCch(str, MAX_PATH,  L".\\Media\\lichen6.dds"));
    V_RETURN(D3DX10CreateShaderResourceViewFromFile(pd3dDevice, str, 0, 0, &g_CellDiffuseTexture[0], &hr));
    V_RETURN(NVUTFindDXSDKMediaFileCch(str, MAX_PATH,  L".\\Media\\lichen6_normal.dds"));
    V_RETURN(D3DX10CreateShaderResourceViewFromFile(pd3dDevice, str, 0, 0, &g_CellNormalMap[0], &hr));

    // Walls and ceiling
    V_RETURN(NVUTFindDXSDKMediaFileCch(str, MAX_PATH,  L".\\Media\\lichen1.dds"));
    V_RETURN(D3DX10CreateShaderResourceViewFromFile(pd3dDevice, str, 0, 0, &g_CellDiffuseTexture[1], &hr));
    V_RETURN(NVUTFindDXSDKMediaFileCch(str, MAX_PATH,  L".\\Media\\lichen1_normal.dds"));
    V_RETURN(D3DX10CreateShaderResourceViewFromFile(pd3dDevice, str, 0, 0, &g_CellNormalMap[1], &hr));

    g_PlaneDiffuseTexture[0] = g_CellDiffuseTexture[0];
    g_PlaneNormalMap[0] = g_CellNormalMap[0];
    for (int i = 1; i < g_NumPlanes; ++i) {
        g_PlaneDiffuseTexture[i] = g_CellDiffuseTexture[1];
        g_PlaneNormalMap[i] = g_CellNormalMap[1];
    }

    return S_OK;
}

//--------------------------------------------------------------------------------------
// Create rasterizer states 
//--------------------------------------------------------------------------------------
HRESULT CreateRasterizerStates(ID3D10Device* pd3dDevice)
{
    D3D10_RASTERIZER_DESC rasterizerState;
    ZeroMemory(&rasterizerState, sizeof(D3D10_RASTERIZER_DESC));
    rasterizerState.FillMode = D3D10_FILL_WIREFRAME;
    rasterizerState.CullMode = D3D10_CULL_NONE;
	rasterizerState.MultisampleEnable = true;
    pd3dDevice->CreateRasterizerState(&rasterizerState, &g_WireframeRS);
    rasterizerState.FillMode = D3D10_FILL_SOLID;
    pd3dDevice->CreateRasterizerState(&rasterizerState, &g_SolidRS);

    return S_OK;
}

//--------------------------------------------------------------------------------------
// Create scene 
//--------------------------------------------------------------------------------------
void InitPlanes()
{
    for (int i = 0; i < g_NumPlanes; ++i) {
        D3DXVECTOR3& normal = g_Plane[i].Normal;
        D3DXVECTOR3 p = -g_Plane[i].Distance * normal;
        D3DXQUATERNION quat;
        if (normal.x || normal.y || normal.z < 0) {
            if (normal.x || normal.y) {
                D3DXVECTOR3 v(-normal.y, normal.x, 0);
                D3DXQuaternionRotationAxis(&quat, &v, acosf(normal.z));
            }
            else
                quat = D3DXQUATERNION(1, 0, 0, 0);
            D3DXMatrixAffineTransformation(&g_PlaneWorld[i], 1, 0, &quat, &p);
        }
        else
            D3DXMatrixTranslation(&g_PlaneWorld[i], p.x, p.y, p.z);
        float size = 7.5f;
        D3DXMATRIX scaling;
        D3DXMatrixScaling(&scaling, size, size, size);
        g_PlaneWorld[i] = scaling * g_PlaneWorld[i];
    }
}

HRESULT CreatePlaneMesh(ID3D10Device* pd3dDevice)
{
    HRESULT hr;
    UINT numIndices = 2 * 3;
    WORD* indices = new WORD[numIndices];
    indices[0] = 0; indices[1] = 2; indices[2] = 1;
    indices[3] = 0; indices[4] = 3; indices[5] = 2;
    UINT numVertices = 4;
    MeshVertex* vertices = new MeshVertex[numVertices];
    float tile = 4;
    vertices[0].Position = D3DXVECTOR3(-1, 1, 0);
    vertices[0].Normal = D3DXVECTOR3(0, 0, 1);
    vertices[0].TangentX = D3DXVECTOR3(1, 0, 0);
    vertices[0].TexCoord = D3DXVECTOR2(0, 0);
    vertices[1].Position = D3DXVECTOR3(1, 1, 0);
    vertices[1].Normal = vertices[0].Normal;
    vertices[1].TangentX = vertices[0].TangentX;
    vertices[1].TexCoord = D3DXVECTOR2(tile, 0);
    vertices[2].Position = D3DXVECTOR3(1, -1, 0);
    vertices[2].Normal = vertices[0].Normal;
    vertices[2].TangentX = vertices[0].TangentX;
    vertices[2].TexCoord = D3DXVECTOR2(tile, tile);
    vertices[3].Position = D3DXVECTOR3(-1, -1, 0);
    vertices[3].Normal = vertices[0].Normal;
    vertices[3].TangentX = vertices[0].TangentX;
    vertices[3].TexCoord = D3DXVECTOR2(0, tile);
    V_RETURN(CreateShapeMesh(pd3dDevice, &g_PlaneMesh, vertices, numVertices, indices, numIndices));
    delete [] vertices;
    delete [] indices;
    return S_OK;
}

void InitSpheres()
{
    for (int i = 0; i < g_NumSpheres; ++i) {
        D3DXMatrixIdentity(&g_SphereWorld[i]);
        g_SphereWorld[i](3, 0) = g_Sphere[i].Center.x;
        g_SphereWorld[i](3, 1) = g_Sphere[i].Center.y;
        g_SphereWorld[i](3, 2) = g_Sphere[i].Center.z;
        g_SphereWorld[i](0, 0) = g_Sphere[i].Radius;
        g_SphereWorld[i](1, 1) = g_Sphere[i].Radius;
        g_SphereWorld[i](2, 2) = g_Sphere[i].Radius;
    }
}

HRESULT CreateSphereMesh(ID3D10Device* pd3dDevice)
{
    HRESULT hr;
    if (g_SphereMesh == 0) {
        float radius[] = { 1, 1 };
        V_RETURN(CreateCapsuleMesh(pd3dDevice, 0, radius, 32, 32, &g_SphereMesh));
    }
    return S_OK;
}

void InitCapsules()
{
    for (int i = 0; i < g_NumCapsules; ++i) {
        D3DXVECTOR3 rotAxis(g_Capsule[i].Axis.y, - g_Capsule[i].Axis.x, 0);
        D3DXVECTOR3 rotAxisN;
        D3DXVec3Normalize(&rotAxisN, &rotAxis);
        D3DXMatrixRotationAxis(&g_CapsuleWorld[i], &rotAxisN, acosf(g_Capsule[i].Axis.z));
        float length = 0.5f * g_Capsule[i].Length;
        g_CapsuleWorld[i](3, 0) = g_Capsule[i].Origin.x + length * g_Capsule[i].Axis.x;
        g_CapsuleWorld[i](3, 1) = g_Capsule[i].Origin.y + length * g_Capsule[i].Axis.y;
        g_CapsuleWorld[i](3, 2) = g_Capsule[i].Origin.z + length * g_Capsule[i].Axis.z;
    }
}

HRESULT CreateCapsuleMeshes(ID3D10Device* pd3dDevice)
{
    HRESULT hr;
    for (int i = 0; i < g_NumCapsules; ++i)
        V_RETURN(CreateCapsuleMesh(pd3dDevice, g_Capsule[i].Length, g_Capsule[i].Radius, 32, 32, &g_CapsuleMesh[i]));
    return S_OK;
}

void InitEllipsoids()
{
    for (int i = 0; i < g_NumEllipsoids; ++i) {
        D3DXMatrixIdentity(&g_EllipsoidWorld[i]);
        g_EllipsoidWorld[i](3, 0) = g_Ellipsoid[i].Transform[0].x;
        g_EllipsoidWorld[i](3, 1) = g_Ellipsoid[i].Transform[0].y;
        g_EllipsoidWorld[i](3, 2) = g_Ellipsoid[i].Transform[0].z;
        g_EllipsoidWorld[i](0, 0) = g_Ellipsoid[i].Transform[1].x;
        g_EllipsoidWorld[i](1, 1) = g_Ellipsoid[i].Transform[1].y;
        g_EllipsoidWorld[i](2, 2) = g_Ellipsoid[i].Transform[1].z;
        D3DXMATRIX worldInv;
        D3DXMatrixInverse(&worldInv, 0, &g_EllipsoidWorld[i]);
        for (int x = 0; x < 3; ++x)
            for (int y = 0; y < 4; ++y)
                g_Ellipsoid[i].Transform[x][y] = worldInv(y, x);
    }
}

HRESULT CreateCapsuleMesh(ID3D10Device* pd3dDevice, float length, float radius[2], WORD numSlices, WORD numStacks, ID3DX10Mesh** mesh)
{
    numSlices = 2 * (numSlices / 2);
    DWORD numFaces = 2 * numStacks * numSlices;
    UINT numIndices = 3 * numFaces;
    WORD* indices = new WORD[numIndices];
    WORD* ind = indices;
    DWORD numVertices = numSlices * numStacks + 2;
    MeshVertex* vertices = new MeshVertex[numVertices];
    MeshVertex* vert = vertices;
	float sliceAngleStep = D3DX_PI / numSlices;
	float stackAngleStep = 2 * D3DX_PI / numStacks;
	WORD index = 0;
    WORD offset = length == 0 ? 0 : 1;
	for (WORD s = 0; s <= numSlices + offset; ++s) {
        WORD slice = s <= numSlices / 2 ? s : s - offset;
        float rad = s <= numSlices / 2 ? radius[0] : radius[1];
		float r = rad * sinf(slice * sliceAngleStep);
		float z = rad * cosf(slice * sliceAngleStep);
		for (WORD stack = 0; stack < numStacks; ++stack) {
			float x = r * sinf(stack * stackAngleStep);
			float y = r * cosf(stack * stackAngleStep);
            vert->Position.x = x;
			vert->Position.y = y;
			vert->Position.z = z;
            D3DXVec3Normalize(&vert->Normal, &vert->Position);
			vert->Position.z += (s <= numSlices / 2 ? + length : - length) / 2;
            D3DXVECTOR3 tangent(y, -x, 0);
            D3DXVec3Normalize(&vert->TangentX, &tangent);
			vert->TexCoord.x = stack / static_cast<float>(numStacks);
			vert->TexCoord.y = slice / static_cast<float>(numSlices);
            ++vert;
            if (slice == 0) {
		        for (WORD stack = 1; stack < numStacks; ++stack) {
				    *ind++ = index;
				    *ind++ = index + stack + 1;
				    *ind++ = index + stack;
                }
				*ind++ = index;
				*ind++ = index + 1;
				*ind++ = index + numStacks;
				++index;
                break;
            }
            else if (slice == numSlices) {
		        for (WORD stack = 1; stack < numStacks; ++stack) {
				    *ind++ = index;
				    *ind++ = index - stack - 1;
				    *ind++ = index - stack;
                }
				*ind++ = index;
				*ind++ = index - 1;
				*ind++ = index - numStacks;
				++index;
                break;
            }
            else {
                if (slice != numSlices - 1)
                    if (stack < numStacks - 1) {
				        *ind++ = index;
				        *ind++ = index + numStacks + 1;
				        *ind++ = index + numStacks;
				        *ind++ = index + numStacks + 1;
				        *ind++ = index;
				        *ind++ = index + 1;
			        }
                    else {
				        *ind++ = index;
				        *ind++ = index + 1;
				        *ind++ = index + numStacks;
				        *ind++ = index + 1;
				        *ind++ = index;
				        *ind++ = index - (numStacks - 1);
                    }
                ++index;
            }
		}
	}
    HRESULT hr;
    V_RETURN(CreateShapeMesh(pd3dDevice, mesh, vertices, numVertices, indices, numIndices));
    delete [] vertices;
    delete [] indices;
    return S_OK;
}

HRESULT CreateShapeMesh(ID3D10Device* pd3dDevice, ID3DX10Mesh** mesh,
                        MeshVertex* vertices, UINT numVertices, WORD* indices, UINT numIndices)
{
    HRESULT hr;
    const D3D10_INPUT_ELEMENT_DESC elements[] = {
        { "Position", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, offsetof(MeshVertex, Position), D3D10_INPUT_PER_VERTEX_DATA, 0 },
        { "Normal",   0, DXGI_FORMAT_R32G32B32_FLOAT, 0, offsetof(MeshVertex, Normal),   D3D10_INPUT_PER_VERTEX_DATA, 0 },
        { "TangentX", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, offsetof(MeshVertex, TangentX), D3D10_INPUT_PER_VERTEX_DATA, 0 },
        { "TexCoord", 0, DXGI_FORMAT_R32G32_FLOAT,    0, offsetof(MeshVertex, TexCoord), D3D10_INPUT_PER_VERTEX_DATA, 0 },
    };
    V_RETURN(D3DX10CreateMesh(pd3dDevice,
                              elements, sizeof(elements) / sizeof(D3D10_INPUT_ELEMENT_DESC),
                              elements[0].SemanticName,
                              numVertices, numIndices/3,
                              0, mesh));
    (*mesh)->SetVertexData(0, vertices);
    (*mesh)->SetIndexData(indices, numIndices);
    (*mesh)->CommitToDevice();
    if (g_RenderMeshIL == 0) {
        D3D10_PASS_DESC passDesc;    
        V_RETURN(g_Effect->GetTechniqueByName("RenderMesh")->GetPassByIndex(0)->GetDesc(&passDesc));
        V_RETURN(pd3dDevice->CreateInputLayout(elements, sizeof(elements) / sizeof(D3D10_INPUT_ELEMENT_DESC), passDesc.pIAInputSignature, passDesc.IAInputSignatureSize, &g_RenderMeshIL));
    }
    return S_OK;
}

//--------------------------------------------------------------------------------------
// Release D3D10 resources created in OnD3D10ResizedSwapChain 
//--------------------------------------------------------------------------------------
void CALLBACK OnD3D10SwapChainReleasing(void* pUserContext)
{
    g_DialogResourceManager.OnD3D10ReleasingSwapChain();
    SAFE_RELEASE(g_BackBufferRTV);
    SAFE_RELEASE(g_BackBufferDSV);
}

//--------------------------------------------------------------------------------------
// Release D3D10 resources created in OnD3D10CreateDevice 
//--------------------------------------------------------------------------------------
void CALLBACK OnD3D10DestroyDevice(void* pUserContext)
{
    g_DialogResourceManager.OnD3D10DestroyDevice();
    g_SettingsDlg.OnD3D10DestroyDevice();
    SAFE_RELEASE(g_AnchorIL);
    SAFE_RELEASE(g_ApplyForcesIL);
    SAFE_RELEASE(g_SatisfyConstraintsIL);
    SAFE_RELEASE(g_RenderTangentSpaceIL);
    SAFE_RELEASE(g_RenderClothIL);
    SAFE_RELEASE(g_InitialPositionVB);
    SAFE_RELEASE(g_TexCoordVB);
    SAFE_RELEASE(g_CutterEdgeVB);
    SAFE_RELEASE(g_CutterEdgeCB);
    SAFE_RELEASE(g_NormalTangentVB);
    SAFE_RELEASE(g_AnchorVB);
    for (int i = 0; i < 3; ++i) {
        SAFE_RELEASE(g_ParticleVB[i]);
        SAFE_RELEASE(g_ParticleSRV[i]);
        SAFE_RELEASE(g_ParticleRTV[i]);
    }
    for (int i = 0; i < sizeof(g_CellDiffuseTexture) / sizeof(g_CellDiffuseTexture[0]); ++i)
        SAFE_RELEASE(g_CellDiffuseTexture[i]);
    for (int i = 0; i < sizeof(g_CellNormalMap) / sizeof(g_CellNormalMap[0]); ++i)
        SAFE_RELEASE(g_CellNormalMap[i]);
    SAFE_RELEASE(g_ClothDiffuseTexture);
    SAFE_RELEASE(g_ClothNormalMap);
    SAFE_RELEASE(g_CutterEdgeRTV);
    for (int i = 0; i < NUM_SIMULATE_IB; ++i)
        SAFE_RELEASE(g_SimulateIB[i]);
    SAFE_RELEASE(g_NormalTangentIB);
    SAFE_RELEASE(g_RenderIB);
    SAFE_RELEASE(g_WireframeRS);
    SAFE_RELEASE(g_SolidRS);
    SAFE_RELEASE(g_Font);
    SAFE_RELEASE(g_Sprite);
    SAFE_RELEASE(g_Effect);
    SAFE_DELETE(g_TxtHelper);
    SAFE_RELEASE(g_RenderMeshIL);
    SAFE_RELEASE(g_PlaneMesh);
    SAFE_RELEASE(g_SphereMesh);
    for (int i = 0; i < g_NumCapsules; ++i)
        SAFE_RELEASE(g_CapsuleMesh[i]);
}
