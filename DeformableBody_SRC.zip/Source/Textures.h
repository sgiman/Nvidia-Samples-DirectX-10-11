//----------------------------------------------------------------------------------
// File:   Textures.h
// Author: Nuttapong Chentanez
// Email:  sdkfeedback@nvidia.com
//
// Deformable Physics is based on Meshless Deformations Based on Shape Matching by M. Mueller, B. Heidelberger, M. Teschner, M. Gross.
// Collision detection and response is done with cube map look up.
// All run-time computation is done on the GPU.
// 
// Copyright (c) 2007 NVIDIA Corporation. All rights reserved.
//
// TO  THE MAXIMUM  EXTENT PERMITTED  BY APPLICABLE  LAW, THIS SOFTWARE  IS PROVIDED
// *AS IS*  AND NVIDIA AND  ITS SUPPLIERS DISCLAIM  ALL WARRANTIES,  EITHER  EXPRESS
// OR IMPLIED, INCLUDING, BUT NOT LIMITED  TO, IMPLIED WARRANTIES OF MERCHANTABILITY
// AND FITNESS FOR A PARTICULAR PURPOSE.  IN NO EVENT SHALL  NVIDIA OR ITS SUPPLIERS
// BE  LIABLE  FOR  ANY  SPECIAL,  INCIDENTAL,  INDIRECT,  OR  CONSEQUENTIAL DAMAGES
// WHATSOEVER (INCLUDING, WITHOUT LIMITATION,  DAMAGES FOR LOSS OF BUSINESS PROFITS,
// BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION, OR ANY OTHER PECUNIARY LOSS)
// ARISING OUT OF THE  USE OF OR INABILITY  TO USE THIS SOFTWARE, EVEN IF NVIDIA HAS
// BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
//
//

//--------------------------------------------------------------------------------------------------------------------------
//      READ THIS FIRST
// See the "READ THIS FIRST" section in the deformableObjects.h
//--------------------------------------------------------------------------------------------------------------------------
#ifndef __TEXTURES_H__
#define __TEXTURES_H__
#ifndef _CRT_SECURE_NO_DEPRECATE
#define _CRT_SECURE_NO_DEPRECATE 1
#endif

#include "DXUT.h"
#include "resource.h"
#include "DXUTmisc.h"
#include "resource.h"
#include "SDKmisc.h"
#include "SDKmesh.h"
using namespace std;


//--------------------------------------------------------------------------------------------------------------------------
//
//	Class for manipulating texture2D and textureCube 
//
//--------------------------------------------------------------------------------------------------------------------------
class CTexture2D{
public:

	// Member functions
	CTexture2D(LPCWSTR fileName, ID3D10Device* pd3dDevice, D3DX10_IMAGE_LOAD_INFO* loadInfo = NULL);
	CTexture2D(ID3D10Device* pd3dDevice, 
		UINT width, 
		UINT height, 
		float* data, 
		DXGI_FORMAT format = DXGI_FORMAT_R32G32B32A32_FLOAT, 
		D3D10_USAGE usage = D3D10_USAGE_DEFAULT, D3D10_BIND_FLAG bindFlag = D3D10_BIND_SHADER_RESOURCE,
		bool createRTV = false, D3D10_CPU_ACCESS_FLAG cpuAccessFlag = (D3D10_CPU_ACCESS_FLAG)0, D3D10_RESOURCE_MISC_FLAG miscFlags = (D3D10_RESOURCE_MISC_FLAG) 0, UINT arraySize = 1, bool isTextureArray = false);
		
	~CTexture2D();

	// Member variables
	ID3D10Resource				 *m_pRes;			// Resource
	ID3D10Texture2D				 *m_pTexture;		// Texture Resource
	ID3D10ShaderResourceView	 *m_pTextureRV;		// Shader resource view, so can be fetched in the shader
	ID3D10RenderTargetView		 *m_pRTV;			// Render targer view, for those that needed it	
	bool						  m_createRTV;		// A flag specifying whether render target view is created or not
	UINT						  m_width;			// The width of the texture
	UINT						  m_height;			// The height of the texture

};

#endif