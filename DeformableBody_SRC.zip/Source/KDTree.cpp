//----------------------------------------------------------------------------------
// File:   KDTree.cpp
// Author: Nuttapong Chentanez
// Email:  sdkfeedback@nvidia.com
//
// Deformable Physics is based on Meshless Deformations Based on Shape Matching by M. Mueller, B. Heidelberger, M. Teschner, M. Gross.
// Collision detection and response is done with cube map look up.
// All run-time computation is done on the GPU.
// 
// Copyright (c) 2007 NVIDIA Corporation. All rights reserved.
//
// TO  THE MAXIMUM  EXTENT PERMITTED  BY APPLICABLE  LAW, THIS SOFTWARE  IS PROVIDED
// *AS IS*  AND NVIDIA AND  ITS SUPPLIERS DISCLAIM  ALL WARRANTIES,  EITHER  EXPRESS
// OR IMPLIED, INCLUDING, BUT NOT LIMITED  TO, IMPLIED WARRANTIES OF MERCHANTABILITY
// AND FITNESS FOR A PARTICULAR PURPOSE.  IN NO EVENT SHALL  NVIDIA OR ITS SUPPLIERS
// BE  LIABLE  FOR  ANY  SPECIAL,  INCIDENTAL,  INDIRECT,  OR  CONSEQUENTIAL DAMAGES
// WHATSOEVER (INCLUDING, WITHOUT LIMITATION,  DAMAGES FOR LOSS OF BUSINESS PROFITS,
// BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION, OR ANY OTHER PECUNIARY LOSS)
// ARISING OUT OF THE  USE OF OR INABILITY  TO USE THIS SOFTWARE, EVEN IF NVIDIA HAS
// BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
//

//--------------------------------------------------------------------------------------------------------------------------
//      READ THIS FIRST
// See the "READ THIS FIRST" section in the deformableObjects.h
//--------------------------------------------------------------------------------------------------------------------------

#include "DXUT.h"
#include "KDTree.h"

CKDNode::~CKDNode() {
	// Destructor of node
	if (m_leaf) {
		// If it's a leaf, delete the list of points in this leaf
		delete [] m_ids;
	} else {
		// If it's an internal node, recursively delete the left and the right subtrees
		delete m_left;
		delete m_right;
	}
}

CKDTree::CKDTree(D3DXVECTOR3* points, DWORD numPts) {

	// Make lists containing position and the id of the vertices
	m_nodes = new D3DXVECTOR3[numPts];
	vector<DWORD> m_ids; 
	for (DWORD i = 0; i < numPts; i++) {
		m_nodes[i] = points[i];
		m_ids.push_back(i);
	}			

	// Create the root
	m_root = new CKDNode();

	// Start building tree
	BuildTree(m_root, m_ids, 0);
}

void CKDTree::Partition(vector<DWORD>& m_ids, vector<DWORD>& left, vector<DWORD>& right, int depth, unsigned char& axis, float& value) {

	// Alternate between x, y, and z axis in partitioning the set of points
	axis = (unsigned char)(depth % 3);
	float mean = 0.0f;

	// Compute the mean
	for (size_t i = 0; i < m_ids.size(); i++) {
		mean += m_nodes[m_ids[i]][axis];
	}

	mean /= m_ids.size();
	for (size_t i = 0; i < m_ids.size(); i++) {
		// If nodes's coordinate is < mean, put on left list, otherwise put on the right list
		if (m_nodes[m_ids[i]][axis] < mean) {
			left.push_back(m_ids[i]);
		} else {
			right.push_back(m_ids[i]);
		}
	}
	value = mean;
}

inline void CKDTree::Inverse3x3(float* in, float* out){
	// Inverse the 3x3 matrix using the method of determinant
	out[0] = in[4]*in[8] - in[5]*in[7];
	out[1] = in[2]*in[7] - in[1]*in[8];
	out[2] = in[1]*in[5] - in[2]*in[4];
	out[3] = in[5]*in[6] - in[3]*in[8];
	out[4] = in[0]*in[8] - in[2]*in[6];
	out[5] = in[2]*in[3] - in[0]*in[5];
	out[6] = in[3]*in[7] - in[4]*in[6];
	out[7] = in[1]*in[6] - in[0]*in[7];
	out[8] = in[0]*in[4] - in[1]*in[3];

	float fDet = in[0]*out[0] + in[1]*out[3]+ in[2]*out[6];

	// If magnitude of determinant is too small, just make the matrix 0
	// This correspond to a badly shape tetrahedron
	if (fabs(fDet) < 1e-10)
	{
		out[0] = 0.0f;
		out[1] = 0.0f;
		out[2] = 0.0f;
		out[3] = 0.0f;
		out[4] = 0.0f;
		out[5] = 0.0f;
		out[6] = 0.0f;
		out[7] = 0.0f;
		out[8] = 0.0f;
	}

	float invfDet = 1.0f / fDet;
	out[0] *= invfDet;
	out[1] *= invfDet;
	out[2] *= invfDet;
	out[3] *= invfDet;
	out[4] *= invfDet;
	out[5] *= invfDet;
	out[6] *= invfDet;
	out[7] *= invfDet;
	out[8] *= invfDet;
}

void CKDTree::BuildTree(CKDNode*& ptr, vector<DWORD>& m_ids, int depth) {
	// Check if the depth is too much already or not
	// or if the number of points are too small,
	// just create a leaf
	if ((depth >= MAX_DEPTH) || (m_ids.size() <= CUT_OFF)) {
		// Allocate memeory and copy over the ID 
		ptr->m_leaf = true;
		ptr->m_ids = new DWORD[m_ids.size()];
		if (!m_ids.empty()) {
			memcpy(ptr->m_ids, &m_ids[0], sizeof(DWORD)*m_ids.size());
		}
		ptr->m_numNodes = (DWORD)m_ids.size();	
		return;
	}

	// Partition to 2 list
	vector<DWORD> left, right;
	Partition(m_ids, left, right, depth, ptr->m_axis, ptr->m_value);

	ptr->m_leaf = false;
	ptr->m_left = new CKDNode();
	ptr->m_right = new CKDNode();
	
	// Recursively build the tree
	BuildTree(ptr->m_left, left, depth+1);
	BuildTree(ptr->m_right, right, depth+1);
}

void CKDTree::FindPoints(CKDNode*& ptr) {
	// Check if this node is the leaf or not
	if (ptr->m_leaf) {
		// Leaf
		D3DXVECTOR3 tmp;
		D3DXVECTOR4 bcoord;

		// Loop through all the vertices and check if they are inside the tetrahedron or not
		for (DWORD i = 0; i < ptr->m_numNodes; i++) {
			// Compute barycentric coordinates
			tmp = m_nodes[ptr->m_ids[i]] - m_origin;
			bcoord.y = m_baryMat[0]*tmp.x + m_baryMat[1]*tmp.y + m_baryMat[2]*tmp.z;
			bcoord.z = m_baryMat[3]*tmp.x + m_baryMat[4]*tmp.y + m_baryMat[5]*tmp.z;
			bcoord.w = m_baryMat[6]*tmp.x + m_baryMat[7]*tmp.y + m_baryMat[8]*tmp.z;
			bcoord.x = 1.0f - bcoord.y - bcoord.z - bcoord.w;
			if ((bcoord.x >= 0.0f) & 
				(bcoord.y >= 0.0f) & 
				(bcoord.z >= 0.0f) & 
				(bcoord.w >= 0.0f)) {
					// See if the barycentric coordinate is all >= 0 or not
					m_pPoints->push_back(ptr->m_ids[i]);
					m_pBarys->push_back(bcoord);
			}
		}
	} else {
		// Non-leaf, just recursively call the checking function
		if (m_mins[ptr->m_axis] <= ptr->m_value) FindPoints(ptr->m_left);
		if (m_maxs[ptr->m_axis] >= ptr->m_value) FindPoints(ptr->m_right);
	}
}
void CKDTree::PointsInTet(D3DXVECTOR3& t0, D3DXVECTOR3& t1, D3DXVECTOR3& t2, D3DXVECTOR3& t3, vector<DWORD>& points, vector<D3DXVECTOR4>& barys) {
	// Find the m_ids of all points that is in the tetrahedral t0 t1 t2 t3
	// Also return the bary centric coordinate
	
	m_origin = t0; // Origin is just the first corner
	
	// Build bary matrix
	D3DXVECTOR3 v1 = t1-t0, v2 = t2-t0, v3 = t3-t0;
	float tmpMat[9] = {v1.x, v2.x, v3.x,
					   v1.y, v2.y, v3.y,
					   v1.z, v2.z, v3.z};

	Inverse3x3(tmpMat, m_baryMat);

	// Find the mins of all axes
	m_mins.x = min(min(min(t0.x, t1.x), t2.x), t3.x);
	m_mins.y = min(min(min(t0.y, t1.y), t2.y), t3.y);
	m_mins.z = min(min(min(t0.z, t1.z), t2.z), t3.z);

	// Find the maxs of all axes
	m_maxs.x = max(max(max(t0.x, t1.x), t2.x), t3.x);
	m_maxs.y = max(max(max(t0.y, t1.y), t2.y), t3.y);
	m_maxs.z = max(max(max(t0.z, t1.z), t2.z), t3.z);

	// Set the pointers to the vectors appropriately
	m_pPoints = &points;
	m_pBarys = &barys;

	// Start to find the points
	FindPoints(m_root);
}
CKDTree::~CKDTree() {
	delete [] m_nodes;
	delete m_root;
}
