//----------------------------------------------------------------------------------
// File:   Landscape.h
// Author: Nuttapong Chentanez
// Email:  sdkfeedback@nvidia.com
//
// Deformable Physics is based on Meshless Deformations Based on Shape Matching by M. Mueller, B. Heidelberger, M. Teschner, M. Gross.
// Collision detection and response is done with cube map look up.
// All run-time computation is done on the GPU.
// 
// Copyright (c) 2007 NVIDIA Corporation. All rights reserved.
//
// TO  THE MAXIMUM  EXTENT PERMITTED  BY APPLICABLE  LAW, THIS SOFTWARE  IS PROVIDED
// *AS IS*  AND NVIDIA AND  ITS SUPPLIERS DISCLAIM  ALL WARRANTIES,  EITHER  EXPRESS
// OR IMPLIED, INCLUDING, BUT NOT LIMITED  TO, IMPLIED WARRANTIES OF MERCHANTABILITY
// AND FITNESS FOR A PARTICULAR PURPOSE.  IN NO EVENT SHALL  NVIDIA OR ITS SUPPLIERS
// BE  LIABLE  FOR  ANY  SPECIAL,  INCIDENTAL,  INDIRECT,  OR  CONSEQUENTIAL DAMAGES
// WHATSOEVER (INCLUDING, WITHOUT LIMITATION,  DAMAGES FOR LOSS OF BUSINESS PROFITS,
// BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION, OR ANY OTHER PECUNIARY LOSS)
// ARISING OUT OF THE  USE OF OR INABILITY  TO USE THIS SOFTWARE, EVEN IF NVIDIA HAS
// BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
//

//--------------------------------------------------------------------------------------------------------------------------
//      READ THIS FIRST
// See the "READ THIS FIRST" section in the deformableObjects.h
//--------------------------------------------------------------------------------------------------------------------------
#ifndef __LANDSCAPE_H__
#define __LANDSCAPE_H__

#include "DXUT.h"
#include "effects.h"
#include "textures.h"
#include "buffers.h"

//--------------------------------------------------------------------------------------
// Structures
//--------------------------------------------------------------------------------------
struct ObsVertex{
	D3DXVECTOR3 pos;
	D3DXVECTOR2 uv;
};

class CLandscapeEffect: public CEffect{
public:
	ID3D10EffectTechnique					*m_pTechnique;
	ID3D10EffectScalarVariable				*m_pVertexTextureWidth;	
	ID3D10EffectScalarVariable				*m_pVertexTextureHeight;	
	ID3D10EffectMatrixVariable				*m_pWorldVariable;
	ID3D10EffectMatrixVariable				*m_pViewVariable;
	ID3D10EffectMatrixVariable				*m_pProjectionVariable;
	ID3D10EffectShaderResourceVariable		*m_pHeightVariable;
	ID3D10EffectShaderResourceVariable		*m_pRedTex;
	ID3D10EffectShaderResourceVariable		*m_pGreenTex;
	ID3D10EffectShaderResourceVariable		*m_pBlueTex;
	ID3D10EffectShaderResourceVariable		*m_pAlphaTex;
	ID3D10EffectShaderResourceVariable		*m_pCoverageTex;
	ID3D10EffectScalarVariable				*m_puvScalingRed;
	ID3D10EffectScalarVariable				*m_puvScalingGreen;
	ID3D10EffectScalarVariable				*m_puvScalingBlue;
	ID3D10EffectScalarVariable				*m_puvScalingAlpha;
	ID3D10EffectVectorVariable				*m_puvJitterRed;
	ID3D10EffectVectorVariable				*m_puvJitterGreen;
	ID3D10EffectVectorVariable				*m_puvJitterBlue;
	ID3D10EffectVectorVariable				*m_puvJitterAlpha;
	ID3D10InputLayout						*m_layout;

	CLandscapeEffect(ID3D10Device* pd3dDevice);
	~CLandscapeEffect();
};

//--------------------------------------------------------------------------------------------------------------------------
//
// This is the class for rendering the landscape 
// 4 textures are blended together to form the final image
// Percentage of each textures are from r,g,b,a channels of a coverage texture
// The height is fetch with vertex texture fetch, so that we could alter the height map texture in real time
// and could obtain a nice ground shaking effect 
// 
//--------------------------------------------------------------------------------------------------------------------------

class CLandscape{
public:

	CLandscape(ID3D10Device* pd3dDevice, float heightScaleX, float heightScaleZ, CTexture2D* heightMap);
	~CLandscape();

	// For setting the projection matrix
	void SetProjectionMat(const D3DXMATRIX* projection);

	// Render the landscape 
	void Render(ID3D10Device* pd3dDevice, const D3DXMATRIX* world, const D3DXMATRIX* view);

private:
	// Create a landscape patch
	void CreatePatch(float heightScaleX, float heightScaleZ ,UINT w, UINT h, UINT& numVertices, ObsVertex*& pos, UINT& numIndices, DWORD*& indices);

	CTexture2D								*m_redTex;
	CTexture2D								*m_greenTex;
	CTexture2D								*m_blueTex;
	CTexture2D								*m_alphaTex;
	CTexture2D								*m_coverageTex;
	
	CLandscapeEffect						*m_landscapeEffect;
	CVertexBuffer<ObsVertex>				*m_posBuf;
	CIndexBuffer<DWORD>						*m_iBuf;
};
#endif