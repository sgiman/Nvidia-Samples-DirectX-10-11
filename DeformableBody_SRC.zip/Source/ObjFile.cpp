//----------------------------------------------------------------------------------
// File:   ObjFile.cpp
// Author: Nuttapong Chentanez
// Email:  sdkfeedback@nvidia.com
//
// Deformable Physics is based on Meshless Deformations Based on Shape Matching by M. Mueller, B. Heidelberger, M. Teschner, M. Gross.
// Collision detection and response is done with cube map look up.
// All run-time computation is done on the GPU.
// 
// Copyright (c) 2007 NVIDIA Corporation. All rights reserved.
//
// TO  THE MAXIMUM  EXTENT PERMITTED  BY APPLICABLE  LAW, THIS SOFTWARE  IS PROVIDED
// *AS IS*  AND NVIDIA AND  ITS SUPPLIERS DISCLAIM  ALL WARRANTIES,  EITHER  EXPRESS
// OR IMPLIED, INCLUDING, BUT NOT LIMITED  TO, IMPLIED WARRANTIES OF MERCHANTABILITY
// AND FITNESS FOR A PARTICULAR PURPOSE.  IN NO EVENT SHALL  NVIDIA OR ITS SUPPLIERS
// BE  LIABLE  FOR  ANY  SPECIAL,  INCIDENTAL,  INDIRECT,  OR  CONSEQUENTIAL DAMAGES
// WHATSOEVER (INCLUDING, WITHOUT LIMITATION,  DAMAGES FOR LOSS OF BUSINESS PROFITS,
// BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION, OR ANY OTHER PECUNIARY LOSS)
// ARISING OUT OF THE  USE OF OR INABILITY  TO USE THIS SOFTWARE, EVEN IF NVIDIA HAS
// BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
//

//--------------------------------------------------------------------------------------------------------------------------
//      READ THIS FIRST
// See the "READ THIS FIRST" section in the deformableObjects.h
//--------------------------------------------------------------------------------------------------------------------------
#include "DXUT.h"
#include "objfile.h"

class CTextureAndResourcePair{
public:
	ID3D10Texture2D* m_pTexture;
	ID3D10ShaderResourceView* m_pTextureRV;

};

// Use Map so that we do not load duplicate textures
static map<string, CTextureAndResourcePair> tex2DMap;

void ClearTextureManager() {
	tex2DMap.clear();
}
void CObjFile::OutToSurf(string& name) {

	ofstream of(name.c_str());
	of<<"surfacemesh"<<endl;
	of<<m_position.size()<<endl;
	for (size_t i  = 0; i < m_position.size(); i++) {
		of<<m_position[i].x<<" "<<m_position[i].y<<" "<<m_position[i].z<<endl;
	}
	of<<m_positionIndices.size() / 3<<endl;
	for (size_t i = 0; i < m_positionIndices.size() / 3; i++) {
		of<<m_positionIndices[i*3]+1<<" "<<m_positionIndices[i*3+1]+1<<" "<<m_positionIndices[i*3+2]+1<<endl;
	}
	of.close();
}
void CObjFile::LoadMaterial(string& name, ID3D10Device* pd3dDevice) {

	HRESULT hr;
	V(DXUTSetMediaSearchPath(L"..\\Media"));
	WCHAR fullName[MAX_PATH];
	WCHAR wideName[MAX_PATH];
	mbstowcs(wideName,name.c_str(),MAX_PATH);
    V( DXUTFindDXSDKMediaFileCch( fullName, MAX_PATH, wideName ) );

	// Load the mtl file
	ifstream inf( fullName );
	string str;
	while (getline(inf, str, '\n')) {

		// Ignore lines starting with #
		if ((str.size() > 0) && (str[0] != '#')) {
			istringstream is(str);
			string first;
			is>>first;

			// Check the first command
			if (first == "map_Kd") {

				// Look at the texture for the diffuse component
				string fileName;
				is>>fileName;

				// See if the texture is already loaded or not
				if (tex2DMap.find(fileName) == tex2DMap.end()) {
					// If not, load it
					WCHAR wideTextureName[MAX_PATH];
					mbstowcs(wideTextureName,fileName.c_str(),MAX_PATH);
                    V( DXUTFindDXSDKMediaFileCch( fullName, MAX_PATH, wideTextureName ) );
					CTexture2D* tex2D = new CTexture2D(fullName, pd3dDevice);

					tex2DMap[fileName].m_pTexture = tex2D->m_pTexture;
					tex2DMap[fileName].m_pTextureRV = tex2D->m_pTextureRV;
					m_pTexture = tex2D->m_pTexture;
					m_pTextureRV = tex2D->m_pTextureRV;

					// Increment the number of references
					m_pTexture->AddRef();
					m_pTextureRV->AddRef();
					delete tex2D;
				} else {
					// If so, use the existing one				
					m_pTexture = tex2DMap[fileName].m_pTexture;
					m_pTextureRV = tex2DMap[fileName].m_pTextureRV;

					// Increment the number of references
					m_pTexture->AddRef();
					m_pTextureRV->AddRef();
				}
			}
		}
	}
	inf.close();
}

CObjFile::CObjFile(LPCWSTR fileName, ID3D10Device* pd3dDevice) {
	m_pTexture = NULL;
	m_pTextureRV = NULL;
	HRESULT hr;
    V(DXUTSetMediaSearchPath(L"..\\Media"));
	WCHAR fullName[MAX_PATH];
    V( DXUTFindDXSDKMediaFileCch( fullName, MAX_PATH, fileName ) );

	ifstream inf(fullName);
	string str;

	// Read the obj file line by line
	while (getline(inf, str, '\n')) {
		if ((str.size() > 0) && (str[0] != '#')) {
			// Skip if starts with #
			istringstream is(str);
			string first;
			is>>first;
			if (first == "mtllib") {
				// Load the material
				string matName;
				is>>matName;
				LoadMaterial(matName, pd3dDevice);
			} else 
			if (first == "g") {
				// Ignore
			} else
			if (first == "usemtl") {
				// Ignore
			} else
			if (first == "v") {
				// Push the vertex m_position
				float x, y, z;
				is>>x>>y>>z;
				m_position.push_back(D3DXVECTOR3(x, y, z));
			} else
			if (first == "vt") {
				// Push the texture coordinate
				float u, v;
				is>>u>>v;
				m_texCoord.push_back(D3DXVECTOR2(u, 1.0f-v));
			} else
			if (first == "f") {
				// Push the face
				// Assume one texture coordinate
				DWORD f0p, f0t, f1p, f1t, f2p, f2t;
				is>>f0p;
				is.ignore(1);
				is>>f0t;
				is>>f1p;
				is.ignore(1);
				is>>f1t;
				is>>f2p;
				is.ignore(1);
				is>>f2t;

				// Push in position indices, index from 0
				m_positionIndices.push_back(f0p-1);
				m_positionIndices.push_back(f1p-1);
				m_positionIndices.push_back(f2p-1);

				// Push in texture indices, index from 0
				m_texCoordIndices.push_back(f0t-1);
				m_texCoordIndices.push_back(f1t-1);
				m_texCoordIndices.push_back(f2t-1);
			} 
		}		
	}
	inf.close();
}
CObjFile::~CObjFile() {
	
	SAFE_RELEASE(m_pTexture);
	SAFE_RELEASE(m_pTextureRV);
}

