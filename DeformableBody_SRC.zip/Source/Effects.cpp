//----------------------------------------------------------------------------------
// File:   Effects.cpp
// Author: Nuttapong Chentanez
// Email:  sdkfeedback@nvidia.com
//
// Deformable Physics is based on Meshless Deformations Based on Shape Matching by M. Mueller, B. Heidelberger, M. Teschner, M. Gross.
// Collision detection and response is done with cube map look up.
// All run-time computation is done on the GPU.
// 
// Copyright (c) 2007 NVIDIA Corporation. All rights reserved.
//
// TO  THE MAXIMUM  EXTENT PERMITTED  BY APPLICABLE  LAW, THIS SOFTWARE  IS PROVIDED
// *AS IS*  AND NVIDIA AND  ITS SUPPLIERS DISCLAIM  ALL WARRANTIES,  EITHER  EXPRESS
// OR IMPLIED, INCLUDING, BUT NOT LIMITED  TO, IMPLIED WARRANTIES OF MERCHANTABILITY
// AND FITNESS FOR A PARTICULAR PURPOSE.  IN NO EVENT SHALL  NVIDIA OR ITS SUPPLIERS
// BE  LIABLE  FOR  ANY  SPECIAL,  INCIDENTAL,  INDIRECT,  OR  CONSEQUENTIAL DAMAGES
// WHATSOEVER (INCLUDING, WITHOUT LIMITATION,  DAMAGES FOR LOSS OF BUSINESS PROFITS,
// BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION, OR ANY OTHER PECUNIARY LOSS)
// ARISING OUT OF THE  USE OF OR INABILITY  TO USE THIS SOFTWARE, EVEN IF NVIDIA HAS
// BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
//

//--------------------------------------------------------------------------------------------------------------------------
//      READ THIS FIRST
// See the "READ THIS FIRST" section in the deformableObjects.h
//--------------------------------------------------------------------------------------------------------------------------

#include "DXUT.h"
#include "SDKmisc.h"
#include "effects.h"

#pragma warning(disable: 4995)
#include <iostream>

using namespace std;
static HRESULT hr;

CEffect::CEffect(LPCWSTR fileName, ID3D10Device* pd3dDevice, D3D10_SHADER_MACRO* macro) {

    V(DXUTSetMediaSearchPath(L"..\\Source\\DeformableBody"));
	WCHAR fullFileName[MAX_PATH];
    V(DXUTFindDXSDKMediaFileCch( fullFileName, MAX_PATH, fileName ) );

	DWORD dwShaderFlags = D3D10_SHADER_ENABLE_STRICTNESS;
	
	// Try to create the effect from file and also output the complie error, if exists
	ID3D10Blob * blob;
	m_pEffect = 0;
    hr = D3DX10CreateEffectFromFile( fullFileName, macro, NULL, "fx_4_0", dwShaderFlags, 0, pd3dDevice, NULL, NULL, &m_pEffect, &blob, &hr );

	if (blob) {
		char* ptr = (char*)blob->GetBufferPointer();
		cout<<ptr<<endl;
	}

	if( FAILED( hr ) )
	{
		MessageBox( NULL, L"The FX file cannot be located, or there is a compilation error. Make sure the working directory is the Bin directory. ", L"Error", MB_OK );
		V( hr );
	}
}

CEffect::~CEffect() {
	SAFE_RELEASE(m_pEffect);
}
