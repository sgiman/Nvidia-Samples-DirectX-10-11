//----------------------------------------------------------------------------------
// File:   DeformableObjects.h
// Author: Nuttapong Chentanez
// Email:  sdkfeedback@nvidia.com
//
// Deformable Physics is based on Meshless Deformations Based on Shape Matching by M. Mueller, B. Heidelberger, M. Teschner, M. Gross.
// Collision detection and response is done with cube map look up.
// All run-time computation is done on the GPU.
// 
// Copyright (c) 2007 NVIDIA Corporation. All rights reserved.
//
// TO  THE MAXIMUM  EXTENT PERMITTED  BY APPLICABLE  LAW, THIS SOFTWARE  IS PROVIDED
// *AS IS*  AND NVIDIA AND  ITS SUPPLIERS DISCLAIM  ALL WARRANTIES,  EITHER  EXPRESS
// OR IMPLIED, INCLUDING, BUT NOT LIMITED  TO, IMPLIED WARRANTIES OF MERCHANTABILITY
// AND FITNESS FOR A PARTICULAR PURPOSE.  IN NO EVENT SHALL  NVIDIA OR ITS SUPPLIERS
// BE  LIABLE  FOR  ANY  SPECIAL,  INCIDENTAL,  INDIRECT,  OR  CONSEQUENTIAL DAMAGES
// WHATSOEVER (INCLUDING, WITHOUT LIMITATION,  DAMAGES FOR LOSS OF BUSINESS PROFITS,
// BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION, OR ANY OTHER PECUNIARY LOSS)
// ARISING OUT OF THE  USE OF OR INABILITY  TO USE THIS SOFTWARE, EVEN IF NVIDIA HAS
// BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
//

//--------------------------------------------------------------------------------------------------------------------------
//      READ THIS FIRST
// Probably the best way to understand this code is to start by reading through the presentation slides
// in the doc directory and then look at the Compute function, then go into the .fx file to follows through all the shadere
// After that, you can then look at how each textures are created and how quads' position and size are determined
//--------------------------------------------------------------------------------------------------------------------------

#ifndef __DEFORMABLE_BODY_H__
#define __DEFORMABLE_BODY_H__
#include "DXUT.h"
#include "DXUTgui.h"
#include "DXUTcamera.h"
#include "DXUTsettingsdlg.h"
#include "SDKmesh_old.h"
#include "buffers.h"
#include "effects.h"
#include "textures.h"

#pragma warning(disable: 4995)
#include <vector>
using namespace std;

//--------------------------------------------------------------------------------------------------------------------------
//
// Vertex stucture for GPGPU computation
//
//--------------------------------------------------------------------------------------------------------------------------
struct GPGPUVertex
{
	D3DXVECTOR4 Pos;
	D3DXVECTOR4 UV;
};

//--------------------------------------------------------------------------------------------------------------------------
//
// Vertex stucture for potential colliding pair computation
//
//--------------------------------------------------------------------------------------------------------------------------
struct PCPVertex
{
	DWORD i, j;
};

//--------------------------------------------------------------------------------------------------------------------------
//
// Effect class for the deformable body computation/rendering
//
//--------------------------------------------------------------------------------------------------------------------------
class CDeformableBodyEffect : public CEffect{
public:

	// Techniques 																			// Technique for: 
	ID3D10EffectTechnique					*m_pDebugTechnique;								// Debugging purpose 
	ID3D10EffectTechnique					*m_pPointRenderTechnique;						// Rendering points instead of mesh (for debugging)
	ID3D10EffectTechnique					*m_pMeshRenderTechnique;						// Rendering the deformable bodies
	ID3D10EffectTechnique					*m_pPickedPointsRenderTechnique;				// Rendering the control points we currently pick

	ID3D10EffectTechnique					*m_pComputePValTechnique;						// Computing pVal
	ID3D10EffectTechnique					*m_pComputePickedVerticesTechnique;				// Picking up vertices
	ID3D10EffectTechnique					*m_pComputePickingForceTechnique;				// Applying force to the picked vertices
	
	ID3D10EffectTechnique					*m_pComputeXTildaAndAccTechnique;				// Computing xTilda and Acceleration
	ID3D10EffectTechnique					*m_pComputePotentialCollisionPairsTechnique;	// Computing potential collision pair
	ID3D10EffectTechnique					*m_pComputeCollisionForceTechnique;				// Computing collision force
	ID3D10EffectTechnique					*m_pComputeCubeMapsTechnique;					// Generate the cube maps

	ID3D10EffectTechnique					*m_pComputeXValTechnique;						// Computing the xVal
	ID3D10EffectTechnique					*m_pComputeCMTechnique;							// Computing the center of mass
	ID3D10EffectTechnique					*m_pComputeMinsNMaxsTechnique;					// Computing the bounding box lower bound and negated upper bound
	ID3D10EffectTechnique					*m_pComputeApqBarTechnique;						// Computing ApqBar matrices
	ID3D10EffectTechnique					*m_pComputeTransformTechnique;					// Computing transformation for each clusters
	ID3D10EffectTechnique					*m_pComputeClusterGoalPositionTechnique;		// Computing goal position of vertices in clusters
	ID3D10EffectTechnique					*m_pComputeForceTechnique;						// Computing the force on each of the control point
	ID3D10EffectTechnique					*m_pComputeGoalPosTechnique;					// Computing the goal position for the each of the control point
	ID3D10EffectTechnique					*m_pUpdateVelAndPosTechnique;					// Update velocity and position of the control points
	ID3D10EffectTechnique					*m_pComputeRealPosTechnique;					// Perform interpolation to obtain the position of the real vertices controlled by the control points
	ID3D10EffectTechnique					*m_pComputeNormalTechnique;						// Computing the normal vector in GPU
	ID3D10EffectTechnique					*m_pUpdateAlphaTechnique;						// Update alpha of all control points in GPU

	// Variables 
	// Matrices
	ID3D10EffectMatrixVariable				*m_pWorldVariable;								// World matrix
	ID3D10EffectMatrixVariable				*m_pViewVariable;								// View matrix
	ID3D10EffectMatrixVariable				*m_pProjectionVariable;							// Projection matrix
    ID3D10EffectMatrixVariable				*m_pworldView;									// World*View matrix
    ID3D10EffectMatrixVariable				*m_pworldViewProj;								// World*View*Projection matrix
    ID3D10EffectMatrixVariable				*m_pworldViewIT;								// (World*View)T^-1 matrix, for transforming normal
	ID3D10EffectMatrixVariable				*m_pcubeMapViewProj;							// View-Projection matrix for the 6 sides of the cube map, assuming that the cube map is generated viewing from the origin

	// Vectors
    ID3D10EffectVectorVariable				*m_plightPos;									// Position of light source for rendering
	ID3D10EffectVectorVariable				*m_pclustersQuads;								// Array containing the top-left and lower-right corners of the quads that correspond to clusters in a texture that contains information about control points in each cluster
	ID3D10EffectVectorVariable				*m_minsPickNC;									// The mins of the box in a normalized coordinate for vertices picking
	ID3D10EffectVectorVariable				*m_maxsPickNC;									// The maxs of the box in a normalized coordinate for vertices picking
	ID3D10EffectVectorVariable				*m_mouseRay;									// A vector corresponding to the ray the mouse currently points to 
	ID3D10EffectVectorVariable				*m_cameraPos;									// The camera's position 


	ID3D10EffectVectorVariable				*m_pinvHeightScale;								// Inverse of the height map scaling
	ID3D10EffectVectorVariable				*m_pcubeTexOffset;								// Texture offset of each of the flatten cube maps

	// Scalar
	ID3D10EffectScalarVariable				*m_ph;											// Time step size
	ID3D10EffectScalarVariable				*m_pinvH;										// Inverse of the time step size
	
	ID3D10EffectScalarVariable				*m_pxTexW;										// The width of the xTex, vTex, ..., (textures that contain information about control points)
	ID3D10EffectScalarVariable				*m_twoInvXTexW;									// 2.0f/xTexW
	ID3D10EffectScalarVariable				*m_twoInvXTexH;									// 2.0f/xTexH
	ID3D10EffectScalarVariable				*m_pxAdrTexW;									// The width of the xAdrTex, ... (textures that contain information about control points in each cluster)
	ID3D10EffectScalarVariable				*m_pinv3xAdrW;									// 1.0f / (3*xAdrW)
	ID3D10EffectScalarVariable				*m_pthreeXAdrW;									// 3*xAdrW
	ID3D10EffectScalarVariable				*m_pcmTexW;										// The width of th cmTex, ... (textures that contain information about clusters)	
	ID3D10EffectScalarVariable				*m_ptwoInv7S;									// 2 / (7*S)
	ID3D10EffectScalarVariable			    *m_pposTexW;									// The width of the posTex, .... (textures that store information about the real vertices)

	ID3D10EffectScalarVariable				*m_pcomputeNormalScaleU;						// The scaling in the U direction for computing the normal
	ID3D10EffectScalarVariable				*m_pcomputeNormalScaleV;						// The scaling in the V direction for computing the normal
	ID3D10EffectScalarVariable				*m_pstartVertex;								// The starting vertex index for the current mesh to render/compute normal
	ID3D10EffectScalarVariable				*m_pclustersToObjects;							// An array containing the id of the object each of the cluster belongs to
	ID3D10EffectScalarVariable				*m_pclustersHardness;							// An array containing the hardness of each of the cluster
	ID3D10EffectScalarVariable				*m_pfloorHardness;								// The floor's hardness
	ID3D10EffectScalarVariable				*m_pspringK;									// The spring constant for applying force to the picked vertices
	ID3D10EffectScalarVariable				*m_pairDrag;									// The coefficient to be multiplied to the velocity to slow down the motion of the objects, should be close to 1 but <= 1 
	ID3D10EffectScalarVariable				*m_pgravity;									// Gravity
	
	ID3D10EffectScalarVariable				*m_shift_xTexW;									// Shift variables 
	ID3D10EffectScalarVariable				*m_and_xTexW;
    ID3D10EffectScalarVariable				*m_shift_xAdrTexW;
	ID3D10EffectScalarVariable				*m_and_xAdrTexW;
    ID3D10EffectScalarVariable				*m_shift_posTexW;
	ID3D10EffectScalarVariable				*m_and_posTexW;
    ID3D10EffectScalarVariable				*m_shift_cmTexW;
	ID3D10EffectScalarVariable				*m_and_cmTexW;
	ID3D10EffectScalarVariable				*m_pbetas;
	ID3D10EffectScalarVariable				*m_palphas;

	// Shader Resources		
	ID3D10EffectShaderResourceVariable		*m_prenderTargetIDBuffer;						// Buffer containing the render target that each of cube map should be rendered to
	ID3D10EffectShaderResourceVariable		*m_pidToxValTexMappingBuffer;					// Buffer containing the uv coordnates in the xValTex that the position for a given control vertex (indexed by ID) resides
	ID3D10EffectShaderResourceVariable		*m_pheightMapTex;								// Height map texture
	ID3D10EffectShaderResourceVariable		*m_pdiffuseTex;									// Diffuse texture for mesh rendering
	ID3D10EffectShaderResourceVariable		*m_pgAdrTex;									// Handle of the gAdrTex
	ID3D10EffectShaderResourceVariable		*m_pgValTex;									// Handle of the gValTex
	ID3D10EffectShaderResourceVariable		*m_pxAdrTex;									// Handle of the xAdrTex
	ID3D10EffectShaderResourceVariable		*m_pxTex;										// Handle of the xTex
	ID3D10EffectShaderResourceVariable		*m_pvTex;										// Handle of the vTex
	ID3D10EffectShaderResourceVariable		*m_pxTildaTex;									// Handle of the xTildaTex
	ID3D10EffectShaderResourceVariable		*m_paTildaTex;									// Handle of the aTildaTex
	ID3D10EffectShaderResourceVariable		*m_pgTex;										// Handle of the gTex
	ID3D10EffectShaderResourceVariable		*m_pxValTex;									// Handle of the xValTex
	ID3D10EffectShaderResourceVariable		*m_ppValTex;									// Handle of the pValTex
	ID3D10EffectShaderResourceVariable		*m_pqBarTex;									// Handle of the qBarTex
	ID3D10EffectShaderResourceVariable		*m_pposAdrTex;									// Handle of the posAdrTex
	ID3D10EffectShaderResourceVariable		*m_pposTex;										// Handle of the posTex
	ID3D10EffectShaderResourceVariable		*m_pnormalTex;									// Handle of the normalTex
	ID3D10EffectShaderResourceVariable		*m_pposWeightTex;								// Handle of the posWeightTex
	ID3D10EffectShaderResourceVariable		*m_pcmTex;										// Handle of the cmTex
	ID3D10EffectShaderResourceVariable		*m_pminsTex;									// Handle of the minsTex
	ID3D10EffectShaderResourceVariable		*m_pnmaxsTex;									// Handle of the nmaxsTex
	ID3D10EffectShaderResourceVariable		*m_pforceTex;									// Handle of the forceTex
	ID3D10EffectShaderResourceVariable		*m_pforceValTex;								// Handle of the forceValTex
	ID3D10EffectShaderResourceVariable		*m_pAqqBarTex;									// Handle of the AqqBarTex
	ID3D10EffectShaderResourceVariable		*m_pApqBarTex;									// Handle of the ApqBarTex
	ID3D10EffectShaderResourceVariable		*m_ptransformTex;								// Handle of the transformTex
	ID3D10EffectShaderResourceVariable		*m_pcubeMapAtlasTex;							// Handle of the cubeMapAtlasTex
	ID3D10EffectShaderResourceVariable		*m_pcube2DTex;									// Handle of the cube2DTex
	ID3D10EffectShaderResourceVariable		*m_puvBuffer;									// Buffer containing uv coordinates
	ID3D10EffectShaderResourceVariable		*m_puvIndexBuffer;								// Buffer containing index into uvBuffer for each triangle in the mesh
	ID3D10EffectShaderResourceVariable		*m_pobjIDTex;									// Handle of the objIDTex
	// Layout of vertex buffers
	ID3D10InputLayout						*m_gpgpuLayout;									// Layout for general GPGPU computation
	ID3D10InputLayout						*m_computeCollisionForceLayout;					// Layout for collision force computation
	ID3D10InputLayout						*m_meshRenderLayout;							// Layout for rendering mesh

	CDeformableBodyEffect(ID3D10Device* pd3dDevice, D3D10_SHADER_MACRO* macro = NULL);
	~CDeformableBodyEffect();

};

//--------------------------------------------------------------------------------------------------------------------------
//
// Class to hold the information about real vertices (which are the vertices whose position are the linear combination of control point vertices) 
// This is used for rendering purpose. The simulation mesh can be of a low resolution, however, we can still have high resolution surface
// mesh for rendering. The real vertices refer to the vertices of this surface mesh.
//
//--------------------------------------------------------------------------------------------------------------------------
class CRealVertex{
public:
	unsigned int m_controlIndex[4];															// The 4 control points that affects this real vertex
	float m_controlWeight[4];																// The weight associated with each of the 4 control points
};

//--------------------------------------------------------------------------------------------------------------------------
//
// Class that holds information about a deformable object, for rendering purpose
//
//--------------------------------------------------------------------------------------------------------------------------
class CDeformableObject{
public:
	CVertexBuffer<D3DXVECTOR2>					*m_uvBuffer;								// UV coordinates
	CIndexBuffer<DWORD>							*m_objIB;									// position Index buffer
	CIndexBuffer<DWORD>							*m_uvIndexBuffer;							// UV Index buffer
	ID3D10Texture2D								*m_pTexture;								// Diffuse texture for the object
	ID3D10ShaderResourceView					*m_pTextureRV;								// Resource view of the texture
};

//--------------------------------------------------------------------------------------------------------------------------
//
// Class for performing GPGPU computation of the deformable body physics based on the paper Meshless Deformation Based on Shape Matching by Matthias Muller et al.
// It handles collision with cube map and also allow the user to pick vertices with mouse and pull them around by applying a spring force on those vertices
// This class also recompute the normal of the deformable objects in GPU so as to render them properly
// It makes uses of many of the G80 features:
//
// Geometric Shader
// Geometric Stream Out
// Texture Array
// Render to texture array
// Integer math
// Integer texture
// 32-bit Floating point alpha blending
// Long shader
//
//--------------------------------------------------------------------------------------------------------------------------
class CDeformableObjects{
public:
	// Assume 1 texture per object 
	CDeformableObjects(UINT numObjects, LPCWSTR* fileNames, LPCWSTR* meshNames, D3DXMATRIX* initTransform, bool* isRelativeToGround, DWORD* K, float* alm_phas, float *betas, float* hardness, D3DXVECTOR3* constrainedMins, D3DXVECTOR3* constrainedMaxs, float floorHardness, ID3D10Device* pd3dDevice, LPCWSTR heightMapFile, D3DXVECTOR3 m_heightMapScale, float airDrag, float springK, float gravity, int cubeMapUpdateFreq);
	~CDeformableObjects();

	// For rendering the meshes
	void Render(ID3D10Device* pd3dDevice, const D3DXMATRIX* world, const D3DXMATRIX* view, const D3DXMATRIX* projection);

	// For computing one time step in the simulation
	void Compute(ID3D10Device* pd3dDevice, float timeStep, bool pull = false, bool pick = false, D3DXVECTOR2 mins = D3DXVECTOR2(1e10, 1e10), D3DXVECTOR2 maxs = D3DXVECTOR2(-1e10, -1e10), D3DXVECTOR3 eyePos = D3DXVECTOR3(0.0f, 0.0f, 0.0f), D3DXVECTOR3 mouseRay = D3DXVECTOR3(0.0f, 0.0f, 1.0f));

	void SetFloorHardness(float hardness);
	void SetGravity(float gravity);
	void SetAirDrag(float drag);
	void SetSpringK(float springK);
	void SetCubeMapUpdateFreq(int freq);

	void SetObjectsAlpha(vector<int>& objs, float newAlpha);
	void SetObjectsBeta(vector<int>& objs, float newBeta);
	void SetObjectsHardness(vector<int>& objs, float newHardness);

	// Height map stuffs, need to be accessible by the landscape class
	CTexture2D* m_heightNormalMapTex; // For collision detection with height map
	D3DXVECTOR3 m_heightMapScale;  // Scaling for height map

private:

	void RenderPoint(ID3D10Device* pd3dDevice);												// Render only points
	void RenderMesh(ID3D10Device* pd3dDevice);												// Render the surface meshs

	// Find the control tetrahedron the vertices belong to and then append the 4 control vertices to the m_realVertices vector
	void FindControlTet(D3DXVECTOR3* vertices, DWORD m_numRealVertices, WORD base, vector<D3DXVECTOR3>& positions, vector<DWORD>& tets, vector<CRealVertex>& m_realVertices);

	// For loading the tetmesh file to be used as a control mesh
	void LoadTetMesh(LPCWSTR name, vector<D3DXVECTOR3>& positions, vector<DWORD>& tets, vector<DWORD>& tris);

	// For loading the height map and also compute the normal 
	void LoadHeightMap(ID3D10Device* pd3dDevice,  LPCWSTR heightMapFile, D3DXVECTOR3 heightMapScale);

	// For rendering picked points
	void PickedPointsRender(ID3D10Device* pd3dDevice);

	// For rendering debugging information
	void DebugRender(ID3D10Device* pd3dDevice);

	// Precompute all the data structures and textures needed for the GPGPU computations
	void PreComputation(ID3D10Device* pd3dDevice, float* alphas, float* betas, float* hardness, float floorHardness);

	// Helper function for dealing with control mesh's faces
	void HandleClustersControlFaces(ID3D10Device* pd3dDevice, int numTex2DForCubes);

	// Create the cube map atlas, so as to be able to support "array of cube map" with 2 texture look up. 
	// The first lookup looks into cube map, to get a 2D address. Then we add an offset to the 2D address so as 
	// to select which cube map we wanted to look up. Then we do a dependent texture fetch to a 2D texture	
	void GenCubeMapAtlas(ID3D10Device* pd3dDevice);

	// Compute the K Mean and partition the points into K groups
	void FindKMean(D3DXVECTOR3* points, DWORD numPts, DWORD k, vector<D3DXVECTOR3>& means, vector<DWORD>& members);

	// For each of the point find which tetrahedron in the control mesh the point belong to
	void FindClustersTets(D3DXVECTOR3* points, DWORD numPts, DWORD k, vector<DWORD>& tets, int baseVertex, vector<DWORD>& tris, vector<vector<int> >& m_clusters, vector<vector<int> >& clusterFaces);

	// Query the height map to get the height at (x, z)
	float GetHeight(float x, float z);

// ------ GPGPU functions -------

	// For computing xVal
	void ComputeXVal(ID3D10Device* pd3dDevice, CTexture2D* xTexToUse);

	// For computing pVal
	void ComputePVal(ID3D10Device* pd3dDevice);

	// For computing center of mass
	void ComputeCM(ID3D10Device* pd3dDevice);
	
	// For computing mins and -maxs of the bounding boxes of the clusters
	void ComputeMinsNMaxs(ID3D10Device* pd3dDevice);

	// For computing ApqBar
	void ComputeApqBar(ID3D10Device* pd3dDevice);

	// For computing tranformation matrices
	void ComputeTransform(ID3D10Device* pd3dDevice);

	// For computing goal position of the control points for each of the clusters
	void ComputeGVal(ID3D10Device* pd3dDevice);

	// For computing goal position of the control points, by averaging its goal position from the clusters that influence it
	void ComputeGoalPos(ID3D10Device* pd3dDevice);

	// For adding the spring force to the picked vertices, so that the user can pull these vertices with a mouse
	void ComputePickingForce(ID3D10Device* pd3dDevice);

	// For update the velocity and the position of the control points
	void UpdateVelAndPos(ID3D10Device* pd3dDevice);

	// For update the alpha of the control points
	void UpdateAlpha(ID3D10Device* pd3dDevice);

	// For computing the position of the real vertices (of the surface mesh for rendering), by interpolating from the position of the 4 control points 
	void ComputeRealPosition(ID3D10Device* pd3dDevice);

	// For computing the normal of each of the real vertex
	void ComputeNormal(ID3D10Device* pd3dDevice);

	// For computing potential colliding clusters pairs
	void ComputePotentialCollidingPairs(ID3D10Device* pd3dDevice);

	// For computing collision forces
	void ComputeCollisionForce(ID3D10Device* pd3dDevice);

	// For computing the cube map for collision detection
	void ComputeCubeMaps(ID3D10Device* pd3dDevice);

	// For computing the intermediate position and velocity 
	void ComputeXTildaAndATilda(ID3D10Device* pd3dDevice);
	
	// For finding out which vertices are picked (their normalized coordinates as view from the camera is inside the bounding box formed by mins and maxs)
	void ComputePickedVertices(ID3D10Device* pd3dDevice, D3DXVECTOR2& mins, D3DXVECTOR2& maxs);

	// For computing total force applied to the control points, by summing the collision force from each of the cluster
	void ComputeForce(ID3D10Device* pd3dDevice);


	// Deformable bodies

	vector< vector<int> >							 m_objsToClusters;						// Store clusters that belongs to this objects

	// Information per deformable bodies
	vector<UINT>									 m_numRealVertices;						// Number of real vertices for each of 
	vector<UINT>									 m_numIndices;							// Number of indices
	vector<CDeformableObject>						 m_defObjects;							// For rendering

	// Concat data of each deformable bodies, namely, the data of the first object come first, then the data of the second object follows and so on..
	// This is needed because we perform the GPGPU computation in parallel, so we want to group the same kind of information for all of the objects together

	//		Control mesh
	D3DXVECTOR3										*m_controlPos;							// Control points initial positions
	vector<D3DXVECTOR3>								 m_tmpControlPos;						// Control point initial positions, in vector form
	float											*m_masses;								// Masses of the control points
	vector<float>									 m_tmpMasses;							// Masses of the control points, in vector form
	vector< vector<int> >							 m_clusters;							// Cluster of control points
	vector< vector<int> >							 m_clustersFaces;						// Cluster of control faces, for collision detection purpose

	//      Surface Mesh
	vector<CRealVertex>								 m_realVertices;						// Array of real vertice 
	int												 m_totalNumControls;					// The sum of the number of control points over all the objects
	UINT											 m_totalNumRealVertices;				// Total number of real surface vertices
	int												 m_totalNumClusters;					// The sum of the number of clusters over all the objects

	vector< float >									 m_clustersHardness;					// The hardness of the m_clusters
	vector< int >									 m_clustersToObjects;					// Map the cluster to the object it belong to
	vector< int >									 m_constrainedVertices;					// List of constrained control points, these points will not be updated
	
	CDeformableBodyEffect							*m_deformableBodyEffect;				// The effect for all the techniques

	
	DWORD											 m_numCubeMapRenderBatchs;				// Number of render batches we need to perform to generate cube map textures
	CIndexBuffer<DWORD>							   **m_clustersControlFacesIndexBuffer;		// Index buffer of the control faces that belong to each cluster
	ID3D10Buffer								   **m_clustersControlFacesRenderTargetIDBuffer; // ID for the render target that a face should go to 
	ID3D10ShaderResourceView					   **m_clustersControlFacesRenderTargetIDBufferRV; // The resource view of the above
	
	ID3D10Buffer								   **m_idToxValTexMappingBuffer;			// Map the vertex id to position in the m_xValTex to fetch the vertex position from
	ID3D10ShaderResourceView					   **m_idToxValTexMappingBufferRV;			// The resource view of the above

	CVertexBuffer<PCPVertex>*					 	 m_potentialCollidingPairsVB;			// A vertex buffer containing potentially colliding pairs

	CTexture2D										*m_white;								// Temporary white texture for rendering, for objects without texture specified

	CTexture2D										*m_objIDTex;							// I: Object ID of each control point
	CTexture2D										*m_xTex[2];								// IO: For pingpong xTexH x xTexW , Position, w store mass 
	CTexture2D										*m_vTex[2];								// IO: For pingpong xTexH x xTexW , Velocity, w store alpha, if alpha == 0, means that this is a constrained node (should not move)
	CTexture2D										*m_xTildaTex;							// IO:  Intermediate position of control points
	CTexture2D										*m_aTildaTex;							// IO: Total acceleration including collision force, external force, collision with heightmap force xTexH x xTexW 
	CTexture2D										*m_xAdrTex;								// I: Address of control points in each cluster xAdrTexH x xAdrTexW ,     xTexW is divisible by number of stuffs to sum in 1 point
																							//    XY = pointer to m_xTex	
	CTexture2D										*m_xValTex;								// IO: control points' position for each cluster			 xAdrTexH x xAdrTexW 
																							//     XYZ = XYZ of x
																							//     W = mass
	CTexture2D										*m_pValTex;								// IO: control points' position relative to cluster's CM for each cluster			 xAdrTexH x xAdrTexW 
																							//     XYZ = XYZ of p == x-cm
																							//     W = mass
	CTexture2D										*m_cmTex;								// IO: cm for each cluster            cmTexH x cmTexW
																							//     XYZ = XYZ of cm 
																							//     W = accumulated mass
	CTexture2D										*m_qBarTex;								// I: Pre-computed qbar (q is included as a special case) xAdrTexH x 3xAdrTexW
																							// (q_x, q_y, q_z, q_xx)
																							// (q_yy, q_zz, q_xy, q_xz)
																							// (q_yz, junk, junk, junk)
	CTexture2D										*m_ApqBarTex;							// IO: Apq bar for each cluster cmTexH x cmTexW*7, Apq is the 3x3 submatrix to the left
																							// (Apqb11, Apqb12, Apqb13, Apqb14)
																							// (Apqb15, Apqb16, Apqb17, Apqb18)
																							// (Apqb21, Apqb22, Apqb23, Apqb24)
																							// (Apqb25, Apqb26, Apqb27, Apqb28)
																							// (Apqb31, Apqb32, Apqb33, Apqb34)
																							// (Apqb35, Apqb36, Apqb37, Apqb38)
																							// (Apqb19, Apqb29, Apqb39)

	CTexture2D										*m_AqqBarTex;							// I: Pre-computed symmetric m_AqqBar cmTexH x cmTexW*12, there are 45 independent component
																							// (Aqqb11, Aqqb12, Aqqb13, Aqqb14)
																							// (Aqqb15, Aqqb16, Aqqb17, Aqqb18)
																							// (Aqqb19, Aqqb22, Aqqb23, Aqqb24)
																							// (Aqqb25, Aqqb26, Aqqb27, Aqqb28)
																							// (Aqqb29, Aqqb33, Aqqb34, Aqqb35)
																							// (Aqqb36, Aqqb37, Aqqb38, Aqqb39)
																							// (Aqqb44, Aqqb45, Aqqb46, Aqqb47)
																							// (Aqqb48, Aqqb49, Aqqb55, Aqqb56)
																							// (Aqqb57, Aqqb58, Aqqb59, Aqqb66)
																							// (Aqqb67, Aqqb68, Aqqb69, Aqqb77)
																							// (Aqqb78, Aqqb79, Aqqb88, Aqqb89)
																							// (Aqqb99, junk, junk, junk)
	CTexture2D *m_transformTex;  // IO: T=Beta*Abar + (1-Beta)*R for each cluster cmTexH x cmTexW*9
			 				     // Store this by column, so that we can do weighted added
							     // (T11, T21, T31, 0)
							     // (T12, T22, T32, 0)
							     // (T13, T23, T33, 0)
							     // (T14, T24, T34, 0)
							     // (T15, T25, T35, 0)
							     // (T16, T26, T36, 0)
							     // (T17, T27, T37, 0)
							     // (T18, T28, T38, 0)
							     // (T19, T29, T39, 0)

	CTexture2D* m_gValTex; // IO: goal position for control points in each cluster			 xAdrTexH x xAdrTexW 
	CTexture2D* m_forceValTex; // IO: Collision force act on control points in each cluster     xAdrTexH x xAdrTexW 
	
	CTexture2D* m_gTex; // IO: goal position for the control points xTexH x xTexW 
	CTexture2D* m_forceTex; // IO: Total force acting on the control points xTexH x xTexW 
	CTexture2D* m_gAdrTex; // I: pointer to gValTex to fetch the goal position from, for each control points 

	CTexture2D* m_posAdrTex; // I: Contain pointers to the 4 control points indices that affect each real vertex
	CTexture2D* m_posWeightTex; // I: Contain weight of the 4 control points that affect each real vertex
	CTexture2D* m_posTex; // IO: Contain real vertices' position computed as a function of control points' position
	CTexture2D* m_normalTex; // IO: Contain real vertices' normal

	CTexture2D* m_debugTex; // For debugging purpose
	CTexture2D* m_debugTex2; // For debugging purpose

	CTexture2D* m_minsTex; // IO: Bounding box mins, cmTexH x cmTexW
	CTexture2D* m_nmaxsTex; // IO: Negated Bounding box maxs, cmTexH x cmTexW
	CTexture2D* m_cubeMapAtlasTex; // Store uv coordinate for looking up into a 2D texture atlas of flatten cube maps
	CTexture2D* m_cube2DTex; // Texture 2D array of the flatten cube map for each clusters

	D3D10_VIEWPORT m_cubeViewports[6]; // The viewport for the 6 sides of the cube maps to be rendered to 

	// Height map
	float* heightData; // The height map data for internal use
	
	int m_sumPerPixel;	// Number of terms to sum by a pixel
	int m_pixelPerRow;	// Number of pixels used for summation in a row 

	// Vertex buffer for GPGPU stuffs
	CVertexBuffer<GPGPUVertex>* m_gpgpuVB;	

	// This section is for GPGPU quad/point/triangle drawing
	// ...Start is the variable that stores the first index in the m_gpgpuVB that should be used for rendering the GPGPU primitive
	// ...Num is the variable that stores the number of vertices that the draw call should use
	// ...VP is the viewport that the GPGPU stuffs should be rendered to

	// Pass for computing xVal
	int m_computeXValStart;	
	D3D10_VIEWPORT m_computeXValVP;

	// Pass for computing CM
	int m_computeCMStart;
	int m_computeCMNum;
	D3D10_VIEWPORT m_computeCMVP;

	// Pass for computing ApqBar
	int m_computeApqBarStart;
	int m_computeApqBarNum;
	D3D10_VIEWPORT m_computeApqBarVP;

	// Pass for computing transform
	int m_computeTransformStart;
	int m_computeTransformNum;
	D3D10_VIEWPORT m_computeTransformVP;

	// Pass for computing goal position of the control points in each of the clusters
	int m_computeClusterGoalPositionStart;
	int m_computeClusterGoalPositionNum;
	D3D10_VIEWPORT m_computeClusterGoalPositionVP;

	// Pass for computing goal position of the control points (by averaging the goal positions of the control point for each cluster that influences this control point)
	int m_computeGoalPosStart;
	int m_computeGoalPosNum;
	D3D10_VIEWPORT m_computeGoalPosVP;

	// Pass for updating the velocity and position of the control points
	int m_updateVelAndPosStart;
	D3D10_VIEWPORT m_updateVelAndPosVP;

	// Pass for computing the surface mesh' vertices' position
	int m_computeRealPosStart;
	D3D10_VIEWPORT m_computeRealPosVP;
	D3D10_VIEWPORT m_computeNormalVP;

	// Pass for computing collision force
	D3D10_VIEWPORT m_computeCollisionForceVP;
	
	// Pass for computing pVal
	int m_computePValStart;
	int m_computePValNum;
	D3D10_VIEWPORT m_computePValVP;

	// Pass for computing the forces applied to the picked vertices
	D3D10_VIEWPORT m_computePickingForceVP;


	// Index for the pingpong buffers for read/write
	int m_forRead;
	int m_forWrite;

	ID3D10Buffer *m_pickedVerticesBuffer;	// Buffer containing vertices that are picked
	ID3D10Buffer *m_collidingPairsBuffer;	// Buffer containing pairs of clusters that potentially collide
	ID3D10Buffer *m_debugBuffer;			// Staging buffer for debugging purpose

	// Cube Map
	UINT m_CubePerRow;						// Number of cubes per row int the flatten cube map texture
	UINT m_Resolution;						// The resolution of the cube map for collision detection, need not be too big

	bool doneLoading;
	float* m_allBetas;						// Beta for each cluster
	float* m_allAlphas;						// Alpha for each cluster
	DWORD m_numObjects;						// number of objects
	bool m_updateAlphas;					// Whether the program should update the objects' alpha
	bool m_updateBetas;						// Whether the program should update the objects' beta
	bool m_updateHardnesss;					// Whether the program should update the objects' hardness
	DWORD m_currentFrame;					// Frame number
	DWORD m_cubeMapUpdateFreq;				// How frequently we update the cube map
};

#endif