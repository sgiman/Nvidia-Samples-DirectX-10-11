//----------------------------------------------------------------------------------
// File:   DeformableBody.cpp
// Author: Nuttapong Chentanez
// Email:  sdkfeedback@nvidia.com
//
// Deformable Physics is based on Meshless Deformations Based on Shape Matching by M. Mueller, B. Heidelberger, M. Teschner, M. Gross.
// Collision detection and response is done with cube map look up.
// All run-time computation is done on the GPU.
// 
// Copyright (c) 2007 NVIDIA Corporation. All rights reserved.
//
// TO  THE MAXIMUM  EXTENT PERMITTED  BY APPLICABLE  LAW, THIS SOFTWARE  IS PROVIDED
// *AS IS*  AND NVIDIA AND  ITS SUPPLIERS DISCLAIM  ALL WARRANTIES,  EITHER  EXPRESS
// OR IMPLIED, INCLUDING, BUT NOT LIMITED  TO, IMPLIED WARRANTIES OF MERCHANTABILITY
// AND FITNESS FOR A PARTICULAR PURPOSE.  IN NO EVENT SHALL  NVIDIA OR ITS SUPPLIERS
// BE  LIABLE  FOR  ANY  SPECIAL,  INCIDENTAL,  INDIRECT,  OR  CONSEQUENTIAL DAMAGES
// WHATSOEVER (INCLUDING, WITHOUT LIMITATION,  DAMAGES FOR LOSS OF BUSINESS PROFITS,
// BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION, OR ANY OTHER PECUNIARY LOSS)
// ARISING OUT OF THE  USE OF OR INABILITY  TO USE THIS SOFTWARE, EVEN IF NVIDIA HAS
// BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
//

//----------------------------------------------------------------------------------
//      READ THIS FIRST
// See the "READ THIS FIRST" section in the deformableObjects.h
//----------------------------------------------------------------------------------
//----------------------------------------------------------------------------------
// Modified by Sergey Gasanov (sgiman) @ 2013, september
// Sgiman Creative Studio (sgiman.com)
//----------------------------------------------------------------------------------


#include "DXUT.h"
#include "DXUTmisc.h"
#include "resource.h"
#include "Buffers.h"
#include "Effects.h"
#include "Textures.h"
#include "SDKmisc.h"
#include "SDKmesh.h"
#include "DeformableObjects.h"
#include "ObjFile.h"
#include "DXUTcamera.h"
#include "Landscape.h"
#include "DXUTgui.h"

#define DEG2RAD( a ) ( a * D3DX_PI / 180.f )

// Stop the warning about 64-bit pointer casts.
#pragma warning(disable:4311)

// Stop the depreciated warning
#pragma warning(disable:4996 4995)

//--------------------------------------------------------------------------------------
// UI control IDs
//--------------------------------------------------------------------------------------
#define IDC_FLOORHARDNESS_TEXT			1
#define IDC_FLOORHARDNESS_VALUE			2
#define IDC_GRAVITY_TEXT				3
#define IDC_GRAVITY_VALUE				4
#define IDC_AIRDRAG_TEXT				5
#define IDC_AIRDRAG_VALUE				6
#define IDC_SPRINGK_TEXT				7
#define IDC_SPRINGK_VALUE				8
#define IDC_CUBEMAPUPDATEFREQ_TEXT		9
#define IDC_CUBEMAPUPDATEFREQ_VALUE		10
#define IDC_CURRENTOBJECT_COMBO			11
#define IDC_ALPHA_TEXT					12
#define IDC_ALPHA_VALUE					13
#define IDC_BETA_TEXT					14
#define IDC_BETA_VALUE					15
#define IDC_HARDNESS_TEXT				16
#define IDC_HARDNESS_VALUE				17
#define IDC_SWITCHDEMO_BUTTON			18
#define IDC_RESETDEMO_BUTTON			19
#define IDC_CHANGEDEVICE_BUTTON			20
#define IDC_TOGGLEFULLSCREEN_BUTTON		21

// Defaults
#define DEFAULT_FLOOR_HARDNESS 2000.0f
#define DEFAULT_AIR_DRAG 0.95f
#define DEFAULT_SPRING_K 500.0f
#define DEFAULT_GRAVITY 38.0f
#define DEFAULT_CUBEMAP_UPDATE_FREQ 10

enum DEMO_TYPE {DEMO_STACKING, DEMO_CONSTRAINING};
DEMO_TYPE g_currentDemoType = DEMO_CONSTRAINING;

// Parameters
float								 g_floorHardness = DEFAULT_FLOOR_HARDNESS;
float								 g_airDrag = DEFAULT_AIR_DRAG;
float								 g_springK = DEFAULT_SPRING_K;
float								 g_gravity = DEFAULT_GRAVITY;
int									 g_cubeMapUpdateFreq = DEFAULT_CUBEMAP_UPDATE_FREQ;
int									 g_currentObjTypeSelected = 0;
//--------------------------------------------------------------------------------------
// Global Variables
//--------------------------------------------------------------------------------------
CDeformableObjects					*g_defTest = NULL;
CLandscape							*g_landscape = NULL;

D3DXMATRIX                          g_world;						// Current world matrix
D3DXMATRIX                          g_projection;					// Current projection matrix
CFirstPersonCamera					g_camera;						// Camera

// Pulling / Picking related variables
const D3DXVECTOR2					g_pickSize(0.05f, 0.05f);	    // The size of the box around the mouse
bool								g_pull = false;					// Flag whether the picked vertices should be pulled by the mouse movment or not
bool								g_pick = false;					// Flag whether we should pick the vertices underneath the mouse in this frame or not
D3DXVECTOR2							g_pickMins;						// The lower bound of the box around the current mouse position, in normalized space -1..1
D3DXVECTOR2							g_pickMaxs;						// The upper bound of the box around the current mouse position, in normalized space -1..1
D3DXVECTOR2							g_mousePos;						// Current mouse position


// Rendering window related variables
const UINT							g_UIWidth = 1024;				// Wod
const UINT							g_UIHeight = 800;
const UINT							g_UIItemWidth = 130;
UINT								g_currentWidth = 1024;			// Width of the viewport
UINT								g_currentHeight = 800;			// Height of the viewport
D3DVIEWPORT9						g_viewport9;					// DX9 viewport structure
ID3D10RenderTargetView 			   *g_renderTargetView[1] = {NULL};	// Saved render target 
ID3D10DepthStencilView			   *g_depthStencilView = NULL;		// Saved stencil buffer	
D3D10_VIEWPORT						g_viewport;						// Saved viewport
bool								g_needToUpdateViews = true;		// Whether or not we should update the 
ID3DX10Font*						g_pFont10 = NULL;       
ID3DX10Sprite*						g_pSprite10 = NULL;
CDXUTTextHelper*					g_pTxtHelper = NULL;			// For displaying texts
bool								g_switchDemo = false;
bool								g_resetDemo = false;

CDXUTDialogResourceManager			g_DialogResourceManager;		// manager for shared resources of dialogs
CDXUTDialog							g_UI;							// dialog for sample specific controls
CD3DSettingsDlg						g_SettingsDlg;					// Device settings dialog
bool								g_bShowHelp = false;			// Whether we should show the help text or not
//--------------------------------------------------------------------------------------
// Forward declarations 
//--------------------------------------------------------------------------------------
bool    CALLBACK IsD3D10DeviceAcceptable( UINT Adapter, UINT Output, D3D10_DRIVER_TYPE DeviceType, DXGI_FORMAT BufferFormat, bool bWindowed, void* pUserContext );
HRESULT CALLBACK OnD3D10CreateDevice( ID3D10Device* pd3dDevice, const DXGI_SURFACE_DESC* pBufferSurfaceDesc, void* pUserContext );
HRESULT CALLBACK OnD3D10ResizedSwapChain( ID3D10Device* pd3dDevice, IDXGISwapChain *pSwapChain, const DXGI_SURFACE_DESC* pBufferSurfaceDesc, void* pUserContext );
void    CALLBACK OnD3D10FrameRender( ID3D10Device* pd3dDevice, double fTime, float fElapsedTime, void* pUserContext );
void    CALLBACK OnD3D10ReleasingSwapChain( void* pUserContext );
void    CALLBACK OnD3D10DestroyDevice( void* pUserContext );

LRESULT CALLBACK MsgProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam, bool* pbNoFurtherProcessing, void* pUserContext );
void    CALLBACK OnKeyboard( UINT nChar, bool bKeyDown, bool bAltDown, void* pUserContext );
void    CALLBACK OnFrameMove( double fTime, float fElapsedTime, void* pUserContext );
bool    CALLBACK ModifyDeviceSettings( DXUTDeviceSettings* pDeviceSettings, void* pUserContext );
void	CALLBACK OnMouse( bool bLeftButtonDown, bool bRightButtonDown, bool bMiddleButtonDown, bool bSideButton1Down, bool bSideButton2Down, int nMouseWheelDelta, int xPos, int yPos, void* pUserContext );
extern	void ClearTextureManager();
void	InitApp();
void    CALLBACK OnGUIEvent( UINT nEvent, int nControlID, CDXUTControl* pControl, void* pUserContext );

//--------------------------------------------------------------------------------------
// Entry point to the program. Initializes everything and goes into a message processing 
// loop. Idle time is used to render the scene.
//--------------------------------------------------------------------------------------
int WINAPI wWinMain( HINSTANCE hInstance, HINSTANCE hPrevInstance, LPWSTR lpCmdLine, int nCmdShow )
{
    // Enable run-time memory check for debug builds.
#if defined(DEBUG) | defined(_DEBUG)
    _CrtSetDbgFlag( _CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF );
#endif

	DXUTSetMediaSearchPath(L".\\Media");
	// Set DXUT callbacks
    DXUTSetCallbackD3D10DeviceAcceptable( IsD3D10DeviceAcceptable );
    DXUTSetCallbackD3D10DeviceCreated( OnD3D10CreateDevice );
    DXUTSetCallbackD3D10SwapChainResized( OnD3D10ResizedSwapChain );
    DXUTSetCallbackD3D10SwapChainReleasing( OnD3D10ReleasingSwapChain );
    DXUTSetCallbackD3D10DeviceDestroyed( OnD3D10DestroyDevice );
    DXUTSetCallbackD3D10FrameRender( OnD3D10FrameRender );

	DXUTSetCallbackMouse(OnMouse, true);
    DXUTSetCallbackMsgProc( MsgProc );
    DXUTSetCallbackKeyboard( OnKeyboard );
    DXUTSetCallbackFrameMove( OnFrameMove );
    DXUTSetCallbackDeviceChanging( ModifyDeviceSettings );

    DXUTInit( true, true, NULL ); // Parse the command line, show msgboxes on error, no extra command line params
    DXUTSetCursorSettings( true, true ); // Show the cursor and clip it when in full screen
	InitApp();

    DXUTCreateWindow( L"Deformable Body Simulation Demo" );
    DXUTCreateDevice( true, g_currentWidth, g_currentHeight );
    DXUTMainLoop(); // Enter into the DXUT render loop
    return DXUTGetExitCode();
}

//--------------------------------------------------------------------------------------
// Reject any D3D10 devices that aren't acceptable by returning false
//----
//----------------------------------------------------------------------------------
bool CALLBACK IsD3D10DeviceAcceptable( UINT Adapter, UINT Output, D3D10_DRIVER_TYPE DeviceType, DXGI_FORMAT BufferFormat, bool bWindowed, void* pUserContext )
{
	return true;
}

// Data about deformable objects
enum OBJECT_ENUM{O_APPLE, O_GRAPE, O_PLUM, O_SPHERE, O_BOX, O_CYLINDER, O_CACTUS, O_CACTUS_SMALL, O_NUM_OBJ};

typedef struct {
	LPCWSTR name;
	LPCWSTR surfaceName;
	LPCWSTR controlMeshName;
	float alpha;
	float beta;
	float hardness;
	int K;
	D3DXVECTOR3 mins;
	D3DXVECTOR3 maxs;
} DefObjType;

vector<float> g_objDefaultAlphas(O_NUM_OBJ);
vector<float> g_objDefaultBetas(O_NUM_OBJ);
vector<float> g_objDefaultHardnesses(O_NUM_OBJ);

vector<int>  g_objsOfEachType[O_NUM_OBJ];
DefObjType g_defObjs[O_NUM_OBJ] = {
	{L"Apple", L"apple.obj", NULL, 1.0f, 0.5f, 3000.0f, 1, D3DXVECTOR3(1e10, 1e10, 1e10), D3DXVECTOR3(-1e10, -1e10, -1e10) },
	{L"Grape", L"grape.obj", NULL, 1.0f, 0.35f, 3000.0f, 1, D3DXVECTOR3(1e10, 1e10, 1e10), D3DXVECTOR3(-1e10, -1e10, -1e10)},
	{L"Plum", L"plum.obj", NULL, 0.64f, 0.1f, 3000.0f, 1, D3DXVECTOR3(1e10, 1e10, 1e10), D3DXVECTOR3(-1e10, -1e10, -1e10)},
	{L"Sphere", L"sphere.obj", L"sphere.tetmesh", 0.5f, 0.5f, 3000.0f, 1, D3DXVECTOR3(1e10, 1e10, 1e10), D3DXVECTOR3(-1e10, -1e10, -1e10)},
	{L"Box", L"box.obj", L"box.tetmesh", 1.0f, 0.0f, 5000.0f, 1, D3DXVECTOR3(1e10, 1e10, 1e10), D3DXVECTOR3(-1e10, -1e10, -1e10)},
	{L"Capsule", L"cylinder.obj", L"cylinder.tetmesh", 0.22f, 0.12f, 3000.0f, 1, D3DXVECTOR3(1e10, 1e10, 1e10), D3DXVECTOR3(-1e10, -1e10, -1e10)},	
	{L"Cactus", L"cactus.obj", L"cactus.tetmesh", 0.94f, 0.44f, 3000.0f, 5, D3DXVECTOR3(-1.0f, 0.0f, -1.0f) , D3DXVECTOR3(1.0f, 1.5f, 1.0f)},
	{L"Small Cactus", L"cactus_small.obj", NULL, 0.5f, 0.7f, 3000.0f, 1, D3DXVECTOR3(-3.0f, 0.0f, -3.0f), D3DXVECTOR3(3.0f, 0.3f, 3.0f)},
};

void CreateInitialObjects( DEMO_TYPE whichDemo, ID3D10Device* pd3dDevice, CDeformableObjects*& defTest ) {
	// Clear the list of objects of each type
	for (int i = 0; i < O_NUM_OBJ; i++) {
		g_objsOfEachType[i].clear();
	}

	//return;
	// Create the initial objects configuration
	const DWORD numCactus = 5;
	const DWORD numCactus_Small = 8;
	const DWORD numRandomStuffs = 50;
	const DWORD numStackingStuffs = 120;
	const DWORD totalNumStuffs = max(numCactus + numCactus_Small + numRandomStuffs, numStackingStuffs) ;
	
	const int cactusPixPos[numCactus][2] = { 
									 {128, 128},
									 {141, 200},
									 {141, 86},
									 {73, 118},
									 {165, 177},								 
									 };
	const int cactus_SmallPixPos[numCactus_Small][2] = { 
									 {107, 95}, 
									 {144,109},
									 {171,114},
									 {106,118},
									 {136,137},
									 {87,153},
									 {121,168},
									 {164,162}};


	LPCWSTR fileNames[totalNumStuffs];
	LPCWSTR meshNames[totalNumStuffs];
	D3DXMATRIX initTransforms[totalNumStuffs];
	float alphas[totalNumStuffs];
	float betas[totalNumStuffs];
	float hardness[totalNumStuffs];
	DWORD K[totalNumStuffs];
	D3DXVECTOR3 constrainedMins[totalNumStuffs];
	D3DXVECTOR3 constrainedMaxs[totalNumStuffs];
	bool isRelativeToGround[totalNumStuffs];
	OBJECT_ENUM types[totalNumStuffs];
	
	LPCWSTR heightMapName = L"height_new.dds";
	D3DXVECTOR3 heightMapScale(80, 20, 80);
	
	D3DXVECTOR3 pixScaling = D3DXVECTOR3(heightMapScale.x/256.0f, heightMapScale.y/256.0f, heightMapScale.z/256.0f);
	
	DWORD currentIndex = 0;

	if (whichDemo == DEMO_STACKING) {
		for (DWORD i = 0; i < numStackingStuffs; i++) {
			types[currentIndex] = (OBJECT_ENUM)(rand() % 6);
			D3DXMatrixTranslation(&initTransforms[currentIndex],  0.0f, 2.0f +i*1.5f, 0.0f);
			isRelativeToGround[currentIndex] = true;
			currentIndex++;

		}
	} else
	if (whichDemo == DEMO_CONSTRAINING) {
		for (DWORD i = 0; i < numCactus; i++) {
			types[currentIndex] = O_CACTUS;
			D3DXMatrixTranslation(&initTransforms[currentIndex], cactusPixPos[i][0]*pixScaling.x-heightMapScale.x*0.5f , -0.2f, cactusPixPos[i][1]*pixScaling.z-heightMapScale.z*0.5f);
			isRelativeToGround[currentIndex] = true;
			currentIndex++;
		}

		for (DWORD i = 0; i < numCactus_Small; i++) {
			types[currentIndex] = O_CACTUS_SMALL;
			D3DXMatrixTranslation(&initTransforms[currentIndex], cactus_SmallPixPos[i][0]*pixScaling.x-heightMapScale.x*0.5f , -0.2f, cactus_SmallPixPos[i][1]*pixScaling.z-heightMapScale.z*0.5f);
			isRelativeToGround[currentIndex] = true;
			currentIndex++;
		}
		
		for (DWORD i = 0; i < numRandomStuffs; i++) {
			types[currentIndex] = (OBJECT_ENUM)(rand() % 6);
			D3DXMatrixTranslation(&initTransforms[currentIndex], ((rand() % 10000) / 9999.0f)*heightMapScale.x*0.2f-heightMapScale.x*0.1f ,5.0f, ((rand() % 10000) / 9999.0f)*heightMapScale.z*0.2f -heightMapScale.z*0.1f);
			isRelativeToGround[currentIndex] = true;
			currentIndex++;
		}
	}

	for (DWORD i = 0; i < currentIndex; i++) {
		DWORD objIndex = types[i];
		fileNames[i] = g_defObjs[objIndex].surfaceName;
		meshNames[i] = g_defObjs[objIndex].controlMeshName;
		K[i] = g_defObjs[objIndex].K;
		alphas[i] = g_defObjs[objIndex].alpha;
		betas[i] = g_defObjs[objIndex].beta;
		hardness[i] = g_defObjs[objIndex].hardness;
		constrainedMins[i] = g_defObjs[objIndex].mins;  
		constrainedMaxs[i] = g_defObjs[objIndex].maxs; 
		g_objsOfEachType[objIndex].push_back(i);
	}
	defTest = new CDeformableObjects(currentIndex, fileNames, meshNames, initTransforms, isRelativeToGround, K, alphas, betas, hardness, constrainedMins, constrainedMaxs, g_floorHardness, pd3dDevice, heightMapName, heightMapScale, g_airDrag, g_springK, g_gravity, g_cubeMapUpdateFreq);
}


//--------------------------------------------------------------------------------------
// Create any D3D10 resources that aren't dependant on the back buffer
//--------------------------------------------------------------------------------------
HRESULT CALLBACK OnD3D10CreateDevice( ID3D10Device* pd3dDevice, const DXGI_SURFACE_DESC *pBufferSurfaceDesc, void* pUserContext )
{

	HRESULT hr;
    V_RETURN( g_DialogResourceManager.OnD3D10CreateDevice(pd3dDevice));
	V_RETURN( g_SettingsDlg.OnD3D10CreateDevice( pd3dDevice ) );
	// Create some fonts
    V_RETURN( D3DX10CreateFont( pd3dDevice, 16, 0, FW_BOLD, 1, FALSE, DEFAULT_CHARSET, 
                                OUT_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, 
                                L"Arial", &g_pFont10 ) );
    V_RETURN( D3DX10CreateSprite( pd3dDevice, 300, &g_pSprite10 ) );
    g_pTxtHelper = new CDXUTTextHelper( NULL, NULL, g_pFont10, g_pSprite10, 15 );
	
	//save off global defaults
	for (int i = 0; i < O_NUM_OBJ; ++i) {
		g_objDefaultAlphas[i] = g_defObjs[i].alpha;
		g_objDefaultBetas[i] = g_defObjs[i].beta;
		g_objDefaultHardnesses[i] = g_defObjs[i].hardness;
	}

	// Create objects
	CreateInitialObjects( g_currentDemoType, pd3dDevice , g_defTest);

	// Create the landscape object
	if (g_defTest) {
		g_landscape = new CLandscape(pd3dDevice, g_defTest->m_heightMapScale.x,g_defTest->m_heightMapScale.z, g_defTest->m_heightNormalMapTex);
	}

	// Initialize camera
    D3DXVECTOR3 Eye( 3.0f, 10.5f, -11.0f );
    D3DXVECTOR3 At( 0.0f, 5.0f, 0.0f );
	
	g_camera.SetViewParams(&Eye, &At);
	g_camera.SetRotateButtons(false, false, true, false);

	// Initialize the viewport
	g_viewport9.Width = g_currentWidth;
	g_viewport9.Height = g_currentHeight;
	g_viewport9.MinZ = 0.0f;
	g_viewport9.MaxZ = 1.0f;
	g_viewport9.X = 0;
	g_viewport9.Y = 0;

	// Set the world matrix to identity
	D3DXMatrixIdentity(&g_world);


	return S_OK;
}
WCHAR g_tmpText[500];


WCHAR* FormatedText(WCHAR* str, ...){
	va_list ap;
	va_start(ap, str);
	vswprintf(g_tmpText, str, ap);	
	va_end (ap);
	return &(g_tmpText[0]);
}
//--------------------------------------------------------------------------------------
// Initialize the app 
//--------------------------------------------------------------------------------------
void UpdateTexts() {
   
	g_UI.GetStatic( IDC_FLOORHARDNESS_TEXT )->SetText( FormatedText(L"Floor Hardness = %0.0f", g_floorHardness) );
	g_UI.GetStatic( IDC_GRAVITY_TEXT )->SetText( FormatedText(L"Gravity = %0.1f", g_gravity) );
	g_UI.GetStatic( IDC_AIRDRAG_TEXT )->SetText( FormatedText(L"Air Drag = %0.2f", g_airDrag) );
	g_UI.GetStatic( IDC_SPRINGK_TEXT )->SetText( FormatedText(L"Spring Constant = %0.0f", g_springK) );
    g_UI.GetStatic( IDC_CUBEMAPUPDATEFREQ_TEXT )->SetText( FormatedText(L"Cubemap update rate = %d", g_cubeMapUpdateFreq) );
	
	g_UI.GetStatic( IDC_ALPHA_TEXT )->SetText( FormatedText(L"Alpha = %0.2f", g_defObjs[g_currentObjTypeSelected].alpha));
	g_UI.GetStatic( IDC_BETA_TEXT )->SetText( FormatedText(L"Beta = %0.2f", g_defObjs[g_currentObjTypeSelected].beta));
	g_UI.GetStatic( IDC_HARDNESS_TEXT )->SetText( FormatedText(L"Hardness = %d", (int)g_defObjs[g_currentObjTypeSelected].hardness));

	g_UI.GetSlider( IDC_FLOORHARDNESS_VALUE )->SetValue( (int)g_floorHardness );
	g_UI.GetSlider( IDC_GRAVITY_VALUE )->SetValue( (int)(g_gravity * 10.0f) );
	g_UI.GetSlider( IDC_AIRDRAG_VALUE )->SetValue( (int)(g_airDrag * 1000.0f) );
	g_UI.GetSlider( IDC_SPRINGK_VALUE )->SetValue( (int)g_springK );
	g_UI.GetSlider( IDC_CUBEMAPUPDATEFREQ_VALUE )->SetValue( (int)g_cubeMapUpdateFreq );

	g_UI.GetSlider( IDC_ALPHA_VALUE)->SetValue((int)(g_defObjs[g_currentObjTypeSelected].alpha*100));
	g_UI.GetSlider( IDC_BETA_VALUE)->SetValue((int)(g_defObjs[g_currentObjTypeSelected].beta*100));
	g_UI.GetSlider( IDC_HARDNESS_VALUE)->SetValue((int)(g_defObjs[g_currentObjTypeSelected].hardness));

}

void InitApp() {
	const int padding = 20;
	g_SettingsDlg.Init( &g_DialogResourceManager );
    g_UI.Init( &g_DialogResourceManager );
	g_UI.SetCallback(OnGUIEvent);

    g_UI.SetFont( 1, L"Comic Sans MS", 24, FW_NORMAL );
    g_UI.SetFont( 2, L"Courier New", 16, FW_NORMAL );
	int incY = 0;
	int lineSpacing = 20;
	incY += lineSpacing / 2;
    int widthOffset = 0;
	g_UI.AddButton( IDC_TOGGLEFULLSCREEN_BUTTON, L"Toggle Full Screen", g_UIWidth-g_UIItemWidth-padding, incY, g_UIItemWidth - widthOffset, lineSpacing );incY += lineSpacing;
	incY += lineSpacing / 2;
	g_UI.AddButton( IDC_CHANGEDEVICE_BUTTON, L"Change Device (F2)", g_UIWidth-g_UIItemWidth-padding, incY, g_UIItemWidth - widthOffset, lineSpacing, VK_F2 );incY += lineSpacing;
	incY += lineSpacing / 2;
   	g_UI.AddButton( IDC_SWITCHDEMO_BUTTON, L"Change Demo", g_UIWidth-g_UIItemWidth-padding, incY, g_UIItemWidth - widthOffset, lineSpacing );incY += lineSpacing;
	incY += lineSpacing / 2;
	g_UI.AddButton( IDC_RESETDEMO_BUTTON, L"Reset Demo", g_UIWidth-g_UIItemWidth-padding, incY, g_UIItemWidth - widthOffset, lineSpacing );incY += lineSpacing;
	incY += lineSpacing / 2;
	g_UI.AddStatic( IDC_FLOORHARDNESS_TEXT, L"", g_UIWidth-g_UIItemWidth-padding, incY, g_UIItemWidth, lineSpacing ); incY += lineSpacing;
	g_UI.AddSlider( IDC_FLOORHARDNESS_VALUE, g_UIWidth-g_UIItemWidth-padding, incY, g_UIItemWidth, lineSpacing, 100, 3000, (int)g_floorHardness); incY += lineSpacing;
	g_UI.AddStatic( IDC_GRAVITY_TEXT, L"", g_UIWidth-g_UIItemWidth-padding, incY, g_UIItemWidth, lineSpacing ); incY += lineSpacing;
	g_UI.AddSlider( IDC_GRAVITY_VALUE, g_UIWidth-g_UIItemWidth-padding, incY, g_UIItemWidth, lineSpacing, 10, 500, (int)(g_gravity*10.0f)); incY += lineSpacing;
	g_UI.AddStatic( IDC_AIRDRAG_TEXT, L"", g_UIWidth-g_UIItemWidth-padding, incY, g_UIItemWidth, lineSpacing ); incY += lineSpacing;
	g_UI.AddSlider( IDC_AIRDRAG_VALUE, g_UIWidth-g_UIItemWidth-padding, incY, g_UIItemWidth, lineSpacing, 500, 970, (int)(g_airDrag*1000.0f)); incY += lineSpacing;
	g_UI.AddStatic( IDC_SPRINGK_TEXT, L"", g_UIWidth-g_UIItemWidth-padding, incY, g_UIItemWidth, lineSpacing ); incY += lineSpacing;
	g_UI.AddSlider( IDC_SPRINGK_VALUE, g_UIWidth-g_UIItemWidth-padding, incY, g_UIItemWidth, lineSpacing, 100, 1500, (int)g_springK); incY += lineSpacing;
	g_UI.AddStatic( IDC_CUBEMAPUPDATEFREQ_TEXT, L"", g_UIWidth-g_UIItemWidth-padding, incY, g_UIItemWidth, lineSpacing ); incY += lineSpacing;
	g_UI.AddSlider( IDC_CUBEMAPUPDATEFREQ_VALUE, g_UIWidth-g_UIItemWidth-padding, incY, g_UIItemWidth, lineSpacing, 1, 20, (int)g_cubeMapUpdateFreq); incY += lineSpacing;

	incY += lineSpacing / 2;
	CDXUTComboBox *pCombo;
    g_UI.AddComboBox( IDC_CURRENTOBJECT_COMBO, g_UIWidth-g_UIItemWidth-padding, incY, g_UIItemWidth, lineSpacing, L'O', false, &pCombo );incY += lineSpacing;
    for( int i = 0; i < O_NUM_OBJ; ++i )
    {
		pCombo->SetDropHeight( 100 );
		pCombo->AddItem( g_defObjs[i].name, (LPVOID)(size_t)i );
    }	
	incY += lineSpacing / 2;

	g_UI.AddStatic( IDC_ALPHA_TEXT, L"", g_UIWidth-g_UIItemWidth-padding, incY, g_UIItemWidth, lineSpacing ); incY += lineSpacing;
	g_UI.AddSlider( IDC_ALPHA_VALUE, g_UIWidth-g_UIItemWidth-padding, incY, g_UIItemWidth, lineSpacing, 10, 100, (int)(g_defObjs[g_currentObjTypeSelected].alpha*100)); incY += lineSpacing;

	g_UI.AddStatic( IDC_BETA_TEXT, L"", g_UIWidth-g_UIItemWidth-padding, incY, g_UIItemWidth, lineSpacing ); incY += lineSpacing;
	g_UI.AddSlider( IDC_BETA_VALUE, g_UIWidth-g_UIItemWidth-padding, incY, g_UIItemWidth, lineSpacing, 0, 70, (int)(g_defObjs[g_currentObjTypeSelected].beta*100)); incY += lineSpacing;

	g_UI.AddStatic( IDC_HARDNESS_TEXT, L"", g_UIWidth-g_UIItemWidth-padding, incY, g_UIItemWidth, lineSpacing ); incY += lineSpacing;
	g_UI.AddSlider( IDC_HARDNESS_VALUE, g_UIWidth-g_UIItemWidth-padding, incY, g_UIItemWidth, lineSpacing, 100, 5000, (int)(g_defObjs[g_currentObjTypeSelected].hardness)); incY += lineSpacing;

	incY += lineSpacing / 2;

	g_UI.SetSize(g_UIWidth, g_UIHeight);
	g_UI.SetLocation(0, 0);
	UpdateTexts();
}

//--------------------------------------------------------------------------------------
// Create any D3D10 resources that depend on the back buffer
// Create and set the depth stencil texture if needed
//--------------------------------------------------------------------------------------
HRESULT CALLBACK OnD3D10ResizedSwapChain( ID3D10Device* pd3dDevice, IDXGISwapChain *pSwapChain, const DXGI_SURFACE_DESC* pBufferSurfaceDesc, void* pUserContext )
{
	HRESULT hr;
	V_RETURN( g_DialogResourceManager.OnD3D10ResizedSwapChain(pd3dDevice, pBufferSurfaceDesc));
    V_RETURN( g_SettingsDlg.OnD3D10ResizedSwapChain( pd3dDevice, pBufferSurfaceDesc ) );

    // Setup the projection parameters again
	g_currentWidth = pBufferSurfaceDesc->Width;
	g_currentHeight = pBufferSurfaceDesc->Height;
    float fAspect = static_cast<float>( pBufferSurfaceDesc->Width )/static_cast<float>( pBufferSurfaceDesc->Height );

	// Set the projection matrix
    D3DXMatrixPerspectiveFovLH(&g_projection, D3DX_PI * 0.25f, fAspect, 0.01f, 100.0f );	
	if (g_landscape) {
		g_landscape->SetProjectionMat(&g_projection);
	}

	// Setup the camera's projection parameters
    g_camera.SetProjParams( D3DX_PI/4, fAspect, 0.01f, 100.0f );
	
	// Update the viewport
	g_viewport9.Width = g_currentWidth;
	g_viewport9.Height = g_currentHeight;


	g_needToUpdateViews = true;

	g_UI.SetSize(g_UIWidth, g_UIHeight);
	g_UI.SetLocation(pBufferSurfaceDesc->Width - g_UIWidth, 0);
	return S_OK;
}

//--------------------------------------------------------------------------------------
// Render the help and statistics text
//--------------------------------------------------------------------------------------
void RenderText()
{
   	long w,h; // Screen Size

	w =  DXUTGetWindowWidth();		// Screen Width 
	h =  DXUTGetWindowHeight();		// Scre�n Height	

	g_pTxtHelper->Begin();
    g_pTxtHelper->SetInsertionPos( 2, 0 );
    g_pTxtHelper->SetForegroundColor( D3DXCOLOR( 1.0f, 1.0f, 0.0f, 1.0f ) );
    g_pTxtHelper->DrawTextLine( DXUTGetFrameStats(true) );
	g_pTxtHelper->DrawTextLine( DXUTGetDeviceStats() );

    // Draw help
    if( g_bShowHelp )
    {
        g_pTxtHelper->SetInsertionPos( 10, g_currentHeight-15*15 );
        g_pTxtHelper->SetForegroundColor( D3DXCOLOR( 1.0f, 0.75f, 0.0f, 1.0f ) );
        g_pTxtHelper->DrawTextLine( L"Controls (F1 to hide):" );

		g_pTxtHelper->SetInsertionPos( 40, g_currentHeight-15*14 );
        g_pTxtHelper->DrawTextLine( L"Pick & Pull: Left click and drag\n"
                                L"Rotate camera: Right button drag\n"
                                L"Move Around: WASD\n"
								L"Floor Hardness: Penalty constant of collision agains the floor\n"
								L"Gravity: Acceleration of gravity\n"
								L"Air Drag: Coefficient to reduce velocity at each time step\n"
								L"Spring Constant: How hard you pull on te object\n"
								L"Cube map update: How often cube map is updated for collision detection\n"
								L"Alpha : Control how much you move objects toward the goal position in a time step\n"
								L"Beta : Control the blending between rigid & optimum quadratic transformation\n"
								);
    }
    else
    {
        g_pTxtHelper->SetForegroundColor( D3DXCOLOR( 1.0f, 1.0f, 1.0f, 1.0f ) );
        g_pTxtHelper->DrawTextLine( L"Press F1 for help" );
    }
    
	/**************************************************************************/
	// Test Deformable Body   
	// Sgiman Creative Studio (sgiman.com)
	g_pTxtHelper->SetInsertionPos(2, h-35);
    g_pTxtHelper->SetForegroundColor(D3DXCOLOR( 0.0f, 1.0f, 1.0f, 1.0f));
	g_pTxtHelper->DrawTextLine(L"Test Deformable Body");
    g_pTxtHelper->SetForegroundColor(D3DXCOLOR( 1.0f, 1.0f, 1.0f, 1.0f));
	g_pTxtHelper->DrawTextLine(L"Sgiman Creative Studio (sgiman.com)");
	/**************************************************************************/

	g_pTxtHelper->End();
}

//--------------------------------------------------------------------------------------
// Render the scene using the D3D10 device
//--------------------------------------------------------------------------------------
void CALLBACK OnD3D10FrameRender( ID3D10Device* pd3dDevice, double fTime, float fElapsedTime, void* pUserContext )
    

{
	if (g_needToUpdateViews) {
		g_renderTargetView[0] = DXUTGetD3D10RenderTargetView();
		g_depthStencilView = DXUTGetD3D10DepthStencilView();

		// Save the viewport   
		UINT cRT = 1;
		pd3dDevice->RSGetViewports( &cRT, &g_viewport );
	}

	if (g_switchDemo) {

        //change cursor to hourglass
        const HCURSOR hcurSave = SetCursor(LoadCursor(0, IDC_WAIT));

		ClearTextureManager();
		if (g_currentDemoType == DEMO_STACKING) {
			g_currentDemoType = DEMO_CONSTRAINING;
		} else {
			g_currentDemoType = DEMO_STACKING;
		}
		SAFE_DELETE(g_landscape);
		SAFE_DELETE(g_defTest);

		CDeformableObjects*					defTestTmp = NULL;
		CLandscape*							landscapeTmp = NULL;				
		CreateInitialObjects( g_currentDemoType, pd3dDevice , defTestTmp);

		if (defTestTmp) {
			landscapeTmp = new CLandscape(pd3dDevice, defTestTmp->m_heightMapScale.x,defTestTmp->m_heightMapScale.z, defTestTmp->m_heightNormalMapTex);
			landscapeTmp->SetProjectionMat(&g_projection);
		}
		g_landscape = landscapeTmp;
		g_defTest = defTestTmp;
		g_switchDemo = false;
        
        //restore old cursor
        SetCursor(hcurSave);
	}
	if (g_resetDemo) {

        //change cursor to hourglass
        const HCURSOR hcurSave = SetCursor(LoadCursor(0, IDC_WAIT));

		ClearTextureManager();
		SAFE_DELETE(g_landscape);
		SAFE_DELETE(g_defTest);

		CDeformableObjects*					defTestTmp = NULL;
		CLandscape*							landscapeTmp = NULL;				
		CreateInitialObjects( g_currentDemoType, pd3dDevice , defTestTmp);

		if (defTestTmp) {
			landscapeTmp = new CLandscape(pd3dDevice, defTestTmp->m_heightMapScale.x,defTestTmp->m_heightMapScale.z, defTestTmp->m_heightNormalMapTex);
			landscapeTmp->SetProjectionMat(&g_projection);
		}
		g_landscape = landscapeTmp;
		g_defTest = defTestTmp;

		//restore values
		g_floorHardness = DEFAULT_FLOOR_HARDNESS;
		g_airDrag = DEFAULT_AIR_DRAG;
		g_springK = DEFAULT_SPRING_K;
		g_gravity = DEFAULT_GRAVITY;
		g_cubeMapUpdateFreq = DEFAULT_CUBEMAP_UPDATE_FREQ;
		for (int i = 0; i < O_NUM_OBJ; ++i) {
			g_defObjs[i].alpha = g_objDefaultAlphas[i];
			g_defObjs[i].beta = g_objDefaultBetas[i];
			g_defObjs[i].hardness = g_objDefaultHardnesses[i];
		}

		if (g_defTest) {
			g_defTest->SetFloorHardness(DEFAULT_FLOOR_HARDNESS);
			g_defTest->SetGravity(DEFAULT_GRAVITY);
			g_defTest->SetAirDrag(DEFAULT_AIR_DRAG);
			g_defTest->SetSpringK(DEFAULT_SPRING_K);
			g_defTest->SetCubeMapUpdateFreq(DEFAULT_CUBEMAP_UPDATE_FREQ);

			for (int i = 0; i < O_NUM_OBJ; ++i) {
				g_defTest->SetObjectsAlpha(g_objsOfEachType[i], g_objDefaultAlphas[i]);
				g_defTest->SetObjectsBeta(g_objsOfEachType[i], g_objDefaultBetas[i]);
				g_defTest->SetObjectsHardness(g_objsOfEachType[i], g_objDefaultHardnesses[i]);
			}
		}

		UpdateTexts();
        
        //restore old cursor
        SetCursor(hcurSave);

		g_resetDemo = false;
	}

    //
    // Clear the back buffer
    //
    float ClearColor[4] = { 0.0f, 0.0f, 0.0f, 0.0f }; // red, green, blue, alpha
    ID3D10RenderTargetView* pRTV = DXUTGetD3D10RenderTargetView();
    pd3dDevice->ClearRenderTargetView( pRTV, ClearColor );
	
    //
    // Clear the depth stencil
    //
    ID3D10DepthStencilView* pDSV = DXUTGetD3D10DepthStencilView();
    pd3dDevice->ClearDepthStencilView( pDSV, D3D10_CLEAR_DEPTH, 1.0f, 0 );

	if (g_SettingsDlg.IsActive()) {
		g_SettingsDlg.OnRender( fElapsedTime );
		return;
	}

	// Obtain the eye position
	D3DXVECTOR3 eyePts(*g_camera.GetEyePt());

	// Compute the normalized ray from camera to the near plane where the mouse point to 	
	D3DXVECTOR3 vp(g_mousePos.x, g_mousePos.y, 0.0f);
	D3DXVECTOR3 mousePosOnNearPlane;
	D3DXVec3Unproject(&mousePosOnNearPlane, &vp, &g_viewport9, &g_projection, g_camera.GetViewMatrix(), &g_world);
	D3DXVECTOR3 mouseRay = mousePosOnNearPlane - eyePts;
	D3DXVec3Normalize(&mouseRay, &mouseRay);

	// Do the deformable bodies physics
	if (g_defTest) {
		g_defTest->Compute(pd3dDevice, 0.0166f, g_pull, g_pick, g_pickMins, g_pickMaxs, eyePts, mouseRay);
	}

	// Mouse picking only last for 1 frame, so set it to false
	g_pick = false;

	// Restore old VP
	pd3dDevice->RSSetViewports( 1, &g_viewport );

    // Restore old RT and DS buffer views
    pd3dDevice->OMSetRenderTargets( 1, g_renderTargetView, g_depthStencilView );

	// Render the landscape
	if (g_landscape) {
		g_landscape->Render(pd3dDevice, &g_world, g_camera.GetViewMatrix());
	}

	// Render the deformable objects
	if (g_defTest) {
		g_defTest->Render(pd3dDevice, &g_world, g_camera.GetViewMatrix(), &g_projection);
	}


    // Render the HUD
	
    DXUT_BeginPerfEvent( DXUT_PERFEVENTCOLOR, L"HUD / Stats" );
    RenderText();
    DXUT_EndPerfEvent();
	g_UI.OnRender( fElapsedTime );


	// Flush the device
	pd3dDevice->Flush();
/*
	// Capture screenshots
	static int g_Frame = 0;
	IDXGISwapChain* pSwapChain = DXUTGetDXGISwapChain();
	ID3D10Texture2D* pRT;
	pSwapChain->GetBuffer(0, __uuidof(pRT), reinterpret_cast<void**>(&pRT));
	WCHAR filename[100];
	StringCchPrintf(filename, 100, L"ScreenShots/screenshot%.4d.dds", g_Frame); 
	D3DX10SaveTextureToFile(pRT, D3DX10_IFF_DDS, filename);
	pRT->Release();
	g_Frame++;
*/

}



//--------------------------------------------------------------------------------------
// Release D3D10 resources created in OnD3D10ResizedSwapChain 
//--------------------------------------------------------------------------------------
void CALLBACK OnD3D10ReleasingSwapChain( void* pUserContext )
{
	g_DialogResourceManager.OnD3D10ReleasingSwapChain();
}


//--------------------------------------------------------------------------------------
// Release D3D10 resources created in OnD3D10CreateDevice 
//--------------------------------------------------------------------------------------
void CALLBACK OnD3D10DestroyDevice( void* pUserContext )
{
	// This holds references to device textures which need to be released.
	ClearTextureManager();

	g_SettingsDlg.OnD3D10DestroyDevice();
	g_DialogResourceManager.OnD3D10DestroyDevice();
	// Release the old RT, DS views
    SAFE_RELEASE( g_pFont10 );
    SAFE_RELEASE( g_pSprite10 );
    SAFE_DELETE( g_pTxtHelper );


	SAFE_DELETE(g_defTest);
	SAFE_DELETE(g_landscape);
}


//--------------------------------------------------------------------------------------
// Called right before creating a D3D9 or D3D10 device, allowing the app to modify the device settings as needed
//--------------------------------------------------------------------------------------
bool CALLBACK ModifyDeviceSettings( DXUTDeviceSettings* pDeviceSettings, void* pUserContext )
{
#ifdef _DEBUG
	pDeviceSettings->d3d10.CreateFlags |= D3D10_CREATE_DEVICE_DEBUG ;
#endif
    return true;
}


//--------------------------------------------------------------------------------------
// Handle updates to the scene.  This is called regardless of which D3D API is used
//--------------------------------------------------------------------------------------
void CALLBACK OnFrameMove( double fTime, float fElapsedTime, void* pUserContext )
{
	// Move the camera
    g_camera.FrameMove( fElapsedTime );

}


//--------------------------------------------------------------------------------------
// Handle messages to the application
//--------------------------------------------------------------------------------------
LRESULT CALLBACK MsgProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam, bool* pbNoFurtherProcessing, void* pUserContext )
{
    // Pass messages to settings dialog if its active
    if( g_SettingsDlg.IsActive() )
    {
        g_SettingsDlg.MsgProc( hWnd, uMsg, wParam, lParam );
        return 0;
    }

	// Pass all remaining windows messages to camera so it can respond to user input
    *pbNoFurtherProcessing = g_UI.MsgProc( hWnd, uMsg, wParam, lParam );

    if( *pbNoFurtherProcessing )
        return 0;

    g_camera.HandleMessages( hWnd, uMsg, wParam, lParam );

    return 0;
}


//--------------------------------------------------------------------------------------
// Handle key presses
//--------------------------------------------------------------------------------------
void CALLBACK OnKeyboard( UINT nChar, bool bKeyDown, bool bAltDown, void* pUserContext )
{

    if( bKeyDown )
    {
		//cout<<nChar<<endl;
        switch( nChar )
        {
			case VK_F1:
				g_bShowHelp = !g_bShowHelp;
			break;
        }
    }
}

//--------------------------------------------------------------------------------------
// Handle ke
//--------------------------------------------------------------------------------------
void CALLBACK OnMouse( bool bLeftButtonDown, bool bRightButtonDown, bool bMiddleButtonDown, bool bSideButton1Down, bool bSideButton2Down, int nMouseWheelDelta, int xPos, int yPos, void* pUserContext ) {
	static bool wasLeftDown = false;

	// Store the mouse position
	g_mousePos = D3DXVECTOR2((float)xPos, (float)yPos);

	// Check if left mouse is down or not
	if (bLeftButtonDown) {

		// Check if it was down before or not
		if (!wasLeftDown) {
			// Just click
			wasLeftDown = true;
			
			float invW = 1.0f / g_currentWidth;
			float invH = 1.0f / g_currentHeight;
			
			// Pick!, because just click
			g_pick = true;

			// Compute the screen coordinate of where the mouse points to 
			D3DXVECTOR2 center = D3DXVECTOR2(2*(xPos * invW)-1.0f, 1.0f-2*(yPos * invH));

			// Compute the lower and upper bound around the mouse
			g_pickMins = center - g_pickSize;
			g_pickMaxs = center + g_pickSize;

			// Also set pull to be true
			g_pull = true;
	
		}
	} else {
		if (wasLeftDown) {
			// Just release mouse button
			wasLeftDown = false;

			// Set the pull to be false
			g_pull = false;
		}
	}
}


void CALLBACK OnGUIEvent( UINT nEvent, int nControlID, CDXUTControl* pControl, void* pUserContext )
{

    switch( nControlID )
    {
        case IDC_FLOORHARDNESS_VALUE:
			g_floorHardness = (float)(((CDXUTSlider*)pControl)->GetValue());
			if (g_defTest) {
				g_defTest->SetFloorHardness(g_floorHardness);
			}
			UpdateTexts();
            break;
        case IDC_GRAVITY_VALUE:
			g_gravity = (float)(((CDXUTSlider*)pControl)->GetValue()*0.1f);
			if (g_defTest) {
				g_defTest->SetGravity(g_gravity);
			}
			UpdateTexts();
            break;
        case IDC_AIRDRAG_VALUE:
			g_airDrag = (float)(((CDXUTSlider*)pControl)->GetValue()*0.001f);
			if (g_defTest) {
				g_defTest->SetAirDrag(g_airDrag);
			}
			UpdateTexts();
            break;
        case IDC_SPRINGK_VALUE:
			g_springK = (float)((CDXUTSlider*)pControl)->GetValue();
			if (g_defTest) {
				g_defTest->SetSpringK(g_springK);
			}
			UpdateTexts();
            break;
        case IDC_CUBEMAPUPDATEFREQ_VALUE:
			g_cubeMapUpdateFreq = ((CDXUTSlider*)pControl)->GetValue();
			if (g_defTest) {
				g_defTest->SetCubeMapUpdateFreq(g_cubeMapUpdateFreq);
			}
			UpdateTexts();
            break;
		case IDC_CURRENTOBJECT_COMBO: {
			DXUTComboBoxItem *pItem = ((CDXUTComboBox*)pControl)->GetSelectedItem();
			g_currentObjTypeSelected = (int)(pItem->pData);
			UpdateTexts();
			break;
			}
		case IDC_ALPHA_VALUE:
			g_defObjs[g_currentObjTypeSelected].alpha = (float)(((CDXUTSlider*)pControl)->GetValue()*0.01f);
			if (g_defTest) {
				g_defTest->SetObjectsAlpha(g_objsOfEachType[g_currentObjTypeSelected], g_defObjs[g_currentObjTypeSelected].alpha);
			}
			UpdateTexts();
            break;
		case IDC_BETA_VALUE:
			g_defObjs[g_currentObjTypeSelected].beta = (float)(((CDXUTSlider*)pControl)->GetValue()*0.01f);
			if (g_defTest) {
				g_defTest->SetObjectsBeta(g_objsOfEachType[g_currentObjTypeSelected], g_defObjs[g_currentObjTypeSelected].beta);
			}
			UpdateTexts();
            break;
		case IDC_HARDNESS_VALUE:
			g_defObjs[g_currentObjTypeSelected].hardness = (float)(((CDXUTSlider*)pControl)->GetValue());
			if (g_defTest) {
				g_defTest->SetObjectsHardness(g_objsOfEachType[g_currentObjTypeSelected], g_defObjs[g_currentObjTypeSelected].hardness);
			}
			UpdateTexts();
            break;
		case IDC_SWITCHDEMO_BUTTON:
			g_switchDemo = true;
			break;
		case IDC_RESETDEMO_BUTTON:
			g_resetDemo = true;
			break;

		case IDC_TOGGLEFULLSCREEN_BUTTON:
            PostMessageW(DXUTGetHWND(), WM_SYSKEYDOWN, VK_RETURN, (1 << 29));
            //DXUTToggleFullScreen();
			break;

		case IDC_CHANGEDEVICE_BUTTON:
			g_SettingsDlg.SetActive( !g_SettingsDlg.IsActive() ); 
			break;
	}
}