//----------------------------------------------------------------------------------
// File:   Landscape.cpp
// Author: Nuttapong Chentanez
// Email:  sdkfeedback@nvidia.com
//
// Deformable Physics is based on Meshless Deformations Based on Shape Matching by M. Mueller, B. Heidelberger, M. Teschner, M. Gross.
// Collision detection and response is done with cube map look up.
// All run-time computation is done on the GPU.
// 
// Copyright (c) 2007 NVIDIA Corporation. All rights reserved.
//
// TO  THE MAXIMUM  EXTENT PERMITTED  BY APPLICABLE  LAW, THIS SOFTWARE  IS PROVIDED
// *AS IS*  AND NVIDIA AND  ITS SUPPLIERS DISCLAIM  ALL WARRANTIES,  EITHER  EXPRESS
// OR IMPLIED, INCLUDING, BUT NOT LIMITED  TO, IMPLIED WARRANTIES OF MERCHANTABILITY
// AND FITNESS FOR A PARTICULAR PURPOSE.  IN NO EVENT SHALL  NVIDIA OR ITS SUPPLIERS
// BE  LIABLE  FOR  ANY  SPECIAL,  INCIDENTAL,  INDIRECT,  OR  CONSEQUENTIAL DAMAGES
// WHATSOEVER (INCLUDING, WITHOUT LIMITATION,  DAMAGES FOR LOSS OF BUSINESS PROFITS,
// BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION, OR ANY OTHER PECUNIARY LOSS)
// ARISING OUT OF THE  USE OF OR INABILITY  TO USE THIS SOFTWARE, EVEN IF NVIDIA HAS
// BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
//

//--------------------------------------------------------------------------------------------------------------------------
//      READ THIS FIRST
// See the "READ THIS FIRST" section in the deformableObjects.h
//--------------------------------------------------------------------------------------------------------------------------

#include "DXUT.h"
#include "landscape.h"

CLandscapeEffect::CLandscapeEffect(ID3D10Device* pd3dDevice) : CEffect(L".\\fx\\deform.fx", pd3dDevice) {
	m_pTechnique = m_pEffect->GetTechniqueByName( "Render" );
	m_pWorldVariable = m_pEffect->GetVariableByName( "world" )->AsMatrix();
	m_pViewVariable = m_pEffect->GetVariableByName( "view" )->AsMatrix();
	m_pProjectionVariable = m_pEffect->GetVariableByName( "projection" )->AsMatrix();
	m_pHeightVariable = m_pEffect->GetVariableByName( "txHeight" )->AsShaderResource();

	m_pRedTex = m_pEffect->GetVariableByName( "redTex" )->AsShaderResource();
	m_pGreenTex = m_pEffect->GetVariableByName( "greenTex" )->AsShaderResource();
	m_pBlueTex = m_pEffect->GetVariableByName( "blueTex" )->AsShaderResource();
	m_pAlphaTex = m_pEffect->GetVariableByName( "alphaTex" )->AsShaderResource();
	m_pCoverageTex = m_pEffect->GetVariableByName( "coverageTex" )->AsShaderResource();
	
	m_puvScalingRed = m_pEffect->GetVariableByName( "uvScalingRed")->AsScalar();
	m_puvScalingGreen = m_pEffect->GetVariableByName( "uvScalingGreen")->AsScalar();
	m_puvScalingBlue = m_pEffect->GetVariableByName( "uvScalingBlue")->AsScalar();
	m_puvScalingAlpha = m_pEffect->GetVariableByName( "uvScalingAlpha")->AsScalar();

	m_puvJitterRed = m_pEffect->GetVariableByName("uvJitterRed")->AsVector();
	m_puvJitterGreen = m_pEffect->GetVariableByName("uvJitterGreen")->AsVector();
	m_puvJitterBlue = m_pEffect->GetVariableByName("uvJitterBlue")->AsVector();
	m_puvJitterAlpha = m_pEffect->GetVariableByName("uvJitterAlpha")->AsVector();
	// Define the input layout
	D3D10_INPUT_ELEMENT_DESC layout[] =
	{
		{ "POSITION", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, 0, D3D10_INPUT_PER_VERTEX_DATA, 0 },  
		{ "TEXCOORD", 0, DXGI_FORMAT_R32G32_FLOAT, 0, 12, D3D10_INPUT_PER_VERTEX_DATA, 0 },  
	};
	HRESULT hr;
	// Create the input layout
	D3D10_PASS_DESC PassDesc;
	m_pTechnique->GetPassByIndex( 0 )->GetDesc( &PassDesc );
	V( pd3dDevice->CreateInputLayout( layout, 2, PassDesc.pIAInputSignature, PassDesc.IAInputSignatureSize, &m_layout ) );
		
}
CLandscapeEffect::~CLandscapeEffect() {
	SAFE_RELEASE(m_layout);
}

void CLandscape::CreatePatch(float heightScaleX, float heightScaleZ,UINT w, UINT h, UINT& numVertices, ObsVertex*& pos, UINT& numIndices, DWORD*& indices) {
	numVertices = w*h;
	numIndices = (w-1)*(h-1)*6;
	pos = new ObsVertex[numVertices];
	indices = new DWORD[numIndices];
	float cenX = heightScaleX * 0.5f;
	float cenZ = heightScaleZ * 0.5f;
	float scaleU = 1.0f / w;
	float scaleV = 1.0f / h;
	float gridSizeX = heightScaleX / (w-1);
	float gridSizeZ = heightScaleZ / (h-1);
	for (UINT i = 0; i < h; i++) {
		for (UINT j = 0; j < w; j++) {
			pos[i*w+j].pos = D3DXVECTOR3(j*gridSizeX-cenX, 0, i*gridSizeZ-cenZ);
			pos[i*w+j].uv = D3DXVECTOR2((j+0.5f)*scaleU, (i+0.5f)*scaleV);
		}
	}
	DWORD* ind = indices;
	for (UINT i = 0; i < h-1; i++) {
		for (UINT j = 0; j < w-1; j++) {
			*(ind++) = i*w+j;
			*(ind++) = (i+1)*w+j+1;
			*(ind++) = i*w+j+1;

			*(ind++) = i*w+j;
			*(ind++) = (i+1)*w+j;
			*(ind++) = (i+1)*w+j+1;
		}
	}

}

void CLandscape::SetProjectionMat(const D3DXMATRIX* projection) {
	// Does not change very often
	m_landscapeEffect->m_pProjectionVariable->SetMatrix((float*)projection);
}

void CLandscape::Render(ID3D10Device* pd3dDevice, const D3DXMATRIX* world, const D3DXMATRIX* view) {
	m_landscapeEffect->m_pWorldVariable->SetMatrix((float*)world);
	m_landscapeEffect->m_pViewVariable->SetMatrix((float*)view);

	pd3dDevice->IASetPrimitiveTopology( D3D10_PRIMITIVE_TOPOLOGY_TRIANGLELIST );

	pd3dDevice->IASetVertexBuffers(0, 1, &m_posBuf->m_pVertexBuffer, &m_posBuf->m_stride, &m_posBuf->m_offset);
	pd3dDevice->IASetIndexBuffer(m_iBuf->m_pIndexBuffer, DXGI_FORMAT_R32_UINT, 0);
	pd3dDevice->IASetInputLayout( m_landscapeEffect->m_layout);

	// Draw landscape	
	m_landscapeEffect->m_pTechnique->GetPassByIndex( 0 )->Apply(0);
	pd3dDevice->DrawIndexed(m_iBuf->m_numIndices, 0, 0); 
}

CLandscape::~CLandscape() {
	SAFE_DELETE(m_posBuf);
	SAFE_DELETE(m_iBuf);
	SAFE_DELETE(m_landscapeEffect);
	SAFE_DELETE(m_redTex);
	SAFE_DELETE(m_greenTex);
	SAFE_DELETE(m_blueTex);
	SAFE_DELETE(m_alphaTex);
	SAFE_DELETE(m_coverageTex);
}

CLandscape::CLandscape(ID3D10Device* pd3dDevice, float heightScaleX, float heightScaleZ, CTexture2D* heightMap) {
	m_landscapeEffect = new CLandscapeEffect(pd3dDevice);
	ObsVertex* pos;
	DWORD* indices;

	UINT numVertices;
	UINT numIndices;

	CreatePatch(heightScaleX,heightScaleZ, heightMap->m_width, heightMap->m_height, numVertices, pos, numIndices, indices);
	m_landscapeEffect->m_pHeightVariable->SetResource(heightMap->m_pTextureRV);
	float jitterRed[2] = {0.11f, 0.37f}, 
		  jitterGreen[2] = {0.0f, 0.0f}, 
		  jitterBlue[2] = {0.51f, -0.23f}, 
		  jitterAlpha[2] = {0.73f, 0.07f};
	
	float scalingRed = heightMap->m_width*0.73f,
		  scalingGreen = heightMap->m_width*0.61f, 
		  scalingBlue = heightMap->m_width*0.97f, 
		  scalingAlpha = heightMap->m_width*1.11f;

	m_landscapeEffect->m_puvJitterRed->SetFloatVector(jitterRed);
	m_landscapeEffect->m_puvJitterGreen->SetFloatVector(jitterGreen);
	m_landscapeEffect->m_puvJitterBlue->SetFloatVector(jitterBlue);
	m_landscapeEffect->m_puvJitterAlpha->SetFloatVector(jitterAlpha);

	m_landscapeEffect->m_puvScalingRed->SetFloat(scalingRed);
	m_landscapeEffect->m_puvScalingGreen->SetFloat(scalingGreen);
	m_landscapeEffect->m_puvScalingBlue->SetFloat(scalingBlue);
	m_landscapeEffect->m_puvScalingAlpha->SetFloat(scalingAlpha);


	m_posBuf = new CVertexBuffer<ObsVertex>(pos, numVertices, pd3dDevice);
	m_iBuf = new CIndexBuffer<DWORD>(indices, numIndices, pd3dDevice);
	delete [] pos;
	delete [] indices;

	
	// Load the Texture
	HRESULT hr;
	V(DXUTSetMediaSearchPath(L"..\\Media"));
	WCHAR filename[MAX_PATH];
    V( DXUTFindDXSDKMediaFileCch( filename, MAX_PATH, L"sand.dds" ) );
	m_redTex = new CTexture2D(filename, pd3dDevice);
    V( DXUTFindDXSDKMediaFileCch( filename, MAX_PATH, L"grass.dds" ) );
	m_greenTex = new CTexture2D(filename, pd3dDevice);
    V( DXUTFindDXSDKMediaFileCch( filename, MAX_PATH, L"dirt.dds" ) );
	m_blueTex = new CTexture2D(filename, pd3dDevice);
    V( DXUTFindDXSDKMediaFileCch( filename, MAX_PATH, L"stone.dds" ) );
	m_alphaTex = new CTexture2D(filename, pd3dDevice);
    V( DXUTFindDXSDKMediaFileCch( filename, MAX_PATH, L"coverage.dds" ) );
	m_coverageTex = new CTexture2D(filename, pd3dDevice);


	// Update Variables that never change
	m_landscapeEffect->m_pRedTex->SetResource( m_redTex->m_pTextureRV );
	m_landscapeEffect->m_pGreenTex->SetResource( m_greenTex->m_pTextureRV );
	m_landscapeEffect->m_pBlueTex->SetResource( m_blueTex->m_pTextureRV );
	m_landscapeEffect->m_pAlphaTex->SetResource( m_alphaTex->m_pTextureRV );
	m_landscapeEffect->m_pCoverageTex->SetResource( m_coverageTex->m_pTextureRV );
}

