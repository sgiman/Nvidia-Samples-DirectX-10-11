//----------------------------------------------------------------------------------
// File:   DeformableObjects.cpp
// Author: Nuttapong Chentanez
// Email:  sdkfeedback@nvidia.com
//
// Deformable Physics is based on Meshless Deformations Based on Shape Matching by M. Mueller, B. Heidelberger, M. Teschner, M. Gross.
// Collision detection and response is done with cube map look up.
// All run-time computation is done on the GPU.
// 
// Copyright (c) 2007 NVIDIA Corporation. All rights reserved.
//
// TO  THE MAXIMUM  EXTENT PERMITTED  BY APPLICABLE  LAW, THIS SOFTWARE  IS PROVIDED
// *AS IS*  AND NVIDIA AND  ITS SUPPLIERS DISCLAIM  ALL WARRANTIES,  EITHER  EXPRESS
// OR IMPLIED, INCLUDING, BUT NOT LIMITED  TO, IMPLIED WARRANTIES OF MERCHANTABILITY
// AND FITNESS FOR A PARTICULAR PURPOSE.  IN NO EVENT SHALL  NVIDIA OR ITS SUPPLIERS
// BE  LIABLE  FOR  ANY  SPECIAL,  INCIDENTAL,  INDIRECT,  OR  CONSEQUENTIAL DAMAGES
// WHATSOEVER (INCLUDING, WITHOUT LIMITATION,  DAMAGES FOR LOSS OF BUSINESS PROFITS,
// BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION, OR ANY OTHER PECUNIARY LOSS)
// ARISING OUT OF THE  USE OF OR INABILITY  TO USE THIS SOFTWARE, EVEN IF NVIDIA HAS
// BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
//
//-----------------------------------------------------------------------------------
//      READ THIS FIRST
// See the "READ THIS FIRST" section in the deformableObjects.h
//-----------------------------------------------------------------------------------
//-----------------------------------------------------------------------------------
// Modified by Sergey Gasanov (sgiman) @ 2013, september
// Sgiman Creative Studio (sgiman.com)
//------------------------------------------------------------------------------------

#include "DXUT.h"
#include "DeformableObjects.h"
#include <iostream>
#include <vector>
#include <fstream>
#include <algorithm>
#include "KDTree.h"
#include "ObjFile.h"
using namespace std;


const float CONSTRAINED_NODES_SIGNIFICANT_FACTOR = 10.0f;  // Specify how much more important we should put on the constrianed nodes

 
enum DEBUG_ENUM{DEBUG_NONE, DEBUG_XVAL, DEBUG_CM, DEBUG_MINSMAXS, DEBUG_APQBAR, DEBUG_TRANSFORM, DEBUG_AQQBAR};
DEBUG_ENUM debugMode = DEBUG_NONE;

static HRESULT hr;
CDeformableBodyEffect::CDeformableBodyEffect(ID3D10Device* pd3dDevice, D3D10_SHADER_MACRO* macro) : CEffect(L".\\fx\\deformableBody.fx", pd3dDevice, macro) {
	// Obtain the handles to the techniques
	m_pDebugTechnique = m_pEffect->GetTechniqueByName( "Debug" );
	m_pPointRenderTechnique = m_pEffect->GetTechniqueByName( "PointRender" );
	m_pComputeCollisionForceTechnique = m_pEffect->GetTechniqueByName( "ComputeCollisionForce" );
	m_pComputePValTechnique = m_pEffect->GetTechniqueByName( "ComputePVal" );
	m_pComputePickedVerticesTechnique = m_pEffect->GetTechniqueByName( "ComputePickedVertices" );
	m_pComputePickingForceTechnique = m_pEffect->GetTechniqueByName( "ComputePickingForce" );
	m_pComputeCubeMapsTechnique = m_pEffect->GetTechniqueByName( "ComputeCubeMaps" );
	m_pComputeXTildaAndAccTechnique = m_pEffect->GetTechniqueByName( "ComputeXTildaAndAcc" );
	m_pMeshRenderTechnique = m_pEffect->GetTechniqueByName( "MeshRender" );
	m_pPickedPointsRenderTechnique = m_pEffect->GetTechniqueByName( "PickedPointsRender" );
	m_pComputePotentialCollisionPairsTechnique = m_pEffect->GetTechniqueByName( "ComputePotentialCollisionPairs" );
	m_pComputeXValTechnique = m_pEffect->GetTechniqueByName( "ComputeXVal" );
	m_pComputeCMTechnique = m_pEffect->GetTechniqueByName( "ComputeCM" );
	m_pComputeMinsNMaxsTechnique = m_pEffect->GetTechniqueByName( "ComputeMinsNMaxs" );
	m_pComputeApqBarTechnique = m_pEffect->GetTechniqueByName( "ComputeApqBar" );
	m_pComputeTransformTechnique = m_pEffect->GetTechniqueByName( "ComputeTransform" );
	m_pComputeClusterGoalPositionTechnique = m_pEffect->GetTechniqueByName( "ComputeClusterGoalPosition" );
	m_pComputeGoalPosTechnique = m_pEffect->GetTechniqueByName( "ComputeGoalPos" );
	m_pComputeForceTechnique = m_pEffect->GetTechniqueByName( "ComputeForce" );
	m_pUpdateVelAndPosTechnique = m_pEffect->GetTechniqueByName( "UpdateVelAndPos" );
	m_pComputeRealPosTechnique = m_pEffect->GetTechniqueByName( "ComputeRealPos" );
	m_pComputeNormalTechnique = m_pEffect->GetTechniqueByName( "ComputeNormal" );
	m_pUpdateAlphaTechnique = m_pEffect->GetTechniqueByName( "UpdateAlpha" );

	m_pcubeMapViewProj = m_pEffect->GetVariableByName( "cubeMapViewProj" )->AsMatrix();

	// Obtain the handles to the variables and shader resource
	m_pWorldVariable = m_pEffect->GetVariableByName( "world" )->AsMatrix();
	m_pViewVariable = m_pEffect->GetVariableByName( "view" )->AsMatrix();
	m_pProjectionVariable = m_pEffect->GetVariableByName( "projection" )->AsMatrix();
	m_pgAdrTex = m_pEffect->GetVariableByName( "gAdrTex" )->AsShaderResource();
	m_pposAdrTex = m_pEffect->GetVariableByName( "posAdrTex" )->AsShaderResource();
	m_pposWeightTex = m_pEffect->GetVariableByName( "posWeightTex" )->AsShaderResource();
	m_pgValTex = m_pEffect->GetVariableByName( "gValTex" )->AsShaderResource();
	m_pgTex = m_pEffect->GetVariableByName( "gTex" )->AsShaderResource();
	m_pforceTex = m_pEffect->GetVariableByName( "forceTex" )->AsShaderResource();
	m_pforceValTex = m_pEffect->GetVariableByName( "forceValTex" )->AsShaderResource();
	m_prenderTargetIDBuffer = m_pEffect->GetVariableByName( "renderTargetIDBuffer" )->AsShaderResource();
	m_pidToxValTexMappingBuffer = m_pEffect->GetVariableByName( "idToxValTexMappingBuffer" )->AsShaderResource();
	m_pxAdrTex = m_pEffect->GetVariableByName( "xAdrTex" )->AsShaderResource();
	m_pxTex = m_pEffect->GetVariableByName( "xTex" )->AsShaderResource();
	m_pobjIDTex = m_pEffect->GetVariableByName( "objIDTex" )->AsShaderResource();
	m_pxTildaTex = m_pEffect->GetVariableByName( "xTildaTex" )->AsShaderResource();
	m_paTildaTex = m_pEffect->GetVariableByName( "aTildaTex" )->AsShaderResource();
	m_pxTexW = m_pEffect->GetVariableByName( "xTexW" )->AsScalar();
	m_pxAdrTexW = m_pEffect->GetVariableByName( "xAdrTexW" )->AsScalar();
	m_pposTexW = m_pEffect->GetVariableByName( "posTexW" )->AsScalar();
	m_pvTex = m_pEffect->GetVariableByName( "vTex" )->AsShaderResource();
	m_pposTex = m_pEffect->GetVariableByName( "posTex" )->AsShaderResource();
	m_pnormalTex = m_pEffect->GetVariableByName( "normalTex" )->AsShaderResource();
	m_pxValTex = m_pEffect->GetVariableByName( "xValTex" )->AsShaderResource();
	m_ppValTex = m_pEffect->GetVariableByName( "pValTex" )->AsShaderResource();
	m_pqBarTex = m_pEffect->GetVariableByName( "qBarTex" )->AsShaderResource();
	m_pcmTex = m_pEffect->GetVariableByName( "cmTex" )->AsShaderResource();
	m_pminsTex = m_pEffect->GetVariableByName( "minsTex" )->AsShaderResource();
	m_pnmaxsTex = m_pEffect->GetVariableByName( "nmaxsTex" )->AsShaderResource();
	m_ptwoInv7S = m_pEffect->GetVariableByName( "twoInv7S" )->AsScalar();
	m_pinv3xAdrW = m_pEffect->GetVariableByName( "inv3xAdrW" )->AsScalar();
	m_pthreeXAdrW= m_pEffect->GetVariableByName( "threeXAdrW" )->AsScalar();
	m_pinvH = m_pEffect->GetVariableByName( "invH" )->AsScalar();
	m_pairDrag = m_pEffect->GetVariableByName( "airDrag")->AsScalar();
	m_pclustersHardness = m_pEffect->GetVariableByName( "clustersHardness" )->AsScalar();
	m_pfloorHardness = m_pEffect->GetVariableByName( "floorHardness" )->AsScalar();

	m_ph = m_pEffect->GetVariableByName( "h" )->AsScalar();
	m_pcmTexW = m_pEffect->GetVariableByName( "cmTexW" )->AsScalar();
	m_pclustersToObjects = m_pEffect->GetVariableByName( "clustersToObjects")->AsScalar();

	m_pcomputeNormalScaleU = m_pEffect->GetVariableByName( "computeNormalScaleU" )->AsScalar();
	m_pcomputeNormalScaleV = m_pEffect->GetVariableByName( "computeNormalScaleV" )->AsScalar();
	m_pstartVertex = m_pEffect->GetVariableByName( "startVertex" )->AsScalar();

	m_pheightMapTex = m_pEffect->GetVariableByName( "heightMapTex" )->AsShaderResource();
	m_pAqqBarTex = m_pEffect->GetVariableByName( "AqqBarTex" )->AsShaderResource();
	m_pApqBarTex = m_pEffect->GetVariableByName( "ApqBarTex" )->AsShaderResource();
	m_ptransformTex = m_pEffect->GetVariableByName( "transformTex" )->AsShaderResource();	

	m_pbetas= m_pEffect->GetVariableByName( "betas" )->AsScalar();
	m_palphas= m_pEffect->GetVariableByName( "alphas" )->AsScalar();
	m_pworldView = m_pEffect->GetVariableByName( "worldView" )->AsMatrix();
    m_pworldViewProj = m_pEffect->GetVariableByName( "worldViewProj" )->AsMatrix();
    m_pworldViewIT = m_pEffect->GetVariableByName( "worldViewIT" )->AsMatrix();
    m_plightPos = m_pEffect->GetVariableByName( "lightPos" )->AsVector();
    m_pclustersQuads = m_pEffect->GetVariableByName( "clustersQuads" )->AsVector();
	m_pcubeTexOffset = m_pEffect->GetVariableByName( "cubeTexOffset" )->AsVector();
	m_pinvHeightScale = m_pEffect->GetVariableByName( "invHeightScale" )->AsVector();
	m_pdiffuseTex = m_pEffect->GetVariableByName( "diffuseTex" )->AsShaderResource();	
	m_pcubeMapAtlasTex = m_pEffect->GetVariableByName("cubeMapAtlasTex")->AsShaderResource();
	m_pcube2DTex = m_pEffect->GetVariableByName("cube2DTex")->AsShaderResource();

	m_puvBuffer = m_pEffect->GetVariableByName("uvBuffer")->AsShaderResource();
	m_puvIndexBuffer = m_pEffect->GetVariableByName("uvIndexBuffer")->AsShaderResource();

	m_pspringK = m_pEffect->GetVariableByName("springK")->AsScalar();
	m_pgravity = m_pEffect->GetVariableByName("gravity")->AsScalar();
	m_twoInvXTexW = m_pEffect->GetVariableByName("twoInvXTexW")->AsScalar();
	m_twoInvXTexH = m_pEffect->GetVariableByName("twoInvXTexH")->AsScalar();
	m_minsPickNC = m_pEffect->GetVariableByName( "minsPickNC" )->AsVector();
	m_maxsPickNC = m_pEffect->GetVariableByName( "maxsPickNC" )->AsVector();
	m_mouseRay = m_pEffect->GetVariableByName( "mouseRay" )->AsVector();
	m_cameraPos = m_pEffect->GetVariableByName( "cameraPos" )->AsVector();

	m_shift_xTexW = m_pEffect->GetVariableByName( "shift_xTexW" )->AsScalar();
	m_shift_xAdrTexW = m_pEffect->GetVariableByName( "shift_xAdrTexW" )->AsScalar();
	m_shift_posTexW = m_pEffect->GetVariableByName( "shift_posTexW" )->AsScalar();
	m_shift_cmTexW = m_pEffect->GetVariableByName( "shift_cmTexW" )->AsScalar();

	m_and_xTexW = m_pEffect->GetVariableByName( "and_xTexW" )->AsScalar();
	m_and_xAdrTexW = m_pEffect->GetVariableByName( "and_xAdrTexW" )->AsScalar();
	m_and_posTexW = m_pEffect->GetVariableByName( "and_posTexW" )->AsScalar();
	m_and_cmTexW = m_pEffect->GetVariableByName( "and_cmTexW" )->AsScalar();

	// Create input layouts
	D3D10_PASS_DESC PassDesc;
	
	// For mesh rendering
    D3D10_INPUT_ELEMENT_DESC meshRenderLayoutDesc[] =
    {
        { "TEXCOORD", 0, DXGI_FORMAT_R32G32_FLOAT, 0, 0, D3D10_INPUT_PER_VERTEX_DATA, 0 },  
    };
	
	m_pMeshRenderTechnique->GetPassByIndex( 0 )->GetDesc( &PassDesc );
    V( pd3dDevice->CreateInputLayout( meshRenderLayoutDesc, 1, PassDesc.pIAInputSignature, PassDesc.IAInputSignatureSize, &m_meshRenderLayout ) );
	// For computing xval
    D3D10_INPUT_ELEMENT_DESC computeXValLayoutDesc[] =
    {
        { "POSITION", 0, DXGI_FORMAT_R32G32B32A32_FLOAT, 0, 0, D3D10_INPUT_PER_VERTEX_DATA, 0 },  
        { "TEXCOORD", 0, DXGI_FORMAT_R32G32B32A32_FLOAT, 0, 16, D3D10_INPUT_PER_VERTEX_DATA, 0 },  
    };
	
    m_pComputeXValTechnique->GetPassByIndex( 0 )->GetDesc( &PassDesc );
    V( pd3dDevice->CreateInputLayout( computeXValLayoutDesc, 2, PassDesc.pIAInputSignature, PassDesc.IAInputSignatureSize, &m_gpgpuLayout ) );

	// For Computing Collision Force
    D3D10_INPUT_ELEMENT_DESC passComputeCollisionForceLayoutDesc[] =
    {
        { "TEXCOORD", 0, DXGI_FORMAT_R32G32_UINT, 0, 0, D3D10_INPUT_PER_VERTEX_DATA, 0 },  
    };
	
	m_pComputeCollisionForceTechnique->GetPassByIndex( 0 )->GetDesc( &PassDesc );
    V( pd3dDevice->CreateInputLayout( passComputeCollisionForceLayoutDesc, 1, PassDesc.pIAInputSignature, PassDesc.IAInputSignatureSize, &m_computeCollisionForceLayout ) );
}
CDeformableBodyEffect::~CDeformableBodyEffect() {

	// Free memory
	SAFE_RELEASE(m_meshRenderLayout);
	SAFE_RELEASE(m_gpgpuLayout);
	SAFE_RELEASE(m_computeCollisionForceLayout);
}
void CDeformableObjects::RenderPoint(ID3D10Device* pd3dDevice) {

	// Set vertex buffer to NULL, because we obtain position from a vertex texture fetch
	ID3D10Buffer* buffers[1];
	UINT tmp = 0;
	buffers[0] = NULL;
	pd3dDevice->IASetVertexBuffers( 0, 1, buffers, &tmp, &tmp );
	pd3dDevice->IASetInputLayout(0);

	// Render points
    pd3dDevice->IASetPrimitiveTopology( D3D10_PRIMITIVE_TOPOLOGY_POINTLIST );

	// Set the shader resources
	m_deformableBodyEffect->m_pposTex->SetResource( m_posTex->m_pTextureRV );
	m_deformableBodyEffect->m_pnormalTex->SetResource( m_normalTex->m_pTextureRV );
	m_deformableBodyEffect->m_pPointRenderTechnique->GetPassByIndex( 0 )->Apply(0);

	// Draw the points
	pd3dDevice->Draw(m_totalNumRealVertices, 0);

}
void CDeformableObjects::RenderMesh(ID3D10Device* pd3dDevice) {
	// Set vertex buffer to NULL, because we obtain position from a vertex texture fetch
	ID3D10Buffer* buffers[1];
	UINT tmp = 0;
	buffers[0] = NULL;
	pd3dDevice->IASetVertexBuffers( 0, 1, buffers, &tmp, &tmp );
	pd3dDevice->IASetInputLayout(0);

	// Set topology to triangles triangles
    pd3dDevice->IASetPrimitiveTopology( D3D10_PRIMITIVE_TOPOLOGY_TRIANGLELIST );

	// Set the position texture
	m_deformableBodyEffect->m_pposTex->SetResource( m_posTex->m_pTextureRV );

	// Set the normal texture
	m_deformableBodyEffect->m_pnormalTex->SetResource( m_normalTex->m_pTextureRV );
	
	int startVertex = 0;

	// Loop through each of the object and render one by one
	for (size_t i = 0; i < m_defObjects.size(); i++) {
		// Set the uv buffer to be the uv of this object
		m_deformableBodyEffect->m_puvBuffer->SetResource(m_defObjects[i].m_uvBuffer->m_pResourceView);

		// Set the uv index buffer to be of this object
		m_deformableBodyEffect->m_puvIndexBuffer->SetResource(m_defObjects[i].m_uvIndexBuffer->m_pResourceView);
		
		if (m_defObjects[i].m_pTextureRV) {

			// Bind the diffuse texture, if one is used
			m_deformableBodyEffect->m_pdiffuseTex->SetResource(m_defObjects[i].m_pTextureRV);
		} else {

			// Otherwise, bind the white texture
			m_deformableBodyEffect->m_pdiffuseTex->SetResource(m_white->m_pTextureRV);
		}

		// Set the starting index of the vertex to use
		m_deformableBodyEffect->m_pstartVertex->SetInt(startVertex);

		// Set the index buffer to be that of this object
		pd3dDevice->IASetIndexBuffer(m_defObjects[i].m_objIB->m_pIndexBuffer, DXGI_FORMAT_R32_UINT, 0);

		// Draw triangle lists
		m_deformableBodyEffect->m_pMeshRenderTechnique->GetPassByIndex( 0 )->Apply(0);
		pd3dDevice->DrawIndexed(m_defObjects[i].m_objIB->m_numIndices, 0, 0);

		// Alter the startVertex
		startVertex += m_numRealVertices[i];
	}

}
void CDeformableObjects::DebugRender(ID3D10Device* pd3dDevice) {
	// Set vertex buffer to NULL, because we obtain position from a vertex texture fetch
	ID3D10Buffer* buffers[1];
	UINT tmp = 0;
	buffers[0] = NULL;
	pd3dDevice->IASetVertexBuffers( 0, 1, buffers, &tmp, &tmp );
	pd3dDevice->IASetInputLayout(0);

	m_deformableBodyEffect->m_pxTex->SetResource( m_xTex[m_forRead]->m_pTextureRV );
	m_deformableBodyEffect->m_paTildaTex->SetResource( m_aTildaTex->m_pTextureRV );

	// Render points
    pd3dDevice->IASetPrimitiveTopology( D3D10_PRIMITIVE_TOPOLOGY_POINTLIST );

	m_deformableBodyEffect->m_pDebugTechnique->GetPassByIndex( 0 )->Apply(0);
	// Draw the points
	pd3dDevice->Draw(m_totalNumRealVertices, 0);


}


void CDeformableObjects::Render(ID3D10Device* pd3dDevice, const D3DXMATRIX* world, const D3DXMATRIX* view, const D3DXMATRIX* projection) {
	if (!doneLoading) return;

	// Set the world, view, projection matrices
	m_deformableBodyEffect->m_pWorldVariable->SetMatrix((float*)world);
	m_deformableBodyEffect->m_pViewVariable->SetMatrix((float*)view);

	// Compute other derived matrices
	static D3DXMATRIX worldView;
	static D3DXMATRIX worldViewProj;
	static D3DXMATRIX worldViewIT;
	D3DXMatrixMultiply(&worldView, world, view);
	D3DXMatrixMultiply(&worldViewProj, &worldView, projection);
	D3DXMatrixInverse(&worldViewIT, NULL, &worldView);
	D3DXMatrixTranspose(&worldViewIT, &worldViewIT);
	 
	// Set the matrices
	m_deformableBodyEffect->m_pworldView->SetMatrix((float*)worldView);
	m_deformableBodyEffect->m_pworldViewIT->SetMatrix((float*)worldViewIT);
	m_deformableBodyEffect->m_pworldViewProj->SetMatrix((float*)worldViewProj);

	// Set the light source position
	D3DXVECTOR3 lightPos(2.0f, 20.0f, -20.0f);
	m_deformableBodyEffect->m_plightPos->SetFloatVector((float*)&lightPos);

	// Render the meshesde
	RenderMesh(pd3dDevice);
	PickedPointsRender(pd3dDevice);
//	DebugRender(pd3dDevice);
	

}
void CDeformableObjects::LoadTetMesh(LPCWSTR name, vector<D3DXVECTOR3>& positions, vector<DWORD>& tets, vector<DWORD>& tris) {
	
	// Load the tetrahedral mesh from a file
	HRESULT hr;
	V(DXUTSetMediaSearchPath(L".\\Media"));
	WCHAR fullName[MAX_PATH];
	V( DXUTFindDXSDKMediaFileCch( fullName, MAX_PATH, name ) );

	ifstream inf(fullName);
	if (!inf) {
		MessageBox( NULL, L"Tet Mesh not found", L"Error", MB_OK );
	}
	// Read off vertices
	int m_numVertices, numTets, numTris;
	inf>>m_numVertices;
	for (int i = 0; i < m_numVertices; i++) {
		float x, y, z;
		inf>>x>>y>>z;
		positions.push_back(D3DXVECTOR3(x, y, z));
	}

	// Read off tetrahedrons
	inf>>numTets;
	DWORD junk, i0,i1,i2,i3;
	for (int i = 0; i < numTets; i++) {
		inf>>junk>>i0>>i1>>i2>>i3;
		tets.push_back(i0-1);
		tets.push_back(i1-1);
		tets.push_back(i2-1);
		tets.push_back(i3-1);
	}

	// Read off triangles
	inf>>numTris;
	for (int i = 0; i < numTris; i++) {
		inf>>junk>>i0>>i1>>i2;
		tris.push_back(i0-1);
		tris.push_back(i1-1);
		tris.push_back(i2-1);
		
	}
	inf.close();
}
void CDeformableObjects::LoadHeightMap(ID3D10Device* pd3dDevice,  LPCWSTR heightMapFile, D3DXVECTOR3 heightMapScale) {
	// Load up the height map for collision purpose
	// Specify the desired image info we want to load 
	D3DX10_IMAGE_LOAD_INFO loadInfo;
	D3DX10_IMAGE_INFO info;

	// Obtain the image from file 
	D3DX10GetImageInfoFromFile(heightMapFile, NULL, &info, &hr);

	// Specify the desired image info
	loadInfo.Width = 16;
	loadInfo.Height = 16;
	loadInfo.Depth = 1;
	loadInfo.FirstMipLevel = 0;
	loadInfo.MipLevels = 10;
	loadInfo.BindFlags = 0;
	loadInfo.Usage = D3D10_USAGE_STAGING;
	loadInfo.CpuAccessFlags = D3D10_CPU_ACCESS_READ | D3D10_CPU_ACCESS_WRITE;
	loadInfo.MiscFlags = 0;
	loadInfo.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
	loadInfo.Filter = D3DX10_FILTER_LINEAR;
	loadInfo.MipFilter = D3DX10_FILTER_LINEAR;
	loadInfo.pSrcInfo = &info;

	// Create a 2D texture from a file, with the desired format
	CTexture2D* tmpTex = new CTexture2D(heightMapFile, pd3dDevice, &loadInfo);

	// Now, compute normal

	// Map the texture for read
	D3D10_MAPPED_TEXTURE2D mapDat;
	tmpTex->m_pTexture->Map(0, D3D10_MAP_READ , 0, &mapDat);

	// Obtain a pointer
	unsigned char* ptr = (unsigned char*)mapDat.pData; 

	// Obtain dimension
	int w = tmpTex->m_width, h = tmpTex->m_height;
	float inv = (heightMapScale.y / 255.0f);

	// Compute scaling along u and v directions
	float du = heightMapScale.x / tmpTex->m_width;
	float dv = heightMapScale.z / tmpTex->m_height;

	// Allocate memory for normals and initialize to 0
	D3DXVECTOR3* normals = new D3DXVECTOR3[tmpTex->m_width*tmpTex->m_height];
	memset(normals, 0, sizeof(float)*3*tmpTex->m_width*tmpTex->m_height);
	
	// Looping through all the triangles 
	for (int i = 0; i < h-1; i++) {
		for (int j = 0; j < w-1; j++) {

			// Fetch the heights of vertices
			//       hc .--. hd
			//          |\ |
			//		    | \|
			//          .--. hr
			float hc = ptr[i*mapDat.RowPitch + j*4+3]* inv;
			float hr = ptr[(i+1)*mapDat.RowPitch + (j+1)*4+3]* inv;
			float hd = ptr[(i)*mapDat.RowPitch + (j+1)*4+3]* inv;

			// Compute normal
			D3DXVECTOR3 tu = D3DXVECTOR3(du, hr-hc, dv);
			D3DXVECTOR3 tv = D3DXVECTOR3(du, hd-hc, 0);
			D3DXVECTOR3 normal;
			D3DXVec3Cross(&normal, &tu, &tv);

			// Add the normal to the 3 vertices
			normals[i*w+j] += normal;
			normals[(i+1)*w+j+1] += normal;
			normals[i*w+j+1] += normal;

			// Fetch the heights of vertices
			//       hc .--. 
			//          |\ |
			//		    | \|
			//       hr .--. hd
			hc = ptr[i*mapDat.RowPitch + j*4+3]* inv;
			hr = ptr[(i+1)*mapDat.RowPitch + (j)*4+3]* inv;
			hd = ptr[(i+1)*mapDat.RowPitch + (j+1)*4+3]* inv;
			
			// Compute normal
			tu = D3DXVECTOR3(0, hr-hc, dv);
			tv = D3DXVECTOR3(du, hd-hc, dv);			
			D3DXVec3Cross(&normal, &tu, &tv);
			
			// Add the normal to the 3 vertices
			normals[i*w+j] += normal;
			normals[(i+1)*w+j] += normal;
			normals[(i+1)*w+j+1] += normal;
		}
	}

	// Start creating a texture containin normal x, y, z in the r, g, b channels and the height in the a channel
	D3DXVECTOR4* data = new D3DXVECTOR4[tmpTex->m_width*tmpTex->m_height];

	// Allocate memory for storing height for internal use
	heightData = new float[tmpTex->m_width*tmpTex->m_height];
	for (int i = 0; i < h; i++) {
		for (int j = 0; j < w; j++) {
			// Normalize the normal vector
			D3DXVec3Normalize(&normals[i*w+j], &normals[i*w+j]);

			// Store the normal and height information to the texture 
			data[i*w+j] = D3DXVECTOR4(normals[i*w+j], ptr[i*mapDat.RowPitch + j*4+3]* inv);
			//data[i*w+j] = D3DXVECTOR4(0.0f, 1.0f, 0.0f, 0.0f);

			// Store the height for internal use
			heightData[i*w+j] = ptr[i*mapDat.RowPitch + j*4+3]*inv;
			//heightData[i*w+j] = 0.0f;
		}
	}
	
	// Unmap the buffer
	tmpTex->m_pTexture->Unmap(0);
	SAFE_DELETE(tmpTex);

	// Create the texture for used as a shader resource
	m_heightNormalMapTex = new CTexture2D(pd3dDevice, w, h, (float*)data); 
	
	delete [] data;
	delete [] normals;

	// Store the scale as well
	this->m_heightMapScale = heightMapScale;	
}

void CDeformableObjects::SetObjectsAlpha(vector<int>& objs, float newAlpha) {
	for (DWORD i = 0; i < objs.size(); i++) {
		int oID = objs[i];		
		m_allAlphas[oID] = newAlpha;		
	}
	m_updateAlphas = true;
}
void CDeformableObjects::SetObjectsBeta(vector<int>& objs, float newBeta) {
	for (DWORD i = 0; i < objs.size(); i++) {
		int oID = objs[i];
		for (DWORD j = 0; j < m_objsToClusters[oID].size(); j++) {
			m_allBetas[m_objsToClusters[oID][j]] = newBeta;
		}
	}
	m_updateBetas = true;
}
void CDeformableObjects::SetObjectsHardness(vector<int>& objs, float newHardness) {
	for (DWORD i = 0; i < objs.size(); i++) {
		int oID = objs[i];
		for (DWORD j = 0; j < m_objsToClusters[oID].size(); j++) {
			m_clustersHardness[m_objsToClusters[oID][j]] = newHardness;
		}
	}
	m_updateHardnesss = true;
}

void CDeformableObjects::FindControlTet(D3DXVECTOR3* vertices, DWORD m_numRealVertices, WORD base, vector<D3DXVECTOR3>& positions, vector<DWORD>& tets, vector<CRealVertex>& m_realVertices) {
	// Figure out the control tets for all vertices of the render surface mesh

	// Build KD-Tree
	CKDTree* kdTree = new CKDTree(vertices, m_numRealVertices);

	// Initialize temporary Real Vertex stucture
	CRealVertex tmpR;

	// Make the index point to an invalid entry
	tmpR.m_controlIndex[0] = 2000000000;

	// Create a vector storing the initial value for each of the real vertices
	DWORD stIndex = (DWORD)m_realVertices.size();
	for (DWORD i = 0; i < m_numRealVertices; i++) {
		m_realVertices.push_back(tmpR);
	}

	// Compute number tets
	DWORD numTets = (DWORD)tets.size() / 4;

	// Temporary vectors for storing the id of the real vertices that lie inside a tet 
	vector<DWORD> ids;

	// Temporary vectors for storing the weight of the real vertices that lie inside a tet 
	vector<D3DXVECTOR4> weights;

	// For each of the control mesh' tetrahedrons, find out what vertices of the render mesh are in the tet
	for (DWORD i = 0; i < numTets; i++) {

		// Clear the vectors
		ids.clear();
		weights.clear();

		// Find what points lie in this tetrahedron
		kdTree->PointsInTet(positions[tets[i*4]], positions[tets[i*4+1]], positions[tets[i*4+2]], positions[tets[i*4+3]], ids, weights);

		// Looping through all these points
		for (DWORD j = 0; j < weights.size(); j++) {
			// Set the 4 control points of the real vertex to the 4 points of this tetrahedron
			m_realVertices[stIndex+ids[j]].m_controlIndex[0] = tets[i*4]+base;
			m_realVertices[stIndex+ids[j]].m_controlIndex[1] = tets[i*4+1]+base;
			m_realVertices[stIndex+ids[j]].m_controlIndex[2] = tets[i*4+2]+base;
			m_realVertices[stIndex+ids[j]].m_controlIndex[3] = tets[i*4+3]+base;

			// Set the weight as well
			m_realVertices[stIndex+ids[j]].m_controlWeight[0] = weights[j].x;
			m_realVertices[stIndex+ids[j]].m_controlWeight[1] = weights[j].y;
			m_realVertices[stIndex+ids[j]].m_controlWeight[2] = weights[j].z;
			m_realVertices[stIndex+ids[j]].m_controlWeight[3] = weights[j].w;
		}
	}

	// Delete the KD tree
	delete kdTree;

	// Check if there is any vertex without control points 
	for (DWORD i = 0; i < m_numRealVertices; i++) {
		if (m_realVertices[stIndex+i].m_controlIndex[0] == 2000000000) {
			// Some vertices is not covered by control tets
			MessageBox( NULL, L"The tet Mesh does not enclose the surface mesh!!", L"Error", MB_OK );
		}
	}

}
CDeformableObjects::CDeformableObjects(UINT numObjects, LPCWSTR* fileNames, LPCWSTR* meshNames, D3DXMATRIX* initTransform, bool* isRelativeToGround, DWORD* K, float* alphas, float *betas, float* hardness, D3DXVECTOR3* constrainedMins, D3DXVECTOR3* constrainedMaxs, float floorHardness, ID3D10Device* pd3dDevice, LPCWSTR heightMapFile, D3DXVECTOR3 heightMapScale, float airDrag, float springK, float gravity, int cubeMapUpdateFreq) {
	m_cubeMapUpdateFreq = (DWORD) cubeMapUpdateFreq;
	m_updateAlphas = false;
	m_updateBetas = false;
	m_updateHardnesss = false;
	m_numObjects = numObjects;
	m_debugTex = NULL;
	m_debugTex2 = NULL;

	doneLoading = false;
	// Initialize constants
	m_CubePerRow = 1;		// Number of cubes per a row in a slice of a texture array
	m_Resolution = 16;	// m_Resolution of the cube face

    V(DXUTSetMediaSearchPath(L".\\Media"));
	WCHAR fullName[MAX_PATH];
    V( DXUTFindDXSDKMediaFileCch( fullName, MAX_PATH, heightMapFile ) );

	// Load the height map
	LoadHeightMap(pd3dDevice, fullName, heightMapScale);
	
	// Pointer to object file loader class
	CObjFile* pMesh;

	// Load the white color texture
    V( DXUTFindDXSDKMediaFileCch( fullName, MAX_PATH, L"white2.dds" ) );
	m_white = new CTexture2D( fullName, pd3dDevice);

	// Initialize the total number of control vertices to 0
	m_totalNumControls = 0;

	// Initialize the total number of real vertices to 0
	m_totalNumRealVertices = 0;

	int clusterCounter = 0;
	// Load each of the models
	for (DWORD o = 0; o < numObjects; o++) {
		
		CDeformableObject def;		
		vector<int> tmpVV;
		m_objsToClusters.push_back(tmpVV);
		for (DWORD c = 0; c < K[o]; c++) {
			m_objsToClusters[o].push_back(clusterCounter);
			clusterCounter++;
		}

		// Load an object
		pMesh = new CObjFile(fileNames[o], pd3dDevice);
		if (pMesh->m_pTexture) {
			
			// Add reference to the texture so it's released appropriately
			def.m_pTexture = pMesh->m_pTexture;
			def.m_pTextureRV = pMesh->m_pTextureRV;
			def.m_pTexture->AddRef();
			def.m_pTextureRV->AddRef();
		} else {

			// Set to NULL
			def.m_pTexture = NULL;
			def.m_pTextureRV = NULL;
		}
		
		// Number of vertices of the loaded surface mesh
		int currentNumV = (int)(pMesh->m_position.size());

		// Number of indices of the triangles of the loaded surface mesh
		int currentNumI = (int)(pMesh->m_positionIndices.size());

		// Store the number of vertices and the indices of the surface mesh to a vector
		m_numRealVertices.push_back(currentNumV);
		m_numIndices.push_back(currentNumI);
		
		// Obtain vertex and index data
		D3DXVECTOR3* vd = &pMesh->m_position[0];
		DWORD* id = &pMesh->m_positionIndices[0];

		// Obtain the index to the beginning of control vertices vector for this mesh
		int beginIndex = (int)(m_tmpControlPos.size());				

		// See if there is any control mesh provided
		if (meshNames[o]) {			
			// There is, use it

			// Load the tetrahedral mesh
			vector<D3DXVECTOR3> positions;
			vector<DWORD> tets;
			vector<DWORD> tris;
			LoadTetMesh(meshNames[o], positions, tets, tris);
			
			// Compute the 4 vertices of the control mesh that influence each surface mesh' vertices 
			FindControlTet(vd, currentNumV, (WORD)beginIndex, positions, tets, m_realVertices);

			// Compute where the origin is, when the transformation is applied
			D3DXVECTOR3 origin(0.0f, 0.0f, 0.0f), originT;
			D3DXVec3TransformCoord(&originT, &origin, &initTransform[o]);

			// See if it's relative to ground, if so, set the offset to the height of the grund
			float yOffset = 0.0f;
			if (isRelativeToGround[o]) yOffset = GetHeight(originT.x, originT.z);
			
			// Assume mass = 1 for all nodes, not quite true, but ok
			for (size_t i = 0; i < positions.size(); i++) {

				// Transform the vertex
				D3DXVECTOR3 tempV;
				D3DXVec3TransformCoord(&tempV, &positions[i], &initTransform[o]);

				bool constrained = false;
				// See if we should contrain this vertex or not
				if (constrainedMins && constrainedMaxs) {
					if ( (positions[i].x >= constrainedMins[o].x) && 
						 (positions[i].y >= constrainedMins[o].y) && 
						 (positions[i].z >= constrainedMins[o].z) && 
						 (positions[i].x <= constrainedMaxs[o].x) && 
						 (positions[i].y <= constrainedMaxs[o].y) && 
						 (positions[i].z <= constrainedMaxs[o].z) ) {
						// In the bounding box, push to the constrained listt
						m_constrainedVertices.push_back((int)(m_tmpControlPos.size()));				    
						constrained = true;
					}
				} 
				// Add the yOffset to the y coordinate of the vertex
				tempV.y += yOffset;

				// Add the control vertex to the list
				m_tmpControlPos.push_back( tempV);

				if (constrained) {
					// Add the mass to the list, if constrained, we need to put more weight
					m_tmpMasses.push_back(CONSTRAINED_NODES_SIGNIFICANT_FACTOR);
				} else {
					// Add the mass to the list
					m_tmpMasses.push_back(1.0f);
				}
			}


			// Append the cluster --> object list
			// Also, append the hardness
			for (DWORD c = 0; c < K[o]; c++) {
				m_clustersToObjects.push_back(o);
				m_clustersHardness.push_back(hardness[o]);
			}

			// Do K Mean to assign vertices to clusters
			FindClustersTets(&positions[0], (DWORD)positions.size(), K[o], tets, beginIndex, tris, m_clusters, m_clustersFaces);

			// Increment the number of control points
			m_totalNumControls += (int)(positions.size());

		} else{
			// If not, just use itself, only 1 cluster is supported for now.

			// Create control points for the mesh, which is in this case, itself
			int CC = 1;

			// Find out where the origin is transformed to 
			D3DXVECTOR3 origin(0.0f, 0.0f, 0.0f), originT;
			D3DXVec3TransformCoord(&originT, &origin, &initTransform[o]);

			// See if it's relative to ground, if so, set the offset to the height of the grund
			float yOffset = 0.0f;
			if (isRelativeToGround[o]) yOffset = GetHeight(originT.x, originT.z);
			for (int i = 0; i < currentNumV; i++) {

				bool constrained = false;
				// Transform the vertex
				D3DXVECTOR3 tempV;
				D3DXVec3TransformCoord(&tempV, &vd[i], &initTransform[o]);
				if (constrainedMins && constrainedMaxs) {
					if ( (vd[i].x >= constrainedMins[o].x) && 
						 (vd[i].y >= constrainedMins[o].y) && 
						 (vd[i].z >= constrainedMins[o].z) && 
						 (vd[i].x <= constrainedMaxs[o].x) && 
						 (vd[i].y <= constrainedMaxs[o].y) && 
						 (vd[i].z <= constrainedMaxs[o].z) ) {
						// In the bounding box, add to constrained list
						m_constrainedVertices.push_back((int)(m_tmpControlPos.size()));				    
						constrained = true;
					}
				}
				tempV.y += yOffset;

				m_tmpControlPos.push_back( tempV);

				if (constrained) {
					// Add the mass to the list, if constrained, we need to put more weight
					m_tmpMasses.push_back(CONSTRAINED_NODES_SIGNIFICANT_FACTOR);
				} else {
					// Add the mass to the list
					m_tmpMasses.push_back(1.0f);
				}
			}
		
			// Write out the list of points that belong to the cluster
			for (int c = 0; c < CC; c++) {
				m_clustersToObjects.push_back(o);
				m_clustersHardness.push_back(hardness[o]);
				vector<int> tmp;
				m_clusters.push_back(tmp);
				vector<int>& v = m_clusters.back();
				for (int i = 0; i < currentNumV; i++) {
					v.push_back(beginIndex+i);
				}
			}
			// Write out the list of faces that belong to this cluster
			// Each face consist of 3 vertices indices
			// All vertices refered in the cluster face must belong to the cluster
			// The index is with respect to the cluster vertices only,
			// ie. A cluster face consists of the 0th, 7th, 10th cluster vertices 
			// should be stored as (0,7,10) triple, regardless of what global vertices the 0th, 7thm 10th cluster vertices
			// refer to.
			
			for (int c = 0; c < CC; c++) {
				vector<int> tmp;
				m_clustersFaces.push_back(tmp);
				vector<int>& f = m_clustersFaces.back();
				for (int i = 0; i < currentNumI; i++) {
					f.push_back(id[i]);
				}
			}

			// Create the real vertices structures
			CRealVertex cav;
			for (int i = 0; i < currentNumV; i++) {				
				
				// The real vertices in this case use itself as the 4 control points, each with weight 0.25
				for (int j = 0; j < 4; j++) {
					cav.m_controlIndex[j] = i+beginIndex;
					cav.m_controlWeight[j] = 0.25f;
				}
				m_realVertices.push_back(cav);
			}
			m_totalNumControls += currentNumV;
		}
		m_totalNumRealVertices += currentNumV;
		

		// Create index buffer for this object
		def.m_objIB = new CIndexBuffer<DWORD>(id, currentNumI, pd3dDevice);		

		// Create vertex buffer which just contains texture coordinates
		def.m_uvBuffer = new CVertexBuffer<D3DXVECTOR2>(&pMesh->m_texCoord[0], (UINT)pMesh->m_texCoord.size(), pd3dDevice, D3D10_BIND_SHADER_RESOURCE);
		
		// Create index buffer for the u, v
		def.m_uvIndexBuffer = new CIndexBuffer<DWORD>(&pMesh->m_texCoordIndices[0], (UINT)pMesh->m_texCoordIndices.size(), pd3dDevice, D3D10_BIND_SHADER_RESOURCE);

		// Append the object to the list
		m_defObjects.push_back(def);

		delete pMesh;
	}

	// From control point, precompute necessary informations
	PreComputation(pd3dDevice, alphas, betas, hardness, floorHardness);

	// Create cube map atlas
	GenCubeMapAtlas(pd3dDevice);

	// Set the air drag
	m_deformableBodyEffect->m_pairDrag->SetFloat(airDrag);

	// Set the spring constant
	m_deformableBodyEffect->m_pspringK->SetFloat(springK);
	
	// Set gravity
	m_deformableBodyEffect->m_pgravity->SetFloat(gravity);


	doneLoading = true;
}

void CreateTmpArray(D3DXVECTOR3* in, float* imass, UINT numI, UINT w, UINT h, float*& out) {
	// Create an array filled with x, y, z amd mass obtained from array of D3DXVEC3 and a float
	out = new float[4*w*h];
	float* o = out;
	memset(out, 0, sizeof(float)*4*w*h);
	for (UINT i = 0; i < numI; i++) {
		*(o++) = in->x;
		*(o++) = in->y;
		*(o++) = in->z;
		*(o++) = *(imass++);
		in++;		
	}
}

void CDeformableObjects::SetFloorHardness(float hardness) {
	m_deformableBodyEffect->m_pfloorHardness->SetFloat(hardness);
}
void CDeformableObjects::SetGravity(float gravity) {
	m_deformableBodyEffect->m_pgravity->SetFloat(gravity);
}
void CDeformableObjects::SetAirDrag(float drag) {
	m_deformableBodyEffect->m_pairDrag->SetFloat(drag);
}
void CDeformableObjects::SetSpringK(float springK) {
	m_deformableBodyEffect->m_pspringK->SetFloat(springK);
}

void CDeformableObjects::ComputeCollisionForce(ID3D10Device* pd3dDevice) {
	// Pass for computing the collision force		
	ID3D10Buffer* buffers[1];
	UINT strides[1];
	UINT offsets[1];

	// Set the vertex buffer to be the buffer containing potential colliding pairs
	buffers[0] = m_collidingPairsBuffer;
	strides[0] = 8;
	offsets[0] = 0;
    pd3dDevice->IASetVertexBuffers( 0, 1, buffers, strides, offsets );

	// Render these pairs as point
	pd3dDevice->IASetPrimitiveTopology( D3D10_PRIMITIVE_TOPOLOGY_POINTLIST );

	// Set the layout appropriately
	pd3dDevice->IASetInputLayout(m_deformableBodyEffect->m_computeCollisionForceLayout);

	// Set viewport
	pd3dDevice->RSSetViewports( 1, &m_computeCollisionForceVP);

	// Set rendering target
	pd3dDevice->OMSetRenderTargets(1, &m_forceValTex->m_pRTV, NULL);

	// Clear cm to 0
	static float ClearColor[4] = { 0.0f, 0.0f, 0.0f, 0.0f }; // red, green, blue, alpha
    pd3dDevice->ClearRenderTargetView( m_forceValTex->m_pRTV, ClearColor );
	
	// Setup the resources
	m_deformableBodyEffect->m_pcube2DTex->SetResource(m_cube2DTex->m_pTextureRV);
	m_deformableBodyEffect->m_pcmTex->SetResource( m_cmTex->m_pTextureRV );
	m_deformableBodyEffect->m_pxValTex->SetResource( m_xValTex->m_pTextureRV );
	m_deformableBodyEffect->m_pcubeMapAtlasTex->SetResource(m_cubeMapAtlasTex->m_pTextureRV);
	m_deformableBodyEffect->m_pComputeCollisionForceTechnique->GetPassByIndex( 0 )->Apply(0);

	pd3dDevice->DrawAuto();

	// Restore vertex buffer
	buffers[0] = m_gpgpuVB->m_pVertexBuffer;
	strides[0] = m_gpgpuVB->m_stride;
	offsets[0] = m_gpgpuVB->m_offset;
    pd3dDevice->IASetVertexBuffers( 0, 1, buffers, strides, offsets );
	
	// Set vertex buffer input layout
	pd3dDevice->IASetInputLayout( m_deformableBodyEffect->m_gpgpuLayout);

}
void CDeformableObjects::ComputePotentialCollidingPairs(ID3D10Device* pd3dDevice) {
	// Pass for computing the collision force		
	ID3D10Buffer* buffers[1];
	UINT strides[1];
	UINT offsets[1];

	// Set the vertex buffer to be the buffer containing potential colliding pairs
	buffers[0] = m_potentialCollidingPairsVB->m_pVertexBuffer;
	strides[0] = 8;
	offsets[0] = 0;
    pd3dDevice->IASetVertexBuffers( 0, 1, buffers, strides, offsets );

	// Render these pairs as point
	pd3dDevice->IASetPrimitiveTopology( D3D10_PRIMITIVE_TOPOLOGY_POINTLIST );

	// Set the layout appropriately
	pd3dDevice->IASetInputLayout(m_deformableBodyEffect->m_computeCollisionForceLayout);

	// Set stream output to output to a buffer
    pd3dDevice->SOSetTargets( 1, &m_collidingPairsBuffer, offsets );
	
	// Set the mins tex
	m_deformableBodyEffect->m_pminsTex->SetResource( m_minsTex->m_pTextureRV );

	// Set the maxs tex
	m_deformableBodyEffect->m_pnmaxsTex->SetResource( m_nmaxsTex->m_pTextureRV );

	// Do a computation
	m_deformableBodyEffect->m_pComputePotentialCollisionPairsTechnique->GetPassByIndex( 0 )->Apply(0);
	pd3dDevice->Draw(m_potentialCollidingPairsVB->m_numVertices, 0);

	// Set the render target buffer to NULL
	buffers[0] = NULL;
	// Set stream output back to normal
    pd3dDevice->SOSetTargets( 1, buffers, offsets );

	// Restore vertex buffer input layout
	pd3dDevice->IASetInputLayout( m_deformableBodyEffect->m_gpgpuLayout);	

}
void CDeformableObjects::ComputeXVal(ID3D10Device* pd3dDevice, CTexture2D* xTexToUse) {
	// Set vertex buffer input layout
	pd3dDevice->IASetInputLayout( m_deformableBodyEffect->m_gpgpuLayout);

	// Set vertex buffer
	ID3D10Buffer* buffers[1];
	UINT strides[1];
	UINT offsets[1];
	buffers[0] = m_gpgpuVB->m_pVertexBuffer;
	strides[0] = m_gpgpuVB->m_stride;
	offsets[0] = m_gpgpuVB->m_offset;

    pd3dDevice->IASetVertexBuffers( 0, 1, buffers, strides, offsets );

	// Set primitive topology
    pd3dDevice->IASetPrimitiveTopology( D3D10_PRIMITIVE_TOPOLOGY_TRIANGLESTRIP );

	// Set viewport
	pd3dDevice->RSSetViewports( 1, &m_computeXValVP );

	m_deformableBodyEffect->m_pxValTex->SetResource( NULL );
	
	// Set rendering target
	pd3dDevice->OMSetRenderTargets(1, &m_xValTex->m_pRTV, NULL);

	// Setup Resource
	m_deformableBodyEffect->m_pxAdrTex->SetResource( m_xAdrTex->m_pTextureRV );
	m_deformableBodyEffect->m_pxTex->SetResource( xTexToUse->m_pTextureRV );

	// Do a computation
	m_deformableBodyEffect->m_pComputeXValTechnique->GetPassByIndex( 0 )->Apply(0);
	pd3dDevice->Draw(4, m_computeXValStart);

}
void CDeformableObjects::ComputePVal(ID3D10Device* pd3dDevice) {
	// Set vertex buffer input layout
	pd3dDevice->IASetInputLayout( m_deformableBodyEffect->m_gpgpuLayout);

	// Set vertex buffer
	ID3D10Buffer* buffers[1];
	UINT strides[1];
	UINT offsets[1];
	buffers[0] = m_gpgpuVB->m_pVertexBuffer;
	strides[0] = m_gpgpuVB->m_stride;
	offsets[0] = m_gpgpuVB->m_offset;
    pd3dDevice->IASetVertexBuffers( 0, 1, buffers, strides, offsets );

	// Set primitive topology
    pd3dDevice->IASetPrimitiveTopology( D3D10_PRIMITIVE_TOPOLOGY_TRIANGLELIST );

	// Set viewport
	pd3dDevice->RSSetViewports( 1, &m_computePValVP );

	m_deformableBodyEffect->m_ppValTex->SetResource( NULL );
	
	// Set rendering target
	pd3dDevice->OMSetRenderTargets(1, &m_pValTex->m_pRTV, NULL);

	// Setup Resource
	m_deformableBodyEffect->m_pxValTex->SetResource( m_xValTex->m_pTextureRV );
	m_deformableBodyEffect->m_pcmTex->SetResource( m_cmTex->m_pTextureRV );

	// Do a computation
	m_deformableBodyEffect->m_pComputePValTechnique->GetPassByIndex( 0 )->Apply(0);
	pd3dDevice->Draw(m_computePValNum, m_computePValStart);

}

void CDeformableObjects::ComputeCM(ID3D10Device* pd3dDevice) {
	// VB Layout stay the same as pass 1
	// VB the same as pass 1

	// Use point
    pd3dDevice->IASetPrimitiveTopology( D3D10_PRIMITIVE_TOPOLOGY_POINTLIST );

	// Set viewport
	pd3dDevice->RSSetViewports( 1, &m_computeCMVP );

	m_deformableBodyEffect->m_pcmTex->SetResource( NULL );
	
	// Set rendering target
	pd3dDevice->OMSetRenderTargets(1, &m_cmTex->m_pRTV, NULL);

	// Clear cm to 0
	static float ClearColor[4] = { 0.0f, 0.0f, 0.0f, 0.0f }; // red, green, blue, alpha
    pd3dDevice->ClearRenderTargetView( m_cmTex->m_pRTV, ClearColor );
	
	// Setup Resource
	m_deformableBodyEffect->m_pxValTex->SetResource( m_xValTex->m_pTextureRV );

	m_deformableBodyEffect->m_pComputeCMTechnique->GetPassByIndex( 0 )->Apply(0);
	pd3dDevice->Draw(m_computeCMNum, m_computeCMStart);

}

void CDeformableObjects::ComputeMinsNMaxs(ID3D10Device* pd3dDevice) {
	// Similar to compute CM, but use min blending instead of addition

	ID3D10RenderTargetView* rtvs[2] = {m_minsTex->m_pRTV, m_nmaxsTex->m_pRTV};
	// Set rendering target
	pd3dDevice->OMSetRenderTargets(2, rtvs, NULL);

	// Clear m_mins to high value
	static float ClearColor[4] = { 1e20f,  1e20f,  1e20f,  1e20f }; // red, green, blue, alpha
    pd3dDevice->ClearRenderTargetView( m_minsTex->m_pRTV, ClearColor );
    pd3dDevice->ClearRenderTargetView( m_nmaxsTex->m_pRTV, ClearColor );
	
	m_deformableBodyEffect->m_pComputeMinsNMaxsTechnique->GetPassByIndex( 0 )->Apply(0);
	pd3dDevice->Draw(m_computeCMNum, m_computeCMStart);

}


void CDeformableObjects::ComputeApqBar(ID3D10Device* pd3dDevice) {
	// Compute the ApqBar

	// Use point
    pd3dDevice->IASetPrimitiveTopology( D3D10_PRIMITIVE_TOPOLOGY_POINTLIST );

	// Set viewport
	pd3dDevice->RSSetViewports( 1, &m_computeApqBarVP );

	// Set render target appropriately
	m_deformableBodyEffect->m_pApqBarTex->SetResource( NULL );
	pd3dDevice->OMSetRenderTargets(1, &m_ApqBarTex->m_pRTV, NULL);

	// Clear m_ApqBar
	static float ClearColor[4] = { 0.0f, 0.0f, 0.0f, 0.0f }; // red, green, blue, alpha

	// Set render target to ApqBar Texture
    pd3dDevice->ClearRenderTargetView( m_ApqBarTex->m_pRTV, ClearColor );
	
	// Setup Resource
	m_deformableBodyEffect->m_pqBarTex->SetResource( m_qBarTex->m_pTextureRV );
	m_deformableBodyEffect->m_pcmTex->SetResource( m_cmTex->m_pTextureRV );
	m_deformableBodyEffect->m_ppValTex->SetResource( m_pValTex->m_pTextureRV );

	m_deformableBodyEffect->m_pComputeApqBarTechnique->GetPassByIndex( 0 )->Apply(0);
	pd3dDevice->Draw(m_computeApqBarNum, m_computeApqBarStart);

}
void CDeformableObjects::ComputeTransform(ID3D10Device* pd3dDevice) {
	// VB Layout stay the same as pass 1
	// VB the same as pass 1

	// Use point
    pd3dDevice->IASetPrimitiveTopology( D3D10_PRIMITIVE_TOPOLOGY_POINTLIST );

	// Set viewport
	pd3dDevice->RSSetViewports( 1, &m_computeTransformVP );

	m_deformableBodyEffect->m_ptransformTex->SetResource( NULL );
	// Set rendering target
	pd3dDevice->OMSetRenderTargets(1, &m_transformTex->m_pRTV, NULL);
	
	// Clear m_transformTex
	static float ClearColor[4] = { 0.0f, 0.0f, 0.0f, 0.0f }; // red, green, blue, alpha
    pd3dDevice->ClearRenderTargetView( m_transformTex->m_pRTV, ClearColor );	

	// Setup Resource
	m_deformableBodyEffect->m_pApqBarTex->SetResource( m_ApqBarTex->m_pTextureRV );
	m_deformableBodyEffect->m_pAqqBarTex->SetResource( m_AqqBarTex->m_pTextureRV );

	m_deformableBodyEffect->m_pComputeTransformTechnique->GetPassByIndex( 0 )->Apply(0);
	pd3dDevice->Draw(m_computeTransformNum, m_computeTransformStart);

}
void CDeformableObjects::ComputeGVal(ID3D10Device* pd3dDevice) {
	// VB Layout stay the same as pass 1
	// VB the same as pass 1

	// Use point
    pd3dDevice->IASetPrimitiveTopology( D3D10_PRIMITIVE_TOPOLOGY_POINTLIST );

	// Set viewport
	pd3dDevice->RSSetViewports( 1, &m_computeClusterGoalPositionVP );
	m_deformableBodyEffect->m_pgValTex->SetResource( NULL );

	// Set rendering target
	pd3dDevice->OMSetRenderTargets(1, &m_gValTex->m_pRTV, NULL);

	// Setup Resources
	m_deformableBodyEffect->m_ptransformTex->SetResource( m_transformTex->m_pTextureRV );

	m_deformableBodyEffect->m_pComputeClusterGoalPositionTechnique->GetPassByIndex( 0 )->Apply(0);
	pd3dDevice->Draw(m_computeClusterGoalPositionNum, m_computeClusterGoalPositionStart);
}
void CDeformableObjects::SetCubeMapUpdateFreq(int freq) {
	m_cubeMapUpdateFreq = (DWORD)freq;
}
void CDeformableObjects::ComputeCubeMaps(ID3D10Device* pd3dDevice) {
	m_currentFrame++;
	if (m_currentFrame < m_cubeMapUpdateFreq) {
		return;
	}
	m_currentFrame = 0;
	// Set vertex buffer to none
	ID3D10Buffer* buffers[1];
	UINT tmp = 0;
	buffers[0] = NULL;
	pd3dDevice->IASetVertexBuffers( 0, 1, buffers, &tmp, &tmp );
    pd3dDevice->IASetPrimitiveTopology( D3D10_PRIMITIVE_TOPOLOGY_TRIANGLELIST );
	pd3dDevice->IASetInputLayout(0);

	// Set render targets to the cube maps texture array
	ID3D10RenderTargetView* rtvs[1] = {m_cube2DTex->m_pRTV};
	
	pd3dDevice->OMSetRenderTargets(1, rtvs, NULL);

	// Clear the render target to completely black
	float clearColor[4] = {0.0f, 0.0f, 0.0f, 0.0f};
	pd3dDevice->ClearRenderTargetView(m_cube2DTex->m_pRTV, clearColor);

	m_deformableBodyEffect->m_ppValTex->SetResource( m_pValTex->m_pTextureRV );

	// Need several batch of rendering for generating the cube map, because the number of elements in texture array is limited
	for (DWORD batch = 0; batch < m_numCubeMapRenderBatchs; batch++) {
	
		// Set the viewport so that the viewport depicts the correct portion of the texture to render to
		int offsetX = (batch % m_CubePerRow)*m_Resolution*6;
		int offsetY = (batch / m_CubePerRow)*m_Resolution;
		for (int v = 0; v < 6; v++) {
			m_cubeViewports[v].TopLeftX = offsetX + m_Resolution*v;
			m_cubeViewports[v].TopLeftY = offsetY;
		}
		pd3dDevice->RSSetViewports(6, m_cubeViewports);

		// Set the render target ID buffer
		m_deformableBodyEffect->m_prenderTargetIDBuffer->SetResource(m_clustersControlFacesRenderTargetIDBufferRV[batch]);
		m_deformableBodyEffect->m_pidToxValTexMappingBuffer->SetResource(m_idToxValTexMappingBufferRV[batch]);
		
		// Set the index buffer for this batch 
		pd3dDevice->IASetIndexBuffer(m_clustersControlFacesIndexBuffer[batch]->m_pIndexBuffer, DXGI_FORMAT_R32_UINT, 0);
		m_deformableBodyEffect->m_pComputeCubeMapsTechnique->GetPassByIndex( 0 )->Apply(0);
		pd3dDevice->DrawIndexed(m_clustersControlFacesIndexBuffer[batch]->m_numIndices, 0, 0);
	}
}

void CDeformableObjects::ComputeForce(ID3D10Device* pd3dDevice) {
	pd3dDevice->IASetPrimitiveTopology( D3D10_PRIMITIVE_TOPOLOGY_TRIANGLELIST );

	// Set viewport
	pd3dDevice->RSSetViewports( 1, &m_computeGoalPosVP );

	m_deformableBodyEffect->m_pgTex->SetResource( NULL );

	// Set rendering target
	ID3D10RenderTargetView* rtvs[1] = {m_forceTex->m_pRTV};

	pd3dDevice->OMSetRenderTargets(1, rtvs, NULL);
	
	static float ClearColor[4] = { 0.0f, 0.0f, 0.0f, 0.0f }; // red, green, blue, alpha
	pd3dDevice->ClearRenderTargetView( m_forceTex->m_pRTV, ClearColor );

	// Setup Resource
	m_deformableBodyEffect->m_pforceValTex->SetResource( m_forceValTex->m_pTextureRV );
	m_deformableBodyEffect->m_pgAdrTex->SetResource( m_gAdrTex->m_pTextureRV );

	m_deformableBodyEffect->m_pComputeForceTechnique->GetPassByIndex( 0 )->Apply(0);
	pd3dDevice->Draw(m_computeGoalPosNum, m_computeGoalPosStart);
}

void CDeformableObjects::ComputeGoalPos(ID3D10Device* pd3dDevice) {

    pd3dDevice->IASetPrimitiveTopology( D3D10_PRIMITIVE_TOPOLOGY_TRIANGLELIST );

	// Set viewport
	pd3dDevice->RSSetViewports( 1, &m_computeGoalPosVP );

	m_deformableBodyEffect->m_pgTex->SetResource( NULL );
	// Set rendering target
	ID3D10RenderTargetView* rtvs[1] = {m_gTex->m_pRTV};

	pd3dDevice->OMSetRenderTargets(1, rtvs, NULL);
	
	static float ClearColor[4] = { 0.0f, 0.0f, 0.0f, 0.0f }; // red, green, blue, alpha
    pd3dDevice->ClearRenderTargetView( m_gTex->m_pRTV, ClearColor );

	// Setup Resource
	m_deformableBodyEffect->m_pgValTex->SetResource( m_gValTex->m_pTextureRV );
	m_deformableBodyEffect->m_pgAdrTex->SetResource( m_gAdrTex->m_pTextureRV );

	m_deformableBodyEffect->m_pComputeGoalPosTechnique->GetPassByIndex( 0 )->Apply(0);
	pd3dDevice->Draw(m_computeGoalPosNum, m_computeGoalPosStart);
}
void CDeformableObjects::UpdateAlpha(ID3D10Device* pd3dDevice) {
	// Set vertex buffer input layout
	pd3dDevice->IASetInputLayout( m_deformableBodyEffect->m_gpgpuLayout);

	// Set vertex buffer
	ID3D10Buffer* buffers[1];
	UINT strides[1];
	UINT offsets[1];
	buffers[0] = m_gpgpuVB->m_pVertexBuffer;
	strides[0] = m_gpgpuVB->m_stride;
	offsets[0] = m_gpgpuVB->m_offset;

    pd3dDevice->IASetVertexBuffers( 0, 1, buffers, strides, offsets );

	// Use point
    pd3dDevice->IASetPrimitiveTopology( D3D10_PRIMITIVE_TOPOLOGY_TRIANGLESTRIP );

	// Set viewport
	pd3dDevice->RSSetViewports( 1, &m_updateVelAndPosVP );

	// Need to feed in previous values of alpha as well to know whether the control points should be constrained or not
	m_deformableBodyEffect->m_pvTex->SetResource( m_vTex[m_forWrite]->m_pTextureRV );

	ID3D10RenderTargetView* rtvs[1] = {m_vTex[m_forRead]->m_pRTV};
	// Set rendering target
	pd3dDevice->OMSetRenderTargets(1, rtvs, NULL);

	m_deformableBodyEffect->m_pUpdateAlphaTechnique->GetPassByIndex( 0 )->Apply(0);
	pd3dDevice->Draw(4, m_updateVelAndPosStart);
}
void CDeformableObjects::UpdateVelAndPos(ID3D10Device* pd3dDevice) {
	// VB Layout stay the same as pass 1
	// VB the same as pass 1
	
	// Use point
    pd3dDevice->IASetPrimitiveTopology( D3D10_PRIMITIVE_TOPOLOGY_TRIANGLESTRIP );

	// Set viewport
	pd3dDevice->RSSetViewports( 1, &m_updateVelAndPosVP );

	// Setup Resource
	m_deformableBodyEffect->m_pxTildaTex->SetResource( m_xTildaTex->m_pTextureRV );
	m_deformableBodyEffect->m_pgTex->SetResource( m_gTex->m_pTextureRV );
	m_deformableBodyEffect->m_paTildaTex->SetResource( m_aTildaTex->m_pTextureRV );
	m_deformableBodyEffect->m_pxTex->SetResource( m_xTex[m_forRead]->m_pTextureRV );
	m_deformableBodyEffect->m_pvTex->SetResource( m_vTex[m_forRead]->m_pTextureRV );

	ID3D10RenderTargetView* rtvs[2] = {m_xTex[m_forWrite]->m_pRTV, m_vTex[m_forWrite]->m_pRTV};
	// Set rendering target
	pd3dDevice->OMSetRenderTargets(2, rtvs, NULL);

	m_deformableBodyEffect->m_pUpdateVelAndPosTechnique->GetPassByIndex( 0 )->Apply(0);
	pd3dDevice->Draw(4, m_updateVelAndPosStart);
}
void CDeformableObjects::ComputeXTildaAndATilda(ID3D10Device* pd3dDevice) {
	// VB Layout stay the same as pass 1
	// VB the same as pass 1
	
	// Use point
    pd3dDevice->IASetPrimitiveTopology( D3D10_PRIMITIVE_TOPOLOGY_TRIANGLESTRIP );

	// Set viewport
	pd3dDevice->RSSetViewports( 1, &m_updateVelAndPosVP );

	// Setup Resource
	m_deformableBodyEffect->m_pforceTex->SetResource( m_forceTex->m_pTextureRV );
	m_deformableBodyEffect->m_pxTex->SetResource( m_xTex[m_forRead]->m_pTextureRV );
	m_deformableBodyEffect->m_pvTex->SetResource( m_vTex[m_forRead]->m_pTextureRV );
	m_deformableBodyEffect->m_pxTildaTex->SetResource(NULL);
	m_deformableBodyEffect->m_paTildaTex->SetResource(NULL);

	ID3D10RenderTargetView* rtvs[2] = {m_xTildaTex->m_pRTV, m_aTildaTex->m_pRTV};
	// Set rendering target
	pd3dDevice->OMSetRenderTargets(2, rtvs, NULL);

	m_deformableBodyEffect->m_pComputeXTildaAndAccTechnique->GetPassByIndex( 0 )->Apply(0);
	pd3dDevice->Draw(4, m_updateVelAndPosStart);
}

void CDeformableObjects::ComputeRealPosition(ID3D10Device* pd3dDevice) {
	// VB Layout stay the same as pass 1
	// VB the same as pass 1
	// Set vertex buffer input layout
	pd3dDevice->IASetInputLayout( m_deformableBodyEffect->m_gpgpuLayout);

	// Set vertex buffer
	ID3D10Buffer* buffers[1];
	UINT strides[1];
	UINT offsets[1];
	buffers[0] = m_gpgpuVB->m_pVertexBuffer;
	strides[0] = m_gpgpuVB->m_stride;
	offsets[0] = m_gpgpuVB->m_offset;
    pd3dDevice->IASetVertexBuffers( 0, 1, buffers, strides, offsets );
	
	// Use point
    pd3dDevice->IASetPrimitiveTopology( D3D10_PRIMITIVE_TOPOLOGY_TRIANGLESTRIP );

	ID3D10RenderTargetView* rtvs[1] = {m_posTex->m_pRTV};

	m_deformableBodyEffect->m_pposTex->SetResource( NULL );

	// Set rendering target
	pd3dDevice->OMSetRenderTargets(1, rtvs, NULL);

	// Set viewport
	pd3dDevice->RSSetViewports( 1, &m_computeRealPosVP );

	// Setup Resource
	m_deformableBodyEffect->m_pposWeightTex->SetResource( m_posWeightTex->m_pTextureRV );
	m_deformableBodyEffect->m_pposAdrTex->SetResource( m_posAdrTex->m_pTextureRV );
	m_deformableBodyEffect->m_pxTex->SetResource( m_xTex[m_forWrite]->m_pTextureRV );

	m_deformableBodyEffect->m_pComputeRealPosTechnique->GetPassByIndex( 0 )->Apply(0);
	pd3dDevice->Draw(4, m_computeRealPosStart);
}

void CDeformableObjects::ComputeNormal(ID3D10Device* pd3dDevice) {
	// Set vertex buffer to none
	ID3D10Buffer* buffers[1];
	UINT tmp = 0;
	buffers[0] = NULL;
	pd3dDevice->IASetVertexBuffers( 0, 1, buffers, &tmp, &tmp );
    pd3dDevice->IASetPrimitiveTopology( D3D10_PRIMITIVE_TOPOLOGY_TRIANGLELIST );
	pd3dDevice->IASetInputLayout(0);

	m_deformableBodyEffect->m_pnormalTex->SetResource( NULL );

	// Set rendering target
	ID3D10RenderTargetView* rtvs[1] = {m_normalTex->m_pRTV};
	pd3dDevice->OMSetRenderTargets(1, rtvs, NULL);

	// Set viewport
	pd3dDevice->RSSetViewports( 1, &m_computeNormalVP );

	static float ClearColor[4] = { 0.0f, 0.0f, 0.0f, 0.0f }; // red, green, blue, alpha
    pd3dDevice->ClearRenderTargetView( m_normalTex->m_pRTV, ClearColor );

	m_deformableBodyEffect->m_pposTex->SetResource( m_posTex->m_pTextureRV );
	
	int startVertex = 0;
	for (size_t i = 0; i < m_defObjects.size(); i++) {
		m_deformableBodyEffect->m_pstartVertex->SetInt(startVertex);
		pd3dDevice->IASetIndexBuffer(m_defObjects[i].m_objIB->m_pIndexBuffer, DXGI_FORMAT_R32_UINT, 0);

		m_deformableBodyEffect->m_pComputeNormalTechnique->GetPassByIndex( 0 )->Apply(0);
		pd3dDevice->DrawIndexed(m_defObjects[i].m_objIB->m_numIndices, 0, 0);
		startVertex += m_numRealVertices[i];
		
	}
}

// Inverse a 9x9 matrix
bool Inverse9x9(float Ainv[9][9])
{

    static int aiColIndex[9];
    static int aiRowIndex[9];
    static bool abPivoted[9];
	static float junk9[9];

	memset(abPivoted,0,9*sizeof(bool));
	//memcpy(Ainv, A, 81*sizeof(float));

    int i1, i2, iRow = 0, iCol = 0;
    float fSave;

    // elimination by full pivoting
    for (int i0 = 0; i0 < 9; i0++)
    {
        // search matrix (excluding pivoted rows) for maximum absolute entry
        float fMax = 0.0f;
        for (i1 = 0; i1 < 9; i1++)
        {
            if (!abPivoted[i1])
            {
                for (i2 = 0; i2 < 9; i2++)
                {
                    if (!abPivoted[i2])
                    {
                        float fAbs = fabs(Ainv[i1][i2]);
                        if (fAbs > fMax)
                        {
                            fMax = fAbs;
                            iRow = i1;
                            iCol = i2;
                        }
                    }
                }
            }
        }

        if (fMax == (float)0.0)
        {
            // matrix is not invertible
            return false;
        }

        abPivoted[iCol] = true;

        // swap rows so that A[iCol][iCol] contains the pivot entry
        if (iRow != iCol)
        {
			memcpy(junk9, &Ainv[iRow][0], 9*sizeof(float));
			memcpy(&Ainv[iRow][0], &Ainv[iCol][0], 9*sizeof(float));
			memcpy(&Ainv[iCol][0], junk9, 9*sizeof(float));
        }

        // keep track of the permutations of the rows
        aiRowIndex[i0] = iRow;
        aiColIndex[i0] = iCol;

        // scale the row so that the pivot entry is 1
        float fInv = ((float)1.0)/Ainv[iCol][iCol];
        Ainv[iCol][iCol] = (float)1.0;
        for (i2 = 0; i2 < 9; i2++)
        {
            Ainv[iCol][i2] *= fInv;
        }

        // zero out the pivot column locations in the other rows
        for (i1 = 0; i1 < 9; i1++)
        {
            if (i1 != iCol)
            {
                fSave = Ainv[i1][iCol];
                Ainv[i1][iCol] = (float)0.0;
                for (i2 = 0; i2 < 9; i2++)
                {
                    Ainv[i1][i2] -= Ainv[iCol][i2]*fSave;
                }
            }
        }
    }

    // reorder rows so that A[][] stores the inverse of the original matrix
    for (i1 = 8; i1 >= 0; i1--)
    {
        if (aiRowIndex[i1] != aiColIndex[i1])
        {
            for (i2 = 0; i2 < 9; i2++)
            {
                fSave = Ainv[i2][aiRowIndex[i1]];
                Ainv[i2][aiRowIndex[i1]] = Ainv[i2][aiColIndex[i1]];
                Ainv[i2][aiColIndex[i1]] = fSave;
            }
        }
    }

    return true;
}

void CDeformableObjects::FindClustersTets(D3DXVECTOR3* points, DWORD numPts, DWORD k, vector<DWORD>& tets, int baseVertex, vector<DWORD>& tris, vector<vector<int> >& m_clusters, vector<vector<int> >& clusterFaces) {
	// Figure out the k-partition, make each partition a cluster. Also include the one-ring neighbors of the vertices in the 
	// partition in the cluster as well, to provide link between cluster
	// Append what we found to the m_clusters's structure, baseVertex is the index we should add to all the vertex indices 
	// so as to refer this cluster.

	vector<D3DXVECTOR3> means;
	vector<DWORD> members;
	FindKMean(points, numPts, k, means, members);
	vector< vector<DWORD> > tmpClusters(k);

	vector< vector<bool> > isMember(k), oldIsMember(k);
	for (DWORD i = 0; i < k; i++) {
		for (DWORD j = 0; j < numPts; j++) {
			isMember[i].push_back(false);
			oldIsMember[i].push_back(false);
		}
	}
	for (DWORD i = 0; i < numPts; i++) {
		oldIsMember[members[i]].at(i) = true;
	}
	// Do add some neighbors of the existing members to the cluster 
	DWORD numTets = (DWORD)tets.size() / 4;
	const int neighborAdded = 2;
	for (int na = 0; na < neighborAdded; na++) {
		for (DWORD i = 0; i < numTets; i++) {
			DWORD i4 = i * 4;
			for (DWORD p1 = 0; p1 < 3; p1++) {
				for (DWORD p2 = p1+1; p2 < 4; p2++) {
					for (DWORD clus = 0; clus < k; clus++) {
					
						if (oldIsMember[clus][tets[i4+p1]] || oldIsMember[clus][tets[i4+p2]]) {
							isMember[clus][tets[i4+p2]] = true;
							isMember[clus][tets[i4+p1]] = true;
						}
					}
				}
			}
		}
		for (DWORD i = 0; i < k; i++) {
			for (DWORD j = 0; j < numPts; j++) {
				oldIsMember[i][j] = isMember[i][j];
			}
		}
	}
	for (DWORD clus = 0; clus < k; clus++) {
		for (DWORD i = 0; i < numPts; i++) {
			if (isMember[clus][i]) tmpClusters[clus].push_back(i);
		}
	}
	DWORD beginClus = (DWORD)m_clusters.size();
	// Sort and remove duplicate and store the cluster member
	for (DWORD i = 0; i < k; i++) {
		vector<DWORD>& tmpVec = tmpClusters[i];
		DWORD numEntries = (DWORD)tmpVec.size();
		sort(tmpVec.begin(), tmpVec.end());
		vector<int> tmp;
		m_clusters.push_back(tmp);
		vector<int>& vecNoDup = m_clusters.back();
		DWORD current = 0, old = 0;
		while (current < numEntries) {
			DWORD oldVal = tmpVec[old];
			while ( (current < numEntries) && (tmpVec[current] == oldVal)) {
				current++;
			}
			vecNoDup.push_back(oldVal + baseVertex);
			old = current;
		}
	}

	vector<DWORD> currentCluster(numPts);
	vector<DWORD> indexInCluster(numPts);
	DWORD numTris = (DWORD)tris.size() / 3;

	// Now, need to figure out m_clusters faces
	for (DWORD i = 0; i < k; i++) {
		vector<int>& vecNoDup = m_clusters[beginClus+i];
		for (DWORD j = 0; j < vecNoDup.size(); j++) {
			currentCluster[vecNoDup[j]-baseVertex] = i; // Specify that this vertex is currently associated with the cluster
			indexInCluster[vecNoDup[j]-baseVertex] = j; // Index with respect to the beginning of the cluster
		}
		vector<int> tmp;
		clusterFaces.push_back(tmp);
		vector<int>& vecFaces = clusterFaces.back();
		
		// Check if all the 3 vertices associated with triangles are in the current cluster
		for (DWORD j = 0; j < numTris; j++) {
			if ((currentCluster[tris[j*3]] == i) &&
				(currentCluster[tris[j*3+1]] == i) &&
				(currentCluster[tris[j*3+2]] == i)) {

				// If so, append it to the current face
				vecFaces.push_back(indexInCluster[tris[j*3]]);
				vecFaces.push_back(indexInCluster[tris[j*3+1]]);
				vecFaces.push_back(indexInCluster[tris[j*3+2]]);		
			}	
		}
	}

	
}
void CDeformableObjects::FindKMean(D3DXVECTOR3* points, DWORD numPts, DWORD k, vector<D3DXVECTOR3>& means, vector<DWORD>& members) {
	const int NUM_K_MEAN_ITERATIONS = 50;
	means.clear();
	members.clear();
	vector<DWORD> memberCount(numPts);

	// Assign all the vertices to the first cluster
	for (DWORD i = 0; i < numPts; i++) {
		members.push_back(0);
	}

	// Set the mean of each cluster to be at the position of the first k vertices (this is just arbitrary)
	for (DWORD i = 0; i < k; i++) {
		means.push_back(points[i]);
	}

	for (DWORD iteration = 0; iteration < NUM_K_MEAN_ITERATIONS; iteration++) {

		// For each of the point, find which cluster it's nearest to and then indicate that it belongs to that cluster
		for (DWORD i = 0; i < numPts; i++) {
			float minD = 1e10f, tmpD;
			DWORD id = 0;
			for (DWORD j = 0; j < k; j++) {
				D3DXVECTOR3 vec = points[i] - means[j];
				tmpD = D3DXVec3Dot(&vec, &vec);
				if (tmpD < minD) {
					minD = tmpD;
					id = j;
				}
			}
			members[i] = id;
		}
		
		// Initialize the mean for each of the clusters to D3DXVECTOR3(0.0f, 0.0f, 0.0f), also set the member count for each of the cluster to 0
		for (DWORD j = 0; j < k; j++) {
			means[j] = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
			memberCount[j] = 0;
		}

		// Compute the mean for each of the clusters
		for (DWORD i = 0; i < numPts; i++) {
			means[members[i]] += points[i];
			memberCount[members[i]]++;
		}
		for (DWORD j = 0; j < k; j++) {
			if (memberCount[j] != 0) {
				means[j] /= (float)memberCount[j];
			}
		}
	}
}

// Step the simulation in time for timeStep second
void CDeformableObjects::Compute(ID3D10Device* pd3dDevice, float timeStep, bool pull, bool pick, D3DXVECTOR2 mins, D3DXVECTOR2 maxs, D3DXVECTOR3 eyePos, D3DXVECTOR3 mouseRay) {
	static int frameNum = 0;
	frameNum++;
	if (!doneLoading) return;

	if (pull || pick) {
		// Set the eye pos and mouse ray, if either we are pulling or picking
		m_deformableBodyEffect->m_cameraPos->SetFloatVector((float*)eyePos);
		m_deformableBodyEffect->m_mouseRay->SetFloatVector((float*)mouseRay);
	}

	// Set invH
	m_deformableBodyEffect->m_pinvH->SetFloat(1.0f/timeStep);

	// Set h
	m_deformableBodyEffect->m_ph->SetFloat(timeStep);

	// See if we need to update any object specific quantities
	if (m_updateAlphas) {
		m_deformableBodyEffect->m_palphas->SetFloatArray(m_allAlphas, 0, m_numObjects);
		UpdateAlpha(pd3dDevice);
		m_updateAlphas = false;
	}
	if (m_updateBetas) {
		m_deformableBodyEffect->m_pbetas->SetFloatArray(m_allBetas, 0, m_totalNumClusters);
		m_updateBetas = false;
	}
	if (m_updateHardnesss) {
		m_deformableBodyEffect->m_pclustersHardness->SetFloatArray(&m_clustersHardness[0], 0, m_totalNumClusters);
		m_updateBetas = false;
	}

	// --------------------- Deal with control vertices ------------------------
	// Compute position of vertices in each cluster
	ComputeXVal(pd3dDevice, m_xTex[m_forRead]);
	// Compute center of mass for each cluster
	ComputeCM(pd3dDevice);	

	// *********** ---------------------------- ********
	if ((debugMode == DEBUG_CM) ) {
		pd3dDevice->Flush();
		pd3dDevice->CopyResource(m_debugTex->m_pTexture, m_cmTex->m_pTexture);
		pd3dDevice->Flush();
		D3D10_MAPPED_TEXTURE2D mapped;
		V(m_debugTex->m_pTexture->Map(0, D3D10_MAP_READ, 0, &mapped));
		float* vvv = (float*)mapped.pData;
		cout<<"Frame Num = "<<frameNum<<endl;
		for (int c = 0; c < m_totalNumClusters; c++) {
			int i = c / m_cmTex->m_width;
			int j = c % m_cmTex->m_width;
			cout<<vvv[i*mapped.RowPitch/4+j*4]/vvv[i*mapped.RowPitch/4+j*4+3]<<" "<<vvv[i*mapped.RowPitch/4+j*4+1]/vvv[i*mapped.RowPitch/4+j*4+3]<<" "<<vvv[i*mapped.RowPitch/4+j*4+2]/vvv[i*mapped.RowPitch/4+j*4+3]<<" "<<vvv[i*mapped.RowPitch/4+j*4+3]<<endl;
		}
		cout<<endl;
		m_debugTex->m_pTexture->Unmap(0);
	}

	if ((debugMode == DEBUG_MINSMAXS) ) {
		pd3dDevice->Flush();
		pd3dDevice->CopyResource(m_debugTex->m_pTexture, m_minsTex->m_pTexture);
		pd3dDevice->Flush();
		D3D10_MAPPED_TEXTURE2D mapped;
		V(m_debugTex->m_pTexture->Map(0, D3D10_MAP_READ, 0, &mapped));
		float* vvv = (float*)mapped.pData;
		cout<<"Frame Num = "<<frameNum<<endl;
		cout<<" mins are"<<endl;
		for (int c = 0; c < m_totalNumClusters; c++) {
			int i = c / m_cmTex->m_width;
			int j = c % m_cmTex->m_width;
			cout<<vvv[i*mapped.RowPitch/4+j*4]<<" "<<vvv[i*mapped.RowPitch/4+j*4+1]<<" "<<vvv[i*mapped.RowPitch/4+j*4+2]<<" "<<vvv[i*mapped.RowPitch/4+j*4+3]<<endl;
		}
		cout<<endl;
		m_debugTex->m_pTexture->Unmap(0);

		pd3dDevice->Flush();
		pd3dDevice->CopyResource(m_debugTex->m_pTexture, m_nmaxsTex->m_pTexture);
		pd3dDevice->Flush();
		V(m_debugTex->m_pTexture->Map(0, D3D10_MAP_READ, 0, &mapped));
		vvv = (float*)mapped.pData;
		cout<<" nmaxs are"<<endl;
		for (int c = 0; c < m_totalNumClusters; c++) {
			int i = c / m_cmTex->m_width;
			int j = c % m_cmTex->m_width;
			cout<<vvv[i*mapped.RowPitch/4+j*4]<<" "<<vvv[i*mapped.RowPitch/4+j*4+1]<<" "<<vvv[i*mapped.RowPitch/4+j*4+2]<<" "<<vvv[i*mapped.RowPitch/4+j*4+3]<<endl;
		}
		cout<<endl;
		m_debugTex->m_pTexture->Unmap(0);

		pd3dDevice->Flush();
		pd3dDevice->CopyResource(m_debugTex2->m_pTexture, m_xValTex->m_pTexture);
		pd3dDevice->Flush();
		V(m_debugTex2->m_pTexture->Map(0, D3D10_MAP_READ, 0, &mapped));
		vvv = (float*)mapped.pData;

		int curRow = 0;
		// For each of the cluster
		for (int i = 0; i < m_totalNumClusters; i++) {
			UINT numRows = (UINT)ceil(m_clusters[i].size() / ((float)m_xAdrTex->m_width));		
			D3DXVECTOR3 mins(1e20f,1e20f,1e20f);
			D3DXVECTOR3 maxs(-1e20f,-1e20f,-1e20f);
			
			for (DWORD j = 0; j < m_clusters[i].size() ; j++) {
				int row = i + j / m_xAdrTex->m_width;
				int col = j % m_xAdrTex->m_width;
				float* ptr = &vvv[row*mapped.RowPitch/4 + col*4];
				if (ptr[0] < mins.x) mins.x = ptr[0];
				if (ptr[1] < mins.y) mins.y = ptr[1];
				if (ptr[2] < mins.z) mins.z = ptr[2];
				if (ptr[0] > maxs.x) maxs.x = ptr[0];
				if (ptr[1] > maxs.y) maxs.y = ptr[1];
				if (ptr[2] > maxs.z) maxs.z = ptr[2];
			}
			curRow+=numRows;
			cout<<"For cluster "<<i<<endl;
			cout<<"True mins = "<<mins.x<<" "<<mins.y<<" "<<mins.z<<endl;
			cout<<"True maxs = "<<maxs.x<<" "<<maxs.y<<" "<<maxs.z<<endl;
		}
		

		m_debugTex2->m_pTexture->Unmap(0);

		

	}
	// *********** ---------------------------- ********

	// Compute lower bound and negated upper bound of the bounding box of each cluster
	ComputeMinsNMaxs(pd3dDevice);


	// Compute position with respect to the center of mass of the vertices in each cluster
	ComputePVal(pd3dDevice);

	// Create the cube maps 
	ComputeCubeMaps(pd3dDevice);

	// Compute the pairs of clusters that potentially collide
	ComputePotentialCollidingPairs(pd3dDevice);

	// Compute collision force acting on vertices in each cluster
	ComputeCollisionForce(pd3dDevice);

	// Sum the collision force to get total force acting on a vertex
	ComputeForce(pd3dDevice);

	// If the picked vertices are being pulled, apply spring force  by adding it to the total force
	if (pull && (!pick)) {
		ComputePickingForce(pd3dDevice);
	}

	// Compute the acceleration (taking into account gravity and collision with the floor) and the intermediate position
	ComputeXTildaAndATilda(pd3dDevice);

	// Compute the intermediate position of the vertices in each cluster
	ComputeXVal(pd3dDevice, m_xTildaTex);

	// Compute the center of masses of the intermediate position of the clusters
	ComputeCM(pd3dDevice);

	// Compute intermediate position with respect to the center of mass
	ComputePVal(pd3dDevice);

	// Compute ApqBar
	ComputeApqBar(pd3dDevice);

	// *********** ---------------------------- ********
	if (debugMode == DEBUG_APQBAR) {
		pd3dDevice->Flush();
		pd3dDevice->CopyResource(m_debugTex->m_pTexture, m_ApqBarTex->m_pTexture);
		pd3dDevice->Flush();
		D3D10_MAPPED_TEXTURE2D mapped;
		V(m_debugTex->m_pTexture->Map(0, D3D10_MAP_READ, D3D10_MAP_FLAG_DO_NOT_WAIT, &mapped));
		float* vvv = (float*)mapped.pData;
		for (int c = 0; c < m_totalNumClusters; c++) {
			int i = c / m_cmTex->m_width;
			int j = c % m_cmTex->m_width;
			float* ptr = &vvv[i*mapped.RowPitch/4 + j*28];
			cout<<ptr[0]<<" "<<ptr[1]<<" "<<ptr[2]<<" "<<ptr[3]<<" "<<ptr[4]<<" "<<ptr[5]<<" "<<ptr[6]<<" "<<ptr[7]<<" "<<ptr[24]<<endl;
			cout<<ptr[8]<<" "<<ptr[9]<<" "<<ptr[10]<<" "<<ptr[11]<<" "<<ptr[12]<<" "<<ptr[13]<<" "<<ptr[14]<<" "<<ptr[15]<<" "<<ptr[25]<<endl;
			cout<<ptr[16]<<" "<<ptr[17]<<" "<<ptr[18]<<" "<<ptr[19]<<" "<<ptr[20]<<" "<<ptr[21]<<" "<<ptr[22]<<" "<<ptr[23]<<" "<<ptr[26]<<endl;
			cout<<endl;
		}
		cout<<endl;
		m_debugTex->m_pTexture->Unmap(0);
	}
	// *********** ---------------------------- ********

	// Compute the transformation, by first computing optimum rotation and then blend with ApqBar
	ComputeTransform(pd3dDevice);
	
	// *********** ---------------------------- ********
	if (debugMode == DEBUG_TRANSFORM) {
		pd3dDevice->Flush();
		pd3dDevice->CopyResource(m_debugTex->m_pTexture, m_transformTex->m_pTexture);
		pd3dDevice->Flush();
		D3D10_MAPPED_TEXTURE2D mapped;
		//V(m_debugTex->m_pTexture->Map(0, D3D10_MAP_READ, D3D10_MAP_FLAG_DO_NOT_WAIT, &mapped));
		V(m_debugTex->m_pTexture->Map(0, D3D10_MAP_READ, 0, &mapped));
		float* vvv = (float*)mapped.pData;
		for (int c = 0; c < m_totalNumClusters; c++) {
			int i = c / m_cmTex->m_width;
			int j = c % m_cmTex->m_width;
			float* ptr = &vvv[i*mapped.RowPitch/4 + j*28];
			cout<<ptr[0]<<" "<<ptr[1]<<" "<<ptr[2]<<" "<<ptr[3]<<" "<<ptr[4]<<" "<<ptr[5]<<" "<<ptr[6]<<" "<<ptr[7]<<" "<<ptr[24]<<endl;
			cout<<ptr[8]<<" "<<ptr[9]<<" "<<ptr[10]<<" "<<ptr[11]<<" "<<ptr[12]<<" "<<ptr[13]<<" "<<ptr[14]<<" "<<ptr[15]<<" "<<ptr[25]<<endl;
			cout<<ptr[16]<<" "<<ptr[17]<<" "<<ptr[18]<<" "<<ptr[19]<<" "<<ptr[20]<<" "<<ptr[21]<<" "<<ptr[22]<<" "<<ptr[23]<<" "<<ptr[26]<<endl;
			cout<<"w = "<<ptr[27]<<endl;
		}
		cout<<endl;
		m_debugTex->m_pTexture->Unmap(0);
	}
	// *********** ---------------------------- ********

	// Compute goal position of the vertices in each of the clusters
	ComputeGVal(pd3dDevice);

	// Average the goal position for the vertices by summing over the goal position of vertices in each influenced cluster and then divide by the number of influence cluster
	ComputeGoalPos(pd3dDevice);

	// Update the velocity and position of the control vertices
	UpdateVelAndPos(pd3dDevice);

	// If pick is true, find out which control vertices fall inside the box in the normalized coordinate
	if (pick) {
		ComputePickedVertices(pd3dDevice, mins, maxs);
	}

// ------------------------------- Deal with surface mesh vertices (called real vertices) ---------------------------

	// Obtain their position by interpolating from the control mesh
	ComputeRealPosition(pd3dDevice);

	// Compute the normal of the vertices
	ComputeNormal(pd3dDevice);


	// Do the read back to obtain debugging information

	//pd3dDevice->CopyResource(m_debugTex2->m_pTexture, m_xTex[m_forRead]->m_pTexture);
	pd3dDevice->CopyResource(m_debugBuffer, m_collidingPairsBuffer);

	pd3dDevice->Flush();

	// Do ping-pong swap 
	swap(m_forRead, m_forWrite);
}


// A class for comparing pairs of integers by comparing the second component
class CompareSecond{
public: 
	bool operator()(const pair<int, int>& a, const pair<int, int>& b) const{
		return a.second < b.second;
	}
};

void CDeformableObjects::GenCubeMapAtlas(ID3D10Device* pd3dDevice) {

	// Specify how many objects we can generate cube maps for in a rendering pass
	const int MAX_NUM_TEXTURE_ARRAY_SIZE = 16;

	// Compute number of texture 2D slices for the cube maps
	UINT numTex2DForCubes = min(m_totalNumClusters, MAX_NUM_TEXTURE_ARRAY_SIZE);

	// Compute the width of the cube map
	UINT textSize2DWidth = m_CubePerRow * m_Resolution * 6;
	
	// Calculate number of cubes in 1 2D Texture slice
	UINT numCubesInOneTex2D = (UINT)ceil(m_totalNumClusters / ((float)numTex2DForCubes));

	// Calculate number of rows necessary for a 2D Texture
	UINT numCubesRowsPerTex2D = (UINT)ceil(numCubesInOneTex2D / ((float)m_CubePerRow));

	UINT textSize2DHeight = numCubesRowsPerTex2D * m_Resolution;

	// Create cube map atlas, map from the 6 faces of the cube map to a 2D texture
	// .--.--.--.--.--.--.
	// | 0|	1| 2| 3| 4| 5|
	// .--.--.--.--.--.--.

	float invT2DW= 1.0f / textSize2DWidth;		// A spacing in u direction 
	float invT2DH= 1.0f / textSize2DHeight;		// A spacing in v direction
	float* atlas = new float[6*m_Resolution*m_Resolution*2];
	float* pa = atlas;
	for (int face = 0; face < 6; face++) {
		for (DWORD row = 0; row < m_Resolution; row++) {
			for (DWORD col = 0; col < m_Resolution; col++) {
				(*pa++) = (float)((col + 0.5 + face*m_Resolution)*invT2DW);
				(*pa++) = (float)((row + 0.5)*invT2DH);
			}
		}
	}
	m_cubeMapAtlasTex = new CTexture2D(pd3dDevice, m_Resolution, m_Resolution, (float*)atlas, DXGI_FORMAT_R32G32_FLOAT, D3D10_USAGE_DEFAULT , D3D10_BIND_SHADER_RESOURCE, false, (D3D10_CPU_ACCESS_FLAG)0, D3D10_RESOURCE_MISC_TEXTURECUBE, 6);
	delete [] atlas;

	// Create renderable Texture2D array for rendering cluster cube map into

	// Will later on use depth texture
	float* cube2DInit = new float[numTex2DForCubes*textSize2DWidth*textSize2DHeight*4];
	for (int i = numTex2DForCubes*textSize2DWidth*textSize2DHeight*4 - 1; i >= 0; i--) {
		cube2DInit[i] = 1.0f;
	}
	m_cube2DTex = new CTexture2D(pd3dDevice, textSize2DWidth, textSize2DHeight, cube2DInit, DXGI_FORMAT_R32G32B32A32_FLOAT, D3D10_USAGE_DEFAULT , (D3D10_BIND_FLAG)(D3D10_BIND_SHADER_RESOURCE | D3D10_BIND_RENDER_TARGET), true, (D3D10_CPU_ACCESS_FLAG)0, (D3D10_RESOURCE_MISC_FLAG)0, numTex2DForCubes, true);

	delete [] cube2DInit;

	// Bind the resources
	m_deformableBodyEffect->m_pcubeMapAtlasTex->SetResource(m_cubeMapAtlasTex->m_pTextureRV);
	m_deformableBodyEffect->m_pcube2DTex->SetResource(m_cube2DTex->m_pTextureRV);

	// Create offset into the m_cube2DTex array for each of the m_clusters
	float* cubeTexOffset = new float[m_totalNumClusters*3];
	for (int i = 0; i < m_totalNumClusters; i++) {
		int indexInATex = i / numTex2DForCubes;
		cubeTexOffset[i*3+0] = (indexInATex % m_CubePerRow)*m_Resolution*6*invT2DW;
		cubeTexOffset[i*3+1] = (indexInATex / m_CubePerRow)*m_Resolution*invT2DH;
		cubeTexOffset[i*3+2] = (float)(i % numTex2DForCubes);
	}

	m_deformableBodyEffect->m_pcubeTexOffset->SetFloatVectorArray(cubeTexOffset, 0, m_totalNumClusters);
	delete [] cubeTexOffset;

	// Create viewport for the 6 faces of the cube map
	for (int i = 0; i < 6; i++) {
		m_cubeViewports[i].MinDepth = 0.0f;
		m_cubeViewports[i].MaxDepth = 1.0f;
		m_cubeViewports[i].TopLeftY = 0;
		m_cubeViewports[i].Width = m_Resolution;
		m_cubeViewports[i].Height = m_Resolution;
		m_cubeViewports[i].TopLeftX = m_Resolution * i;
	}

	HandleClustersControlFaces(pd3dDevice, numTex2DForCubes);

	// Create matrices for cube map
    float fHeight = 0.0f;
    D3DXVECTOR3 vEyePt = D3DXVECTOR3( 0.0f, 0.0, 0.0f );
    D3DXVECTOR3 vLookDir;
    D3DXVECTOR3 vUpDir;
	D3DXMATRIX cubeMat[6];
	D3DXMATRIX cubeProj;

	// +x
    vLookDir = D3DXVECTOR3( 1.0f, fHeight, 0.0f );
    vUpDir   = D3DXVECTOR3( 0.0f, 1.0f, 0.0f );
    D3DXMatrixLookAtLH( &cubeMat[0], &vEyePt, &vLookDir, &vUpDir );

	// -x
    vLookDir = D3DXVECTOR3(-1.0f, fHeight, 0.0f );
    vUpDir   = D3DXVECTOR3( 0.0f, 1.0f, 0.0f );
    D3DXMatrixLookAtLH( &cubeMat[1], &vEyePt, &vLookDir, &vUpDir );

	// +y
    vLookDir = D3DXVECTOR3( 0.0f, fHeight+1.0f, 0.0f );
    vUpDir   = D3DXVECTOR3( 0.0f, 0.0f,-1.0f );
    D3DXMatrixLookAtLH( &cubeMat[2], &vEyePt, &vLookDir, &vUpDir );

	// -y
    vLookDir = D3DXVECTOR3( 0.0f, fHeight-1.0f, 0.0f );
    vUpDir   = D3DXVECTOR3( 0.0f, 0.0f, 1.0f );
    D3DXMatrixLookAtLH( &cubeMat[3], &vEyePt, &vLookDir, &vUpDir );

	// +z
    vLookDir = D3DXVECTOR3( 0.0f, fHeight, 1.0f );
    vUpDir   = D3DXVECTOR3( 0.0f, 1.0f, 0.0f );
    D3DXMatrixLookAtLH( &cubeMat[4], &vEyePt, &vLookDir, &vUpDir );

	// -z
    vLookDir = D3DXVECTOR3( 0.0f, fHeight,-1.0f );
    vUpDir   = D3DXVECTOR3( 0.0f, 1.0f, 0.0f );
    D3DXMatrixLookAtLH( &cubeMat[5], &vEyePt, &vLookDir, &vUpDir );

	// Perspective projection with 90 deg FOV
    D3DXMatrixPerspectiveFovLH( &cubeProj, D3DX_PI * 0.5f, 1.0f, 0.01f, 100.f );
	for (int i = 0; i < 6; i++) {
		D3DXMatrixMultiply(&cubeMat[i], &cubeMat[i], &cubeProj);
	}
	m_deformableBodyEffect->m_pcubeMapViewProj->SetMatrixArray((float*)cubeMat, 0, 6);

}
void CDeformableObjects::HandleClustersControlFaces(ID3D10Device* pd3dDevice, int numTex2DForCubes) {
	// Create index buffer for the cluster faces
	// and also create buffer to map the premitive ID-->render target 
	// Each batch represent a draw call, so that we do not need to switch viewport very often

	// Compute the number of rendering batches we need to perform to generate cube map textures
	m_numCubeMapRenderBatchs = (DWORD)ceil(m_totalNumClusters / ((float)numTex2DForCubes)); 
	m_clustersControlFacesIndexBuffer = new CIndexBuffer<DWORD>*[m_numCubeMapRenderBatchs];
	m_clustersControlFacesRenderTargetIDBuffer = new ID3D10Buffer*[m_numCubeMapRenderBatchs];
	m_clustersControlFacesRenderTargetIDBufferRV = new ID3D10ShaderResourceView*[m_numCubeMapRenderBatchs];
	m_idToxValTexMappingBuffer = new ID3D10Buffer*[m_numCubeMapRenderBatchs];
	m_idToxValTexMappingBufferRV = new ID3D10ShaderResourceView*[m_numCubeMapRenderBatchs];

	int currentCluster = 0;
	UINT curRow = 0;

	// Loop through each batches
	for (DWORD batch = 0; batch < m_numCubeMapRenderBatchs; batch++) {
		vector<DWORD> indicesTmp;
		vector<DWORD> renderTargetTmp;
		vector<unsigned short> idToxValMappingTmp;
		int verticesSeenSoFar = 0;
		for (int i = 0; i < numTex2DForCubes; i++) {
			// Deal with faces stuffs
			int numMembers = (int)m_clustersFaces[currentCluster].size();
			vector<int>& vec = m_clustersFaces[currentCluster];
			for (int j = 0; j < numMembers; j++) {
				indicesTmp.push_back(verticesSeenSoFar+vec[j]);			
				
				if (j % 3 == 0) {
					// Put in i once every 3 index
					renderTargetTmp.push_back(i);
				}
			}				
			
			// Deal with vertices stuffs
			numMembers = (int)m_clusters[currentCluster].size();
			
			UINT numRows = (UINT)ceil(numMembers / ((float)m_xAdrTex->m_width));
			for (int j = 0; j < numMembers; j++) {
				
				idToxValMappingTmp.push_back((unsigned short)(j%m_xAdrTex->m_width));
				idToxValMappingTmp.push_back((unsigned short)(j/m_xAdrTex->m_width + curRow));				
			
			}
			verticesSeenSoFar += numMembers;
			curRow += numRows;
			currentCluster++;
			if (currentCluster == m_totalNumClusters) break;
		}

		// Now, create index buffer
		
		m_clustersControlFacesIndexBuffer[batch] = new CIndexBuffer<DWORD>(&indicesTmp[0], (UINT)indicesTmp.size(), pd3dDevice);

		// Create render target index buffer
		D3D10_BUFFER_DESC bd;
		D3D10_SUBRESOURCE_DATA InitData;

		bd.Usage = D3D10_USAGE_DEFAULT;
		bd.ByteWidth = (UINT)(sizeof( DWORD ) * renderTargetTmp.size());
		bd.BindFlags =     D3D10_BIND_SHADER_RESOURCE ;
		bd.CPUAccessFlags = 0;
		bd.MiscFlags = 0;
		
		InitData.pSysMem = &renderTargetTmp[0];
		HRESULT hr;

		V(pd3dDevice->CreateBuffer( &bd, &InitData, &m_clustersControlFacesRenderTargetIDBuffer[batch] )  != S_OK);
		D3D10_SHADER_RESOURCE_VIEW_DESC SRVDesc;
		ZeroMemory( &SRVDesc, sizeof(SRVDesc) );
		SRVDesc.Format = DXGI_FORMAT_R32_UINT;
		SRVDesc.ViewDimension =  D3D10_SRV_DIMENSION_BUFFER ;
		SRVDesc.Buffer.ElementOffset = 0;
		SRVDesc.Buffer.ElementWidth = (UINT)renderTargetTmp.size();
	
		V(pd3dDevice->CreateShaderResourceView( m_clustersControlFacesRenderTargetIDBuffer[batch] , &SRVDesc, &m_clustersControlFacesRenderTargetIDBufferRV[batch] ));	

		// Create mapping from vertex id to position to fetch vertex position in the m_xValTex
		bd.Usage = D3D10_USAGE_DEFAULT;
		bd.ByteWidth = (UINT)(sizeof( unsigned short ) * idToxValMappingTmp.size());
		bd.BindFlags =     D3D10_BIND_SHADER_RESOURCE ;
		bd.CPUAccessFlags = 0;
		bd.MiscFlags = 0;
		
		InitData.pSysMem = &idToxValMappingTmp[0];		

		V(pd3dDevice->CreateBuffer( &bd, &InitData, &m_idToxValTexMappingBuffer[batch] )  != S_OK);
		ZeroMemory( &SRVDesc, sizeof(SRVDesc) );
		SRVDesc.Format = DXGI_FORMAT_R16G16_UINT;
		SRVDesc.ViewDimension =  D3D10_SRV_DIMENSION_BUFFER ;
		SRVDesc.Buffer.ElementOffset = 0;
		SRVDesc.Buffer.ElementWidth = (UINT)idToxValMappingTmp.size() / 2;
	
		V(pd3dDevice->CreateShaderResourceView( m_idToxValTexMappingBuffer[batch] , &SRVDesc, &m_idToxValTexMappingBufferRV[batch] ));	

		
		if (currentCluster == m_totalNumClusters) break;

	}
}

void CDeformableObjects::ComputePickedVertices(ID3D10Device* pd3dDevice, D3DXVECTOR2& mins, D3DXVECTOR2& maxs) {
	// Set vertex buffer to none
	ID3D10Buffer* buffers[1];
	UINT tmp = 0;
	buffers[0] = NULL;
	pd3dDevice->IASetVertexBuffers( 0, 1, buffers, &tmp, &tmp );
    pd3dDevice->IASetPrimitiveTopology( D3D10_PRIMITIVE_TOPOLOGY_POINTLIST );
	pd3dDevice->IASetInputLayout(0);
	UINT offsets[1] = {0};

	// Set stream 

    pd3dDevice->SOSetTargets( 1, &m_pickedVerticesBuffer, offsets );
	
	// Do a computation
	m_deformableBodyEffect->m_pxTex->SetResource( m_xTex[m_forRead]->m_pTextureRV );
	
	m_deformableBodyEffect->m_minsPickNC->SetFloatVector(&mins[0]);
	m_deformableBodyEffect->m_maxsPickNC->SetFloatVector(&maxs[0]);
	m_deformableBodyEffect->m_pComputePickedVerticesTechnique->GetPassByIndex( 0 )->Apply(0);
	pd3dDevice->Draw(m_totalNumControls, 0);


	// Set stream output back to normal
    pd3dDevice->SOSetTargets( 1, buffers, offsets );

	// Restore vertex buffer input layout
	pd3dDevice->IASetInputLayout( m_deformableBodyEffect->m_gpgpuLayout);		
}

void CDeformableObjects::PickedPointsRender(ID3D10Device* pd3dDevice) {
	ID3D10Buffer* buffers[1];
	UINT strides[1];
	UINT offsets[1];

	// Set for draw auto
	buffers[0] = m_pickedVerticesBuffer;
	strides[0] = 8;
	offsets[0] = 0;
    pd3dDevice->IASetVertexBuffers( 0, 1, buffers, strides, offsets );
	pd3dDevice->IASetPrimitiveTopology( D3D10_PRIMITIVE_TOPOLOGY_POINTLIST );
	pd3dDevice->IASetInputLayout(m_deformableBodyEffect->m_computeCollisionForceLayout);

	// Set the resource
	m_deformableBodyEffect->m_pxTex->SetResource( m_xTex[m_forRead]->m_pTextureRV );
	
	m_deformableBodyEffect->m_pPickedPointsRenderTechnique->GetPassByIndex( 0 )->Apply(0);
	pd3dDevice->DrawAuto();

}

void CDeformableObjects::ComputePickingForce(ID3D10Device* pd3dDevice) {
	ID3D10Buffer* buffers[1];
	UINT strides[1];
	UINT offsets[1];

	// Set for draw auto
	buffers[0] = m_pickedVerticesBuffer;
	strides[0] = 8;
	offsets[0] = 0;
    pd3dDevice->IASetVertexBuffers( 0, 1, buffers, strides, offsets );
	pd3dDevice->IASetPrimitiveTopology( D3D10_PRIMITIVE_TOPOLOGY_POINTLIST );
	pd3dDevice->IASetInputLayout(m_deformableBodyEffect->m_computeCollisionForceLayout);

	// Set viewport
	pd3dDevice->RSSetViewports( 1, &m_computePickingForceVP);
	
	// Set the resource
	m_deformableBodyEffect->m_pxTex->SetResource( m_xTex[m_forRead]->m_pTextureRV );
	
	// Set rendering target
	pd3dDevice->OMSetRenderTargets(1, &m_forceTex->m_pRTV, NULL);


	m_deformableBodyEffect->m_pComputePickingForceTechnique->GetPassByIndex( 0 )->Apply(0);
	pd3dDevice->DrawAuto();

	// Restore vertex buffer
	buffers[0] = m_gpgpuVB->m_pVertexBuffer;
	strides[0] = m_gpgpuVB->m_stride;
	offsets[0] = m_gpgpuVB->m_offset;
    pd3dDevice->IASetVertexBuffers( 0, 1, buffers, strides, offsets );
	
	// Set vertex buffer input layout
	pd3dDevice->IASetInputLayout( m_deformableBodyEffect->m_gpgpuLayout);
}

float CDeformableObjects::GetHeight(float x, float z) {

	// Obtain the height at a given position

	// Add offset (because height map is centered at (0,0,0))
	x += 0.5f*m_heightMapScale.x;
	z += 0.5f*m_heightMapScale.z;

	// If out of bound, output height = 0.0f
	if (x < 0.0f) return 0.0f;
	if (z < 0.0f) return 0.0f;
	if (x >= m_heightMapScale.x) return 0.0f;
	if (z >= m_heightMapScale.z) return 0.0f;

	// Remap the x coordinate to range from 0..heightMapWidth
	x = (x/m_heightMapScale.x)* (m_heightNormalMapTex->m_width-1);

	// Remap the y coordinate to range from 0..heightMapHeight
	z = (z/m_heightMapScale.z)* (m_heightNormalMapTex->m_height-1);

	// Perform bi-linear interpolation
	int ix = (int)x, iz = (int)z;
	float fx = x - ix, fz = z - iz;
	return (1.0f-fz)*  (fx*heightData[iz*m_heightNormalMapTex->m_width+ix]+(1.0f-fx)*heightData[iz*m_heightNormalMapTex->m_width+ix+1]) +
			   fz   *  (fx*heightData[(iz+1)*m_heightNormalMapTex->m_width+ix]+(1.0f-fx)*heightData[(iz+1)*m_heightNormalMapTex->m_width+ix+1]);
}
DWORD NextPowerOfTwo(DWORD v) {
	v--;
	v |= v >> 1;
	v |= v >> 2;
	v |= v >> 4;
	v |= v >> 8;
	v |= v >> 16;
	return v+1;
}

int ShiftAmount(DWORD amount) {
	DWORD amt = 0;
	while (amount > 0) {
		amount >>= 1;
		amt++;
	}
	return amt - 1;

}
// Precomputation stuffs for the objects
void CDeformableObjects::PreComputation(ID3D10Device* pd3dDevice, float* alphas, float* betas, float* hardness, float floorHardness) {
	GPGPUVertex gpuv;
	int numAllInfluences = 0;						// The sum of the number of influences over the vertices
	vector<GPGPUVertex> gpgpuVertices;				// For storing vertices for GPGPU stuffs

	m_totalNumClusters = (int)m_clusters.size();	// Number of clusters

	// Initialize the index to the ping-pong for reading and writing information from/to
	m_forRead = 0;
	m_forWrite = 1;

	// Number of terms to sum (the greater, the more computation is done for a fragment)
	m_sumPerPixel = 1;  // Must be power of 2

	// Number of pixels used for summation in a row 
	m_pixelPerRow = 1024;  // Must be power of 2

	// Figure out how clusters influence vertices
	vector<pair<int, int> > influenceVec;
	vector<int> clusterMember; // Map the vertex to a cluster it belong to 

	for (int i = 0; i < m_totalNumControls; i++) {
		influenceVec.push_back(pair<int, int>(i,0));
		clusterMember.push_back(0);
	}

	// Figure out how many clusters influence each of the vertex
	for (int i = 0; i < m_totalNumClusters; i++) {
		int numMembers = (int)m_clusters[i].size();
		numAllInfluences += numMembers;
		vector<int>::iterator it = m_clusters[i].begin();
		for (int j = 0; j < numMembers; j++) {
			clusterMember[*it] = i;
			influenceVec[*(it++)].second++;						
		}
	}

	// Sort the vertex by the number of influence clusters
	sort(influenceVec.begin(),influenceVec.end(), CompareSecond());

	// Create a mapping from the original vertices order to the sorted order
	vector<int> mapping(m_totalNumControls);
	for (int i = 0; i < m_totalNumControls; i++) {
		mapping[influenceVec[i].first] = i;
	}

	// Rearrange cluster membership
	for (int i = 0; i < m_totalNumClusters; i++) {
	int numMembers = (int)m_clusters[i].size();
		vector<int>::iterator it = m_clusters[i].begin();
		for (int j = 0; j < numMembers; j++) {
			*it = mapping[*it];
			it++;
		}
	}
	
	// Reorder control vertices
	m_controlPos = new D3DXVECTOR3[m_totalNumControls];
	m_masses = new float[m_totalNumControls];
	for (int i = 0; i < m_totalNumControls; i++) {
		m_controlPos[i] = m_tmpControlPos[influenceVec[i].first];
		m_masses[i] = m_tmpMasses[influenceVec[i].first];
	}

	// Rename control vertices influence
	for (size_t i = 0; i < m_realVertices.size(); i++) {
		for (int j = 0; j < 4; j++) {
			m_realVertices[i].m_controlIndex[j] = mapping[m_realVertices[i].m_controlIndex[j]];
		}
	}

	// Rename the constrained vertices
	for (size_t i = 0; i < m_constrainedVertices.size(); i++) {
		m_constrainedVertices[i] = mapping[m_constrainedVertices[i]];
	}

	// Add a macro definition of the sumPerPixel and numClusters before compiling the effect
	D3D10_SHADER_MACRO macro[3];
	char name0[50];
	char def0[50];
	char name1[50];
	char def1[50];

	sprintf_s(name0, 50, "sumPerPixel");
	sprintf_s(def0, 50, "%d", m_sumPerPixel);
	sprintf_s(name1, 50, "numClusters");
	sprintf_s(def1, 50, "%d", m_totalNumClusters);
	macro[0].Name = name0;
	macro[0].Definition = def0;
	macro[1].Name = name1;
	macro[1].Definition = def1;
	macro[2].Name = NULL;
	macro[2].Definition = NULL;

	m_deformableBodyEffect = new CDeformableBodyEffect(pd3dDevice, macro);

		
	// Initialize the m_clusters to objects mapping
	m_deformableBodyEffect->m_pclustersToObjects->SetIntArray(&m_clustersToObjects[0], 0, m_totalNumClusters);

	// Compute the inverse of the scaling for the height map
	float invHeightScale[3] = {1.0f / m_heightMapScale.x, 1.0f / m_heightMapScale.y, 1.0f / m_heightMapScale.z};

	// Set some of the constants
	m_deformableBodyEffect->m_pinvHeightScale->SetFloatVector(invHeightScale);
	m_deformableBodyEffect->m_pheightMapTex->SetResource(m_heightNormalMapTex->m_pTextureRV);
	m_deformableBodyEffect->m_pfloorHardness->SetFloat(floorHardness);
	m_deformableBodyEffect->m_pclustersHardness->SetFloatArray(&m_clustersHardness[0], 0, m_totalNumClusters);

	//-------------- Create m_xTex, m_vTex simple for now ---------
	UINT xTexW, xTexH;
	xTexW = NextPowerOfTwo((UINT)ceil(sqrtf((float)m_totalNumControls+1.0f)));
	xTexH = (UINT)ceil(((float)m_totalNumControls+1.0f) / ((float)xTexW));	
	m_deformableBodyEffect->m_pxTexW->SetInt(xTexW);

	// Create an array filled with initial position of the control points
	float* tmp;
	CreateTmpArray(m_controlPos, m_masses, m_totalNumControls, xTexW, xTexH, tmp);

	m_deformableBodyEffect->m_twoInvXTexW->SetFloat(2.0f/xTexW);
	m_deformableBodyEffect->m_twoInvXTexH->SetFloat(2.0f/xTexH);

	// Initialize positions
	m_xTex[0] = new CTexture2D(pd3dDevice, xTexW, xTexH, tmp, DXGI_FORMAT_R32G32B32A32_FLOAT, D3D10_USAGE_DEFAULT , (D3D10_BIND_FLAG)(D3D10_BIND_SHADER_RESOURCE | D3D10_BIND_RENDER_TARGET), true, (D3D10_CPU_ACCESS_FLAG) 0);
	m_xTex[1] = new CTexture2D(pd3dDevice, xTexW, xTexH, tmp, DXGI_FORMAT_R32G32B32A32_FLOAT, D3D10_USAGE_DEFAULT , (D3D10_BIND_FLAG)(D3D10_BIND_SHADER_RESOURCE | D3D10_BIND_RENDER_TARGET), true, (D3D10_CPU_ACCESS_FLAG) 0 );
	m_xTildaTex = new CTexture2D(pd3dDevice, xTexW, xTexH, tmp, DXGI_FORMAT_R32G32B32A32_FLOAT, D3D10_USAGE_DEFAULT , (D3D10_BIND_FLAG)(D3D10_BIND_SHADER_RESOURCE | D3D10_BIND_RENDER_TARGET), true, (D3D10_CPU_ACCESS_FLAG) 0 );

	// Initialize acceleration to 0
	m_aTildaTex = new CTexture2D(pd3dDevice, xTexW, xTexH, 0, DXGI_FORMAT_R32G32B32A32_FLOAT, D3D10_USAGE_DEFAULT , (D3D10_BIND_FLAG)(D3D10_BIND_SHADER_RESOURCE | D3D10_BIND_RENDER_TARGET), true, (D3D10_CPU_ACCESS_FLAG) 0 );
	memset(tmp, 0, 4*sizeof(float)*xTexW*xTexH);

	
	// Initialize velocity to 0 as well, Make sure the w component contain the alpha
	for (int i = 0; i < m_totalNumControls; i++) 
	{
		tmp[4*i+3] = alphas[m_clustersToObjects[clusterMember[influenceVec[i].first]]];
	}

	// For those constrained vertices, make the alpha 0 (special case)
	for (size_t i = 0; i < m_constrainedVertices.size(); i++) 
	{
		tmp[4*m_constrainedVertices[i]+3] = 0.0f;
	}
	
	m_vTex[0] = new CTexture2D(pd3dDevice, xTexW, xTexH, tmp, DXGI_FORMAT_R32G32B32A32_FLOAT, D3D10_USAGE_DEFAULT , (D3D10_BIND_FLAG)(D3D10_BIND_SHADER_RESOURCE | D3D10_BIND_RENDER_TARGET), true, (D3D10_CPU_ACCESS_FLAG) 0 );
	m_vTex[1] = new CTexture2D(pd3dDevice, xTexW, xTexH, tmp, DXGI_FORMAT_R32G32B32A32_FLOAT, D3D10_USAGE_DEFAULT , (D3D10_BIND_FLAG)(D3D10_BIND_SHADER_RESOURCE | D3D10_BIND_RENDER_TARGET), true, (D3D10_CPU_ACCESS_FLAG) 0 );
	delete [] tmp;

	// Create the objIDTex too 
	UINT* tmpu32 = new UINT[xTexW*xTexH];

	memset(tmpu32, 0, sizeof(UINT)*xTexW*xTexH);
	for (size_t i = 0; i < (DWORD)m_totalNumControls; i++) 
	{
		tmpu32[i] = m_clustersToObjects[clusterMember[influenceVec[i].first]];
	}
	m_objIDTex = new CTexture2D(pd3dDevice, xTexW, xTexH, (float*)tmpu32, DXGI_FORMAT_R32_UINT, D3D10_USAGE_DEFAULT ,D3D10_BIND_SHADER_RESOURCE);
	delete [] tmpu32;

	// Set the resource
	m_deformableBodyEffect->m_pobjIDTex->SetResource(m_objIDTex->m_pTextureRV);

	// Initialize the object alpha
	m_allAlphas = new float[m_numObjects];
	for (DWORD i = 0; i < m_numObjects; i++) {
		m_allAlphas[i] = alphas[i];
	}


	// --------------- Create m_xAdrTex -------------------
	// Figure out the size of this texture
	UINT xAdrTexW = m_sumPerPixel*m_pixelPerRow, xAdrTexH = 0;
	m_deformableBodyEffect->m_pxAdrTexW->SetInt(xAdrTexW);
	for (int i = 0; i < m_totalNumClusters; i++) {
		// Figure out how many rows this m_clusters take up
		// Must be divisible by m_sumPerPixel
		UINT numRows = (UINT)ceil(m_clusters[i].size() / ((float)xAdrTexW));

		// Make sure we have an additional entry that gaurantee to store 0 value in the m_xValTex texture
		// This entry is used to reduce the complexity of summing the influence of m_clusters on control points
		if (i == m_totalNumClusters-1) {
			numRows = (UINT)ceil((m_clusters[i].size()+1) / ((float)xAdrTexW));
		}
		xAdrTexH += numRows;
	}

	UINT entries = xAdrTexW*xAdrTexH;
	short* tmpui = new short[2*entries];
	short* ti = tmpui;
	short junkY = (short)(m_totalNumControls / xTexW), junkX = (short)(m_totalNumControls % xTexW);

	// Initialize with junk vertex position
	for (UINT i = 0; i < entries; i++) {
		*(ti++) = junkX;
		*(ti++) = junkY;
	}

	// Create xAdrTex so that for each cluster it stores pointers to the control points that are the member of the cluster
	UINT curRow = 0;
	for (int i = 0; i < m_totalNumClusters; i++) {
		// For each of the cluster,
		int numMembers = (int)m_clusters[i].size();
		UINT numRows = (UINT)ceil(numMembers/ ((float)xAdrTexW));
		short* ptr = &tmpui[curRow*2*xAdrTexW];
		vector<int>& vec = m_clusters[i];

		// Go through all of its members and compute the pointer and store in the texture
		for (int j = 0; j < numMembers; j++) {
			*(ptr++) = (short)(vec[j] % xTexW);
			*(ptr++) = (short)(vec[j] / xTexW);
		}
		curRow += numRows;
	}
	m_xAdrTex = new CTexture2D(pd3dDevice, xAdrTexW, xAdrTexH, (float*)tmpui, DXGI_FORMAT_R16G16_UINT, D3D10_USAGE_IMMUTABLE, D3D10_BIND_SHADER_RESOURCE);
	delete [] tmpui;

	// -------------- Create m_xValTex --------------------------
	tmp = new float[4*xAdrTexW*xAdrTexH];
	memset(tmp, 0, 4*xAdrTexW*xAdrTexH*sizeof(float));
	m_xValTex = new CTexture2D(pd3dDevice, xAdrTexW, xAdrTexH, 0, DXGI_FORMAT_R32G32B32A32_FLOAT, D3D10_USAGE_DEFAULT , (D3D10_BIND_FLAG)(D3D10_BIND_SHADER_RESOURCE | D3D10_BIND_RENDER_TARGET), true );
	if (debugMode == DEBUG_XVAL) {
		m_debugTex = new CTexture2D(pd3dDevice, xAdrTexW, xAdrTexH, 0, DXGI_FORMAT_R32G32B32A32_FLOAT, D3D10_USAGE_STAGING, (D3D10_BIND_FLAG)(0), false, D3D10_CPU_ACCESS_READ );
	}
	// -------------- Create m_pValTex --------------------------
	m_pValTex = new CTexture2D(pd3dDevice, xAdrTexW, xAdrTexH, 0, DXGI_FORMAT_R32G32B32A32_FLOAT, D3D10_USAGE_DEFAULT , (D3D10_BIND_FLAG)(D3D10_BIND_SHADER_RESOURCE | D3D10_BIND_RENDER_TARGET), true );
	delete [] tmp;

	// -------------- Create m_cmTex ----------------------------
	UINT cmTexW = NextPowerOfTwo((UINT)ceil(sqrtf((float)m_totalNumClusters)));
	UINT cmTexH = (UINT)ceil(((float)m_totalNumClusters) / ((float)cmTexW));

	m_deformableBodyEffect->m_pcmTexW->SetInt(cmTexW);
	m_cmTex = new CTexture2D(pd3dDevice, cmTexW, cmTexH, 0, DXGI_FORMAT_R32G32B32A32_FLOAT, D3D10_USAGE_DEFAULT, (D3D10_BIND_FLAG)(D3D10_BIND_SHADER_RESOURCE | D3D10_BIND_RENDER_TARGET), true );

	// ------------- Create m_minsTex -----------------------
	m_minsTex = new CTexture2D(pd3dDevice, cmTexW, cmTexH, 0, DXGI_FORMAT_R32G32B32A32_FLOAT, D3D10_USAGE_DEFAULT, (D3D10_BIND_FLAG)(D3D10_BIND_SHADER_RESOURCE | D3D10_BIND_RENDER_TARGET), true );

	// ------------- Create m_maxsTex -----------------------
	m_nmaxsTex = new CTexture2D(pd3dDevice, cmTexW, cmTexH, 0, DXGI_FORMAT_R32G32B32A32_FLOAT, D3D10_USAGE_DEFAULT, (D3D10_BIND_FLAG)(D3D10_BIND_SHADER_RESOURCE | D3D10_BIND_RENDER_TARGET), true );
	if ((debugMode == DEBUG_CM) || (debugMode == DEBUG_MINSMAXS)) {
		m_debugTex = new CTexture2D(pd3dDevice, cmTexW, cmTexH, 0, DXGI_FORMAT_R32G32B32A32_FLOAT, D3D10_USAGE_STAGING, (D3D10_BIND_FLAG)(0), false, D3D10_CPU_ACCESS_READ );
		m_debugTex2 = new CTexture2D(pd3dDevice, xAdrTexW, xAdrTexH, 0, DXGI_FORMAT_R32G32B32A32_FLOAT, D3D10_USAGE_STAGING, (D3D10_BIND_FLAG)(0), false, D3D10_CPU_ACCESS_READ );
	}

	// -------------- Create m_qBarTex ---------------------------
	D3DXVECTOR4* tmpv4 = new D3DXVECTOR4[xAdrTexW*3*xAdrTexH];
	memset(tmpv4, 0, sizeof(float)*4*xAdrTexW*3*xAdrTexH);
	curRow = 0;
	for (int i = 0; i < m_totalNumClusters; i++) {
		// For each of the cluster, 
		int numMembers = (int)m_clusters[i].size();
		UINT numRows = (UINT)ceil(numMembers/ ((float)xAdrTexW));
		
		// Compute cm
		D3DXVECTOR3 sumV = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
		float sumM = 0.0f;
		for (int j = 0; j < numMembers; j++) {
			sumV += m_controlPos[m_clusters[i].at(j)]*m_masses[m_clusters[i].at(j)];
			sumM += m_masses[m_clusters[i].at(j)];
		}
		sumV /= sumM;
		D3DXVECTOR4* ptr = &tmpv4[xAdrTexW*3*curRow];

		// Then compute qBar
		for (int j = 0; j < numMembers; j++) {
			// Compute q first,
			D3DXVECTOR3 q = m_controlPos[m_clusters[i].at(j)] - sumV;

			// Then store qBar in 3 adjacent texel
			*(ptr++) = D3DXVECTOR4(q.x, q.y, q.z, q.x*q.x);
			*(ptr++) = D3DXVECTOR4(q.y*q.y, q.z*q.z, q.x*q.y, q.x*q.z);
			*(ptr++) = D3DXVECTOR4(q.y*q.z, 0, 0, 0);
		}
		curRow += numRows;
	}
	m_qBarTex = new CTexture2D(pd3dDevice, xAdrTexW*3, xAdrTexH, (float*)tmpv4, DXGI_FORMAT_R32G32B32A32_FLOAT, D3D10_USAGE_DEFAULT, (D3D10_BIND_FLAG)(D3D10_BIND_SHADER_RESOURCE | D3D10_BIND_RENDER_TARGET), true );

	// -------------- Create m_AqqBarTex -------------------------
	float* AqqBarTexMem = new float[12*cmTexW*cmTexH*4];
	float AqqBar[9][9];
	curRow = 0;
	float* aMem = AqqBarTexMem;

	for (int i = 0; i < m_totalNumClusters; i++) {
		// For each cluster,
		int numMembers = (int)m_clusters[i].size();
		UINT numRows = (UINT)ceil(numMembers/ ((float)xAdrTexW));

		// Obtain the pointer to qBar
		float* ptr = (float*)&tmpv4[xAdrTexW*3*curRow];
		memset(AqqBar, 0, 81*sizeof(float));

		// Compute AqqBar^-1
		for (int j = 0; j < numMembers; j++) {
			for (int i1 = 0; i1 < 9; i1++) {
				for (int i2 = 0; i2 < 9; i2++) {
					AqqBar[i1][i2] += m_masses[m_clusters[i].at(j)]*ptr[i1]*ptr[i2];
				}
			}
			ptr += 12;
		}

		// Inverse to get AqqBar
		Inverse9x9(AqqBar);

		if (debugMode == DEBUG_AQQBAR) {
			for (int r = 0; r < 9; r++) {
				for (int c = 0; c < 9; c++) {
					cout<<AqqBar[r][c]<<" ";
				}
				cout<<endl;
			}
			cout<<endl;
		}

		// Store them in consecutive 12 texels (45 independent entries + 3 padding) / 4
		for (int i1 = 0; i1 < 9; i1++) {
			for (int i2 = i1; i2 < 9; i2++) {
				*(aMem++) = AqqBar[i1][i2];
			}
		}

		// Padding
		*(aMem++) = 0.0f;
		*(aMem++) = 0.0f;
		*(aMem++) = 0.0f;

		curRow += numRows;
	}

	delete [] tmpv4;
	m_AqqBarTex = new CTexture2D(pd3dDevice, cmTexW*12, cmTexH, AqqBarTexMem, DXGI_FORMAT_R32G32B32A32_FLOAT, D3D10_USAGE_DEFAULT, (D3D10_BIND_FLAG)(D3D10_BIND_SHADER_RESOURCE | D3D10_BIND_RENDER_TARGET), true );
	delete [] AqqBarTexMem;

	// -------------- Create m_ApqBarTex ---------------------------
	m_ApqBarTex = new CTexture2D(pd3dDevice, cmTexW*7, cmTexH, 0, DXGI_FORMAT_R32G32B32A32_FLOAT, D3D10_USAGE_DEFAULT, (D3D10_BIND_FLAG)(D3D10_BIND_SHADER_RESOURCE | D3D10_BIND_RENDER_TARGET), true );
	
	// -------------- Create TransformTex ---------------------------
	m_transformTex = new CTexture2D(pd3dDevice, cmTexW*7, cmTexH, 0, DXGI_FORMAT_R32G32B32A32_FLOAT, D3D10_USAGE_DEFAULT, (D3D10_BIND_FLAG)(D3D10_BIND_SHADER_RESOURCE | D3D10_BIND_RENDER_TARGET), true );
	if ( (debugMode == DEBUG_APQBAR) || (debugMode == DEBUG_TRANSFORM) ) {
		m_debugTex = new CTexture2D(pd3dDevice, cmTexW*7, cmTexH, 0, DXGI_FORMAT_R32G32B32A32_FLOAT, D3D10_USAGE_STAGING, (D3D10_BIND_FLAG)(0), false, D3D10_CPU_ACCESS_READ );
	}

	// -------------- Create m_gValTex -----------------------------
	// Setup the pinv3xAdrW variable
	m_deformableBodyEffect->m_pinv3xAdrW->SetFloat(1.0f / (xAdrTexW*3.0f));
	m_deformableBodyEffect->m_pthreeXAdrW->SetFloat(xAdrTexW*3.0f);
	m_gValTex = new CTexture2D(pd3dDevice, xAdrTexW, xAdrTexH, 0, DXGI_FORMAT_R32G32B32A32_FLOAT, D3D10_USAGE_DEFAULT , (D3D10_BIND_FLAG)(D3D10_BIND_SHADER_RESOURCE | D3D10_BIND_RENDER_TARGET), true );	

	// -------------- Create m_forceValTex -----------------------------
	m_forceValTex = new CTexture2D(pd3dDevice, xAdrTexW, xAdrTexH, 0, DXGI_FORMAT_R32G32B32A32_FLOAT, D3D10_USAGE_DEFAULT , (D3D10_BIND_FLAG)(D3D10_BIND_SHADER_RESOURCE | D3D10_BIND_RENDER_TARGET), true );	
	// -------------- Create m_forceTex ---------------------------
	m_forceTex = new CTexture2D(pd3dDevice, xTexW, xTexH, 0, DXGI_FORMAT_R32G32B32A32_FLOAT, D3D10_USAGE_DEFAULT , (D3D10_BIND_FLAG)(D3D10_BIND_SHADER_RESOURCE | D3D10_BIND_RENDER_TARGET), true, (D3D10_CPU_ACCESS_FLAG) 0);

	// -------------- Create m_gTex ---------------------------
	m_gTex = new CTexture2D(pd3dDevice, xTexW, xTexH, 0, DXGI_FORMAT_R32G32B32A32_FLOAT, D3D10_USAGE_DEFAULT , (D3D10_BIND_FLAG)(D3D10_BIND_SHADER_RESOURCE | D3D10_BIND_RENDER_TARGET), true, (D3D10_CPU_ACCESS_FLAG) 0);

	// -------------- Create m_gAdrTex ---------------------------
	unsigned long* affectedBigList = new unsigned long[numAllInfluences];
	int* numAffected = new int[m_totalNumControls];
	unsigned long** affectedList = new  unsigned long* [m_totalNumControls];
	memset(numAffected, 0, sizeof(int)*m_totalNumControls);
	unsigned long * curPtr = affectedBigList;
	for (int i = 0; i < m_totalNumControls; i++) {
		affectedList[i] = curPtr;
		curPtr += influenceVec[i].second;
	}
	curRow = 0;

	// Find out how many clusters have influence on each control point
	for (int i = 0; i < m_totalNumClusters; i++) {
		int numMembers = (int)m_clusters[i].size();
		UINT numRows = (UINT)ceil(numMembers / ((float)xAdrTexW));
		vector<int>& vec = m_clusters[i];

		// Loop through all the members of the control points
		for (int j = 0; j < numMembers; j++) {
			affectedList[vec[j]][numAffected[vec[j]]] = ((j % xAdrTexW)) | (((j / xAdrTexW + curRow)) << 16);
			numAffected[vec[j]]++;
		}
		curRow += numRows;
	}

	// Now, figure out the size of the texture needed
	int totalHeight = 0;
	int currentNumClusters = 1;
	vector<GPGPUVertex> computeGoalVertices;

	// Need to draw at least once anyway, assuming all vertices are affected by at least 1 cluster
	gpuv.Pos = D3DXVECTOR4(-1.0f,-1.0f,0,1);
	gpuv.UV = D3DXVECTOR4(-0.5f,xTexH-0.5f,0.0f,0.0f);
	computeGoalVertices.push_back(gpuv);	
	gpuv.Pos = D3DXVECTOR4(-1.0f,1.0f,0,1);
	gpuv.UV = D3DXVECTOR4(-0.5f,-0.5f,0.0f,0.0f);
	computeGoalVertices.push_back(gpuv);
	gpuv.Pos = D3DXVECTOR4(1.0f,-1.0f,0,1);
	gpuv.UV = D3DXVECTOR4(xTexW-0.5f,xTexH-0.5f,0.0f,0.0f);
	computeGoalVertices.push_back(gpuv);

	gpuv.Pos = D3DXVECTOR4(-1.0f,1.0f,0,1);
	gpuv.UV = D3DXVECTOR4(-0.5f,-0.5f,0.0f,0.0f);
	computeGoalVertices.push_back(gpuv);
	gpuv.Pos = D3DXVECTOR4(1.0f,1.0f,0,1);
	gpuv.UV = D3DXVECTOR4(xTexW-0.5f,-0.5f,0.0f,0.0f);
	computeGoalVertices.push_back(gpuv);
	gpuv.Pos = D3DXVECTOR4(1.0f,-1.0f,0,1);
	gpuv.UV = D3DXVECTOR4(xTexW-0.5f,xTexH-0.5f,0.0f,0.0f);
	computeGoalVertices.push_back(gpuv);
	totalHeight += xTexH;
	
	// Calculate the height of the m_gAdrTex texture
	for (int i = 0; i < m_totalNumControls; i++) {
		if (influenceVec[i].second != currentNumClusters) {

			int c = i % xTexW , r = i / xTexW;

			int delta = influenceVec[i].second - currentNumClusters;
			// Add quads to cover the remaining vertices
			//        one quad to cover all the remaining control points in the rows below
			//        one other quad (actually a line) to cover the remaining control points in the current row
			int addedHeight = (xTexH - r);

			// Compute the dimension of the quads
			float y1 = -(r*(2.0f / xTexH) - 1.0f),
				  y1p1 = -((r+1)*(2.0f / xTexH) - 1.0f),
				  y2 = -1.0f,
				  x = c*(2.0f / xTexW) - 1;

			for (int q = 0; q < delta; q++) {
				// For the remaining rows, except this row
				gpuv.Pos = D3DXVECTOR4(-1.0f,y2,0,1);
				gpuv.UV = D3DXVECTOR4(-0.5f,totalHeight+addedHeight-0.5f,0.0f,0.0f);
				computeGoalVertices.push_back(gpuv);
				gpuv.Pos = D3DXVECTOR4(-1.0f,y1p1,0,1);
				gpuv.UV = D3DXVECTOR4(-0.5f,totalHeight+1-0.5f,0.0f,0.0f);
				computeGoalVertices.push_back(gpuv);
				gpuv.Pos = D3DXVECTOR4(1.0f,y2,0,1);
				gpuv.UV = D3DXVECTOR4(xTexW-0.5f,totalHeight+addedHeight-0.5f,0.0f,0.0f);
				computeGoalVertices.push_back(gpuv);

				gpuv.Pos = D3DXVECTOR4(-1.0f,y1p1,0,1);
				gpuv.UV = D3DXVECTOR4(-0.5f,totalHeight+1-0.5f,0.0f,0.0f);
				computeGoalVertices.push_back(gpuv);
				gpuv.Pos = D3DXVECTOR4(1.0f,y1p1,0,1);
				gpuv.UV = D3DXVECTOR4(xTexW-0.5f,totalHeight+1-0.5f,0.0f,0.0f);
				computeGoalVertices.push_back(gpuv);
				gpuv.Pos = D3DXVECTOR4(1.0f,y2,0,1);
				gpuv.UV = D3DXVECTOR4(xTexW-0.5f,totalHeight+addedHeight-0.5f,0.0f,0.0f);
				computeGoalVertices.push_back(gpuv);
	
				// For the remaining of this row
				gpuv.Pos = D3DXVECTOR4(x,y1p1,0,1);
				gpuv.UV = D3DXVECTOR4(c-0.5f,totalHeight+1-0.5f,0.0f,0.0f);
				computeGoalVertices.push_back(gpuv);
				gpuv.Pos = D3DXVECTOR4(x,y1,0,1);
				gpuv.UV = D3DXVECTOR4(c-0.5f,totalHeight-0.5f,0.0f,0.0f);
				computeGoalVertices.push_back(gpuv);
				gpuv.Pos = D3DXVECTOR4(1.0f,y1p1,0,1);
				gpuv.UV = D3DXVECTOR4(xTexW-0.5f,totalHeight+1-0.5f,0.0f,0.0f);
				computeGoalVertices.push_back(gpuv);

				gpuv.Pos = D3DXVECTOR4(x,y1,0,1);
				gpuv.UV = D3DXVECTOR4(c-0.5f,totalHeight-0.5f,0.0f,0.0f);
				computeGoalVertices.push_back(gpuv);
				gpuv.Pos = D3DXVECTOR4(1.0f,y1,0,1);
				gpuv.UV = D3DXVECTOR4(xTexW-0.5f,totalHeight-0.5f,0.0f,0.0f);
				computeGoalVertices.push_back(gpuv);
				gpuv.Pos = D3DXVECTOR4(1.0f,y1p1,0,1);
				gpuv.UV = D3DXVECTOR4(xTexW-0.5f,totalHeight+1-0.5f,0.0f,0.0f);
				computeGoalVertices.push_back(gpuv);

				totalHeight += addedHeight;
			}
			currentNumClusters = influenceVec[i].second;
		}
	}
	// Create the initial data for texture 
	unsigned long* tmpul = new unsigned long[xTexW*totalHeight];
	unsigned long* ptrul =  tmpul;
	unsigned long fill = (xTexH-1) | ((xTexW-1) << 16);
	
	// Initialize it so that it refers to the sentinel vertex that stores 0
	for (int i = xTexW*totalHeight-1; i >= 0; i--) {
		tmpul[i] = fill;
	}
	// Calculate the height of the m_gAdrTex texture
	ptrul = tmpul;
	for (int i = 0; i < m_totalNumControls; i++) {
		*(ptrul++) = affectedList[i][0];
	}
	curRow = xTexH;
	currentNumClusters = 1;
	int curInfluence = 1;

	// The following computation basically produce the textures for the pass for computing goal position
	// of a control point, by averaging from the goal positions of the control points from all the clusters that
	// influence it.
	for (int i = 0; i < m_totalNumControls; i++) {
		if (influenceVec[i].second != currentNumClusters) {
			int c = i % xTexW , r = i / xTexW;
			int delta = influenceVec[i].second - currentNumClusters;
			int addedHeight = (xTexH - r);
			for (int q = 0; q < delta; q++) {
				ptrul = &tmpul[xTexW*curRow + c];
				for (int j = i; j < m_totalNumControls; j++) {
					*(ptrul++) = affectedList[j][curInfluence];
				}
				curInfluence++;
				curRow += addedHeight;	
			}
			currentNumClusters = influenceVec[i].second;
		}
	}
	
	m_gAdrTex = new CTexture2D(pd3dDevice, xTexW, totalHeight, (float*)tmpul, DXGI_FORMAT_R16G16_UINT, D3D10_USAGE_IMMUTABLE, D3D10_BIND_SHADER_RESOURCE);
	delete [] tmpul;
	delete [] affectedList;
	delete [] affectedBigList;

	// Create the texture for storing the real position
	// -------------- Create m_gTex ---------------------------
	UINT posTexW = NextPowerOfTwo((UINT)ceil(sqrtf((float)m_totalNumRealVertices)));
	UINT posTexH = (UINT)ceil((float)m_totalNumRealVertices / ((float)posTexW));
	m_deformableBodyEffect->m_pposTexW->SetInt(posTexW);
	m_deformableBodyEffect->m_pcomputeNormalScaleU->SetFloat(2.0f / ((float)posTexW));
	m_deformableBodyEffect->m_pcomputeNormalScaleV->SetFloat(2.0f / ((float)posTexH));
	
	unsigned long* posAdr = new unsigned long[posTexW*posTexH*4];
	unsigned long* pA = posAdr;
	float* posWeight = new float[posTexW*posTexH*4];
	float* pW = posWeight;
	


	memset(posAdr, 0, sizeof(unsigned long)*posTexW*posTexH);
	memset(posWeight, 0, sizeof(float)*posTexW*posTexH);

	// Create texture that contains the pointers to the 4 control points that will be interpolated to get
	// the position of the vertex
	for (UINT i = 0; i < m_totalNumRealVertices; i++)	{ 
		for (int j = 0; j < 4; j++) {
			*(pA++) = (m_realVertices[i].m_controlIndex[j] % xTexW) | ((m_realVertices[i].m_controlIndex[j] / xTexW) << 16);
			*(pW++) = m_realVertices[i].m_controlWeight[j];
		}
	}
	m_posAdrTex = new CTexture2D(pd3dDevice, posTexW, posTexH, (float*)posAdr, DXGI_FORMAT_R32G32B32A32_UINT, D3D10_USAGE_DEFAULT , (D3D10_BIND_FLAG)(D3D10_BIND_SHADER_RESOURCE | D3D10_BIND_RENDER_TARGET), true, (D3D10_CPU_ACCESS_FLAG) 0);
	m_posWeightTex = new CTexture2D(pd3dDevice, posTexW, posTexH, posWeight, DXGI_FORMAT_R32G32B32A32_FLOAT, D3D10_USAGE_DEFAULT , (D3D10_BIND_FLAG)(D3D10_BIND_SHADER_RESOURCE | D3D10_BIND_RENDER_TARGET), true, (D3D10_CPU_ACCESS_FLAG) 0);
	m_posTex = new CTexture2D(pd3dDevice, posTexW, posTexH, 0, DXGI_FORMAT_R32G32B32A32_FLOAT, D3D10_USAGE_DEFAULT , (D3D10_BIND_FLAG)(D3D10_BIND_SHADER_RESOURCE | D3D10_BIND_RENDER_TARGET), true, (D3D10_CPU_ACCESS_FLAG) 0);
	m_normalTex = new CTexture2D(pd3dDevice, posTexW, posTexH, 0, DXGI_FORMAT_R32G32B32A32_FLOAT, D3D10_USAGE_DEFAULT , (D3D10_BIND_FLAG)(D3D10_BIND_SHADER_RESOURCE | D3D10_BIND_RENDER_TARGET), true, (D3D10_CPU_ACCESS_FLAG) 0);
//	m_debugTex = new CTexture2D(pd3dDevice, posTexW, posTexH, 0, DXGI_FORMAT_R32G32B32A32_FLOAT, D3D10_USAGE_STAGING , (D3D10_BIND_FLAG)(0), false, D3D10_CPU_ACCESS_READ );
	delete [] posAdr;
	delete [] posWeight;

	// Deal with the pass of computing xValTex)
	
	m_computeXValStart = 0;
	gpuv.Pos = D3DXVECTOR4(-1.0f,-1.0f,0,1);
	gpuv.UV = D3DXVECTOR4(-0.5f,xAdrTexH-0.5f,0.0f,0.0f);
	gpgpuVertices.push_back(gpuv);
	gpuv.Pos = D3DXVECTOR4(-1.0f,1.0f,0,1);
	gpuv.UV = D3DXVECTOR4(-0.5f,-0.5f,0.0f,0.0f);
	gpgpuVertices.push_back(gpuv);
	gpuv.Pos = D3DXVECTOR4(1.0f,-1.0f,0,1);
	gpuv.UV = D3DXVECTOR4(xAdrTexW-0.5f,xAdrTexH-0.5f,0.0f,0.0f);
	gpgpuVertices.push_back(gpuv);
	gpuv.Pos = D3DXVECTOR4(1.0f,1.0f,0,1);
	gpuv.UV = D3DXVECTOR4(xAdrTexW-0.5f,-0.5f,0.0f,0.0f);
	gpgpuVertices.push_back(gpuv);

	m_computeXValVP.Width = xAdrTexW;
	m_computeXValVP.Height = xAdrTexH;
	m_computeXValVP.MinDepth = 0.0f;
	m_computeXValVP.MaxDepth = 1.0f;
	m_computeXValVP.TopLeftX = 0;
	m_computeXValVP.TopLeftY = 0;


	// Deal with computing CM)
	m_computeCMStart = (int)gpgpuVertices.size();
	curRow = 0;
	float twoInvcmTexH = 2.0f / ((float)cmTexH), twoInvcmTexW = 2.0f / ((float)cmTexW);

	// For each of the cluster
	for (int i = 0; i < m_totalNumClusters; i++) {
		UINT numRows = (UINT)ceil(m_clusters[i].size() / ((float)xAdrTexW));
		gpuv.Pos = D3DXVECTOR4((float)(i % cmTexW), (float)(i / cmTexW), 0.0f,1.0f) + D3DXVECTOR4(0.5f, 0.5f, 0.0f, 0.0f);  
		gpuv.Pos.x *= twoInvcmTexW;
		gpuv.Pos.y *= twoInvcmTexH;
		gpuv.Pos -= D3DXVECTOR4(1.0f, 1.0f, 0.0f,0);
		gpuv.Pos.y *= -1.0f;

		// Create a number of fragments enough to sum the contribution of the control points
		int numPixs = (int)ceil((float)m_clusters[i].size() / ((float)m_sumPerPixel));
		for (int j = 0; j < numPixs; j++) {
			gpuv.UV = D3DXVECTOR4((float)(j % m_pixelPerRow)*m_sumPerPixel, (float)(j / m_pixelPerRow) + curRow,0.0f,0.0f);	
			gpgpuVertices.push_back(gpuv);
		}
		curRow+=numRows;
	}
	m_computeCMNum = (int)(gpgpuVertices.size() - m_computeCMStart);
	m_computeCMVP.Width = cmTexW;
	m_computeCMVP.Height = cmTexH;
	m_computeCMVP.MinDepth = 0.0f;
	m_computeCMVP.MaxDepth = 1.0f;
	m_computeCMVP.TopLeftX = 0;
	m_computeCMVP.TopLeftY = 0;
	
	// Deal with computing Apqbar
	m_computeApqBarStart = (int)gpgpuVertices.size();
	curRow = 0;
	float twoInv7S = 2.0f / (((float)cmTexW)*7.0f);
	m_deformableBodyEffect->m_ptwoInv7S->SetFloat(twoInv7S);

	for (int i = 0; i < m_totalNumClusters; i++) {
		UINT numRows = (UINT)ceil((float)(m_clusters[i].size()) / ((float)xAdrTexW));
		gpuv.Pos = D3DXVECTOR4((float)((i % cmTexW)*7), (float)(i / cmTexW), 0.0f, 1.0f) + D3DXVECTOR4(0.5f, 0.5f, 0.0f, 0.0f);  
		gpuv.Pos.x *= twoInv7S;
		gpuv.Pos.y *= twoInvcmTexH;
		gpuv.Pos -= D3DXVECTOR4(1.0f, 1.0f, 0.0f, 0.0f);
		gpuv.Pos.y *= -1.0f;
		// UV, xy integer texcoord for xVal, if x is multiplied by 3, will be tex coord for m_qBarTex
		//     zw integer texcoord for cm
		int numPixs = (int)ceil((float)m_clusters[i].size() / ((float)m_sumPerPixel));
		for (int j = 0; j < numPixs; j++) {
			gpuv.UV = D3DXVECTOR4((float)((j % m_pixelPerRow)*m_sumPerPixel), (float)(j / m_pixelPerRow) + curRow, (float)(i % cmTexW),(float)(i/cmTexW));
			gpgpuVertices.push_back(gpuv);
		}
		curRow+=numRows;
	}
	m_computeApqBarNum = (int)(gpgpuVertices.size() - m_computeApqBarStart);
	m_computeApqBarVP.Width = 7*cmTexW;
	m_computeApqBarVP.Height = cmTexH;
	m_computeApqBarVP.MinDepth = 0.0f;
	m_computeApqBarVP.MaxDepth = 1.0f;
	m_computeApqBarVP.TopLeftX = 0;
	m_computeApqBarVP.TopLeftY = 0;

	// Deal with computing Transformation
	m_computeTransformStart = (int)(gpgpuVertices.size());
	m_allBetas = new float[m_totalNumClusters];
	for (int i = 0; i < m_totalNumClusters; i++) {
		gpuv.Pos = D3DXVECTOR4((float)((i % cmTexW)*7), (float)(i / cmTexW), 0.0f,1.0f) + D3DXVECTOR4(0.5f, 0.5f, 0.0f, 0.0f);  
		gpuv.Pos.x *= twoInv7S;
		gpuv.Pos.y *= twoInvcmTexH;
		gpuv.Pos -= D3DXVECTOR4(1.0f, 1.0f, 0.0f,0);
		gpuv.Pos.y *= -1.0f;
		gpuv.Pos.w = (float)i;
		gpuv.UV = D3DXVECTOR4((float)((i % cmTexW)*7), (float)(i / cmTexW), (float)((i % cmTexW)*12), (float)(i / cmTexW)); // Start fetch position for ApqTex and AqqTex
		gpgpuVertices.push_back(gpuv);
		m_allBetas[i] = betas[m_clustersToObjects[i]];
	}	
	m_deformableBodyEffect->m_pbetas->SetFloatArray(m_allBetas, 0, m_totalNumClusters);

	m_computeTransformNum = (int)(gpgpuVertices.size() - m_computeTransformStart);
	m_computeTransformVP.Width = 7*cmTexW;
	m_computeTransformVP.Height = cmTexH;
	m_computeTransformVP.MinDepth = 0.0f;
	m_computeTransformVP.MaxDepth = 1.0f;
	m_computeTransformVP.TopLeftX = 0;
	m_computeTransformVP.TopLeftY = 0;

	// Deal with computing goal position of control points in each cluster
	m_computeClusterGoalPositionStart = (int)(gpgpuVertices.size());

	curRow = 0;
	for (int i = 0; i < m_totalNumClusters; i++) {
		UINT numRows = (UINT)ceil((float)m_clusters[i].size() / ((float)xAdrTexW));
		// A quad per cluster for now, can be optimized
		// to a quad + a line for potentially smaller # of fragments
		// Pass in a point, GS will convert it to a quad
		// Position store 2 corners of the rectangle representing the cluster
		gpuv.Pos = D3DXVECTOR4(-1.0f,  -((curRow*2.0f / ((float)xAdrTexH)) - 1.0f), 1.0f, -(((curRow+numRows)*2.0f / ((float)xAdrTexH)) - 1.0f));

		// Texture coordinate stores the xy--position to fetch CM and transform (after multiplied by 7) (integer) and zw--min and max y to sample q bar (in floating point 0..1) coord
		
		gpuv.UV = D3DXVECTOR4((float)(i % cmTexW), (float)(i / cmTexW), (curRow-0.5f),((curRow+numRows)-0.5f)); 
		//gpuv.UV = D3DXVECTOR4((m_totalNumClusters-1-i) % cmTexW, (m_totalNumClusters-1-i) / cmTexW,  xAdrTexH-1-(curRow-0.5f), xAdrTexH-1-((curRow+numRows)-0.5f)); 
		gpgpuVertices.push_back(gpuv);
		curRow += numRows;
	}

	m_computeClusterGoalPositionNum = (int)(gpgpuVertices.size() - m_computeClusterGoalPositionStart);
	m_computeClusterGoalPositionVP.Width = xAdrTexW;
	m_computeClusterGoalPositionVP.Height = xAdrTexH;
	m_computeClusterGoalPositionVP.MinDepth = 0.0f;
	m_computeClusterGoalPositionVP.MaxDepth = 1.0f;
	m_computeClusterGoalPositionVP.TopLeftX = 0;
	m_computeClusterGoalPositionVP.TopLeftY = 0;

	// Deal with computing goal position of control points (by averaging from goal position of the control points from all the clusters that influence them)
	m_computeGoalPosStart = (int)(gpgpuVertices.size());
	m_computeGoalPosNum = (int)computeGoalVertices.size();
	for (size_t i = 0; i < computeGoalVertices.size(); i++) {
		gpgpuVertices.push_back(computeGoalVertices[i]);
	}

	m_computeGoalPosVP.Width = xTexW;
	m_computeGoalPosVP.Height = xTexH;
	m_computeGoalPosVP.MinDepth = 0.0f;
	m_computeGoalPosVP.MaxDepth = 1.0f;
	m_computeGoalPosVP.TopLeftX = 0;
	m_computeGoalPosVP.TopLeftY = 0;

	// Deal with updating position and velocity
	m_updateVelAndPosStart = (int)gpgpuVertices.size();
	gpuv.Pos = D3DXVECTOR4(-1.0f,-1.0f,0,1);
	gpuv.UV = D3DXVECTOR4(-0.5f,xTexH-0.5f,0.0f,0.0f);
	gpgpuVertices.push_back(gpuv);
	gpuv.Pos = D3DXVECTOR4(-1.0f,1.0f,0,1);
	gpuv.UV = D3DXVECTOR4(-0.5f,-0.5f,0.0f,0.0f);
	gpgpuVertices.push_back(gpuv);
	gpuv.Pos = D3DXVECTOR4(1.0f,-1.0f,0,1);
	gpuv.UV = D3DXVECTOR4(xTexW-0.5f,xTexH-0.5f,0.0f,0.0f);
	gpgpuVertices.push_back(gpuv);
	gpuv.Pos = D3DXVECTOR4(1.0f,1.0f,0,1);
	gpuv.UV = D3DXVECTOR4(xTexW-0.5f,-0.5f,0.0f,0.0f);
	gpgpuVertices.push_back(gpuv);

	m_updateVelAndPosVP.Width = xTexW;
	m_updateVelAndPosVP.Height = xTexH;
	m_updateVelAndPosVP.MinDepth = 0.0f;
	m_updateVelAndPosVP.MaxDepth = 1.0f;
	m_updateVelAndPosVP.TopLeftX = 0;
	m_updateVelAndPosVP.TopLeftY = 0;

	// Deal with computing the position of the surface mesh' vertices
	m_computeRealPosStart = (int)gpgpuVertices.size();
	gpuv.Pos = D3DXVECTOR4(-1.0f,-1.0f,0,1);
	gpuv.UV = D3DXVECTOR4(-0.5f,posTexH-0.5f,0.0f,0.0f);
	gpgpuVertices.push_back(gpuv);
	gpuv.Pos = D3DXVECTOR4(-1.0f,1.0f,0,1);
	gpuv.UV = D3DXVECTOR4(-0.5f,-0.5f,0.0f,0.0f);
	gpgpuVertices.push_back(gpuv);
	gpuv.Pos = D3DXVECTOR4(1.0f,-1.0f,0,1);
	gpuv.UV = D3DXVECTOR4(posTexW-0.5f,posTexH-0.5f,0.0f,0.0f);
	gpgpuVertices.push_back(gpuv);
	gpuv.Pos = D3DXVECTOR4(1.0f,1.0f,0,1);
	gpuv.UV = D3DXVECTOR4(posTexW-0.5f,-0.5f,0.0f,0.0f);
	gpgpuVertices.push_back(gpuv);

	m_computeRealPosVP.Width = posTexW;
	m_computeRealPosVP.Height = posTexH;
	m_computeRealPosVP.MinDepth = 0.0f;
	m_computeRealPosVP.MaxDepth = 1.0f;
	m_computeRealPosVP.TopLeftX = 0;
	m_computeRealPosVP.TopLeftY = 0;

	// Deal with computing normal of the surface mesh' vertices
	m_computeNormalVP.Width = posTexW;
	m_computeNormalVP.Height = posTexH;
	m_computeNormalVP.MinDepth = 0.0f;
	m_computeNormalVP.MaxDepth = 1.0f;
	m_computeNormalVP.TopLeftX = 0;
	m_computeNormalVP.TopLeftY = 0;

	// Deal with pass compute collision force	
	m_computeCollisionForceVP.Width = xAdrTexW;
	m_computeCollisionForceVP.Height = xAdrTexH;
	m_computeCollisionForceVP.MinDepth = 0.0f;
	m_computeCollisionForceVP.MaxDepth = 1.0f;
	m_computeCollisionForceVP.TopLeftX = 0;
	m_computeCollisionForceVP.TopLeftY = 0;

	// Deal with computing pVal
	m_computePValVP.Width = xAdrTexW;
	m_computePValVP.Height = xAdrTexH;
	m_computePValVP.MinDepth = 0.0f;
	m_computePValVP.MaxDepth = 1.0f;
	m_computePValVP.TopLeftX = 0;
	m_computePValVP.TopLeftY = 0;

	m_computePValStart = (int)gpgpuVertices.size();
	curRow = 0;
	for (int i = 0; i < m_totalNumClusters; i++) {
		// A quad to cover all texels that belong to the cluster
		UINT numRows = (UINT)ceil((float)m_clusters[i].size() / ((float)xAdrTexW));
		float x1 = -1.0f, 
			  y1 = -((curRow*2.0f / ((float)xAdrTexH)) - 1.0f), 
			  x2 = 1.0f, 
			  y2 = -(((curRow+numRows)*2.0f / ((float)xAdrTexH)) - 1.0f);

		// First tri
		gpuv.UV = D3DXVECTOR4((float)(i % cmTexW), (float)(i / cmTexW), 0.0f, 0.0f);

		gpuv.Pos = D3DXVECTOR4(x1, y1, 0.0f, 1.0f);
		gpgpuVertices.push_back(gpuv);
		
		gpuv.Pos = D3DXVECTOR4(x1, y2, 0.0f, 1.0f);
		gpgpuVertices.push_back(gpuv);

		gpuv.Pos = D3DXVECTOR4(x2, y1, 0.0f, 1.0f);
		gpgpuVertices.push_back(gpuv);

		// Second tri

		gpuv.Pos = D3DXVECTOR4(x1, y2, 0.0f, 1.0f);
		gpgpuVertices.push_back(gpuv);

		gpuv.Pos = D3DXVECTOR4(x2, y2, 0.0f, 1.0f);
		gpgpuVertices.push_back(gpuv);

		gpuv.Pos = D3DXVECTOR4(x2, y1, 0.0f, 1.0f);
		gpgpuVertices.push_back(gpuv);

		curRow += numRows;
	}
	m_computePValNum = (int)(gpgpuVertices.size() - m_computePValStart);

	m_gpgpuVB = new CVertexBuffer<GPGPUVertex>(&gpgpuVertices[0], (UINT)gpgpuVertices.size(), pd3dDevice);

	// Create stream out buffer for potentially colliding pair computation	

	// Creat the potential colliding pairs vertex buffer
	vector<PCPVertex> pcpVertices;
	PCPVertex pcpv;
	for (int i = 0; i < m_totalNumClusters; i++) {
		for (int j = i+1; j < m_totalNumClusters; j++) {
			if (m_clustersToObjects[i] != m_clustersToObjects[j]) {
				pcpv.i = (DWORD)i;
				pcpv.j = (DWORD)j;
				pcpVertices.push_back(pcpv);
			}
		}
	}
	m_potentialCollidingPairsVB = new CVertexBuffer<PCPVertex>(&pcpVertices[0], (UINT)pcpVertices.size(), pd3dDevice, D3D10_BIND_VERTEX_BUFFER );
	D3D10_BUFFER_DESC collidingPairBufferDesc =
	{
		(UINT)(pcpVertices.size()*sizeof(PCPVertex)*2),
		D3D10_USAGE_DEFAULT,
		D3D10_BIND_STREAM_OUTPUT | D3D10_BIND_VERTEX_BUFFER,
		0,
		0
	};

	pd3dDevice->CreateBuffer( &collidingPairBufferDesc, NULL, &m_collidingPairsBuffer );

	D3D10_BUFFER_DESC debugBufferDesc =
	{
		(UINT)(pcpVertices.size()*sizeof(PCPVertex)*2),
		D3D10_USAGE_STAGING ,
		0,
		D3D10_CPU_ACCESS_READ ,
		0
	};
	pd3dDevice->CreateBuffer( &debugBufferDesc, NULL, &m_debugBuffer );

	D3D10_BUFFER_DESC pickBufferDesc =
	{
		m_totalNumControls*sizeof(PCPVertex),
		D3D10_USAGE_DEFAULT,
		D3D10_BIND_STREAM_OUTPUT | D3D10_BIND_VERTEX_BUFFER,
		0,
		0
	};
	pd3dDevice->CreateBuffer( &pickBufferDesc, NULL, &m_pickedVerticesBuffer );

	// Create quads for each m_clusters
	D3DXVECTOR4* clustersQuads = new D3DXVECTOR4[m_totalNumClusters];
	curRow = 0;
	for (int i = 0; i < m_totalNumClusters; i++) {
		UINT numRows = (UINT)ceil((float)(m_clusters[i].size()) / ((float)xAdrTexW));
		clustersQuads[i] = D3DXVECTOR4(-1.0f, 1.0f-2.0f*curRow/((float)(xAdrTexH)),
									  1.0f, 1.0f-2.0f*(curRow+numRows)/((float)(xAdrTexH)));
		curRow += numRows;
	}
	m_deformableBodyEffect->m_pclustersQuads->SetFloatVectorArray((float*)clustersQuads,0, m_totalNumClusters);

	// Deal with pass cpf 
	m_computePickingForceVP.Width = xTexW;
	m_computePickingForceVP.Height = xTexH;
	m_computePickingForceVP.MinDepth = 0.0f;
	m_computePickingForceVP.MaxDepth = 1.0f;
	m_computePickingForceVP.TopLeftX = 0;
	m_computePickingForceVP.TopLeftY = 0;
	
	delete [] clustersQuads;
	delete [] numAffected;	

	// Setup the shift and and variables
	m_deformableBodyEffect->m_shift_xTexW->SetInt(ShiftAmount(xTexW));
	m_deformableBodyEffect->m_and_xTexW->SetInt(xTexW-1);
	m_deformableBodyEffect->m_shift_xAdrTexW->SetInt(ShiftAmount(xAdrTexW));
	m_deformableBodyEffect->m_and_xAdrTexW->SetInt(xAdrTexW-1);
	m_deformableBodyEffect->m_shift_posTexW->SetInt(ShiftAmount(posTexW));
	m_deformableBodyEffect->m_and_posTexW->SetInt(posTexW-1);
	m_deformableBodyEffect->m_shift_cmTexW->SetInt(ShiftAmount(cmTexW));
	m_deformableBodyEffect->m_and_cmTexW->SetInt(cmTexW-1);
	


}
CDeformableObjects::~CDeformableObjects() {
	delete m_objIDTex;
	delete [] m_allBetas;
	delete m_potentialCollidingPairsVB;
	delete [] heightData;
	for (DWORD i = 0; i < m_numCubeMapRenderBatchs; i++) {
		delete m_clustersControlFacesIndexBuffer[i];
		SAFE_RELEASE(m_clustersControlFacesRenderTargetIDBuffer[i]);
		SAFE_RELEASE(m_clustersControlFacesRenderTargetIDBufferRV[i]);
		SAFE_RELEASE(m_idToxValTexMappingBuffer[i]);
		SAFE_RELEASE(m_idToxValTexMappingBufferRV[i]);
	}   
	delete [] m_clustersControlFacesIndexBuffer;
	delete [] m_clustersControlFacesRenderTargetIDBuffer;
	delete [] m_clustersControlFacesRenderTargetIDBufferRV;
	delete [] m_idToxValTexMappingBuffer;
	delete [] m_idToxValTexMappingBufferRV;

	delete m_cube2DTex;
	delete m_cubeMapAtlasTex;
	delete m_forceTex;
	delete m_forceValTex;
	SAFE_RELEASE(m_collidingPairsBuffer);
	SAFE_RELEASE(m_debugBuffer);
	SAFE_RELEASE(m_pickedVerticesBuffer);

	delete m_heightNormalMapTex;
	delete m_gpgpuVB;


	delete m_deformableBodyEffect;
	delete [] m_masses;
	delete [] m_controlPos;
	delete m_xTildaTex;
	delete m_aTildaTex;
	delete m_xTex[0];
	delete m_xTex[1];
	delete m_vTex[0];
	delete m_vTex[1];
	delete m_xAdrTex;
	delete m_xValTex;
	delete m_pValTex;

	delete m_minsTex;
	delete m_nmaxsTex;
	delete m_cmTex;
	delete m_qBarTex;
	delete m_ApqBarTex;
	delete m_AqqBarTex;
	delete m_transformTex;
	delete m_gValTex;
	delete m_gTex;
	delete m_gAdrTex;
	SAFE_DELETE(m_debugTex);
	SAFE_DELETE(m_debugTex2);
	delete m_posAdrTex;
	delete m_posWeightTex;
	delete m_posTex;
	delete m_normalTex;
	for (DWORD i = 0; i < m_defObjects.size(); i++) {
		delete m_defObjects[i].m_objIB;
		delete m_defObjects[i].m_uvBuffer;
		delete m_defObjects[i].m_uvIndexBuffer;
		
		SAFE_RELEASE(m_defObjects[i].m_pTexture);
		SAFE_RELEASE(m_defObjects[i].m_pTextureRV);
	}
	delete m_white;

}



