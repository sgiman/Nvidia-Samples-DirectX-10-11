//----------------------------------------------------------------------------------
// File:   Buffers.h
// Author: Nuttapong Chentanez
// Email:  sdkfeedback@nvidia.com
//
// Deformable Physics is based on Meshless Deformations Based on Shape Matching by M. Mueller, B. Heidelberger, M. Teschner, M. Gross.
// Collision detection and response is done with cube map look up.
// All run-time computation is done on the GPU.
// 
// Copyright (c) 2007 NVIDIA Corporation. All rights reserved.
//
// TO  THE MAXIMUM  EXTENT PERMITTED  BY APPLICABLE  LAW, THIS SOFTWARE  IS PROVIDED
// *AS IS*  AND NVIDIA AND  ITS SUPPLIERS DISCLAIM  ALL WARRANTIES,  EITHER  EXPRESS
// OR IMPLIED, INCLUDING, BUT NOT LIMITED  TO, IMPLIED WARRANTIES OF MERCHANTABILITY
// AND FITNESS FOR A PARTICULAR PURPOSE.  IN NO EVENT SHALL  NVIDIA OR ITS SUPPLIERS
// BE  LIABLE  FOR  ANY  SPECIAL,  INCIDENTAL,  INDIRECT,  OR  CONSEQUENTIAL DAMAGES
// WHATSOEVER (INCLUDING, WITHOUT LIMITATION,  DAMAGES FOR LOSS OF BUSINESS PROFITS,
// BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION, OR ANY OTHER PECUNIARY LOSS)
// ARISING OUT OF THE  USE OF OR INABILITY  TO USE THIS SOFTWARE, EVEN IF NVIDIA HAS
// BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
//

#ifndef __BUFFERS_H__
#define __BUFFERS_H__
#pragma warning(disable:4127)
#include "DXUT.h"
#include "DXUTmisc.h"


template <class T>
//--------------------------------------------------------------------------------------------------------------------------
//
// Wrapper class for vertex buffer
//
//--------------------------------------------------------------------------------------------------------------------------
class CVertexBuffer{
public:
	UINT						m_offset;			// Offset from the beginning of the buffer where the data starts, typically 0
	UINT						m_stride;			// Stride
	ID3D10Buffer			   *m_pVertexBuffer;	// Pointer to the vertex buffer
	UINT				 		m_numVertices;		// Number of vertices
	ID3D10ShaderResourceView   *m_pResourceView;	// Resource view

	CVertexBuffer(T* vertices, UINT numVertices, ID3D10Device* pd3dDevice, D3D10_BIND_FLAG bindFlag = D3D10_BIND_VERTEX_BUFFER) {
		// Number of vertices		
		m_numVertices = numVertices;

		// Fill the buffer descriptions
	    D3D10_BUFFER_DESC bd;
		bd.Usage = D3D10_USAGE_DEFAULT;
		bd.ByteWidth = sizeof( T ) * numVertices;
		bd.BindFlags = bindFlag;
		bd.CPUAccessFlags = 0;
		bd.MiscFlags = 0;

		// Set the initial data structure
		D3D10_SUBRESOURCE_DATA InitData;
		InitData.pSysMem = vertices;
		HRESULT hr;

		// Create the buffer
		V(pd3dDevice->CreateBuffer( &bd, &InitData, &m_pVertexBuffer ) != S_OK);

		// Set vertex buffer
		m_stride = sizeof( T );
		m_offset = 0;
		m_pResourceView = NULL;

		// Check if this buffer will be used as a shader resource or not
		if (bindFlag & D3D10_BIND_SHADER_RESOURCE) {
			D3D10_SHADER_RESOURCE_VIEW_DESC SRVDesc;
			ZeroMemory( &SRVDesc, sizeof(SRVDesc) );

			// Choose the format according to the size of vertex
			if (sizeof(T) == 4) {
				SRVDesc.Format = DXGI_FORMAT_R32_FLOAT;
			} else if (sizeof(T) == 8) {
				SRVDesc.Format = DXGI_FORMAT_R32G32_FLOAT;
			} else if (sizeof(T) == 12) {
				SRVDesc.Format = DXGI_FORMAT_R32G32B32_FLOAT;
			} else if (sizeof(T) == 16) {
				SRVDesc.Format = DXGI_FORMAT_R32G32B32A32_FLOAT;
			}
			SRVDesc.ViewDimension =  D3D10_SRV_DIMENSION_BUFFER;
			SRVDesc.Buffer.ElementOffset = 0;
			SRVDesc.Buffer.ElementWidth = m_numVertices;
		
			// Create the resource view
			V(pd3dDevice->CreateShaderResourceView( m_pVertexBuffer , &SRVDesc, &m_pResourceView ));	

		}
	}
	~CVertexBuffer() {
		SAFE_RELEASE( m_pVertexBuffer );
		SAFE_RELEASE( m_pResourceView );
	}
};


//--------------------------------------------------------------------------------------------------------------------------
//
// Wrapper class for index buffer
//
//--------------------------------------------------------------------------------------------------------------------------
template <class T>
class CIndexBuffer{
public:
	ID3D10Buffer				*m_pIndexBuffer;	// Index buffer
	UINT						 m_numIndices;		// Number of indices
	ID3D10ShaderResourceView	*m_pResourceView;	// Resource view, in case we bind it as a buffer

	CIndexBuffer(T* indices, UINT numIndices, ID3D10Device* pd3dDevice, D3D10_BIND_FLAG bindFlag = D3D10_BIND_INDEX_BUFFER) {
		// Initialize the resource view to NULL
		m_pResourceView = NULL;

		// Store the number of indices
		m_numIndices = numIndices;

		// Fill the description
		D3D10_BUFFER_DESC bd;		
		bd.Usage = D3D10_USAGE_DEFAULT;
		bd.ByteWidth = sizeof( T ) * m_numIndices;
		bd.BindFlags = bindFlag;
		bd.CPUAccessFlags = 0;
		bd.MiscFlags = 0;

		// Setup the initial data
		D3D10_SUBRESOURCE_DATA InitData;
		InitData.pSysMem = indices;
		HRESULT hr;
		V(pd3dDevice->CreateBuffer( &bd, &InitData, &m_pIndexBuffer )  != S_OK);
		m_pResourceView = NULL;

		// Check if we need to create a shader resource view or not
		if (bindFlag & D3D10_BIND_SHADER_RESOURCE) {
			D3D10_SHADER_RESOURCE_VIEW_DESC SRVDesc;
			ZeroMemory( &SRVDesc, sizeof(SRVDesc) );

			// Choose the appropriate format based on the size of T
			if (sizeof(T) == 4) {
				SRVDesc.Format = DXGI_FORMAT_R32_UINT;
			} else if (sizeof(T) == 2) {
				SRVDesc.Format = DXGI_FORMAT_R16_UINT;
			}
			SRVDesc.ViewDimension =  D3D10_SRV_DIMENSION_BUFFER;
			SRVDesc.Buffer.ElementOffset = 0;
			SRVDesc.Buffer.ElementWidth = m_numIndices;
		
			V(pd3dDevice->CreateShaderResourceView( m_pIndexBuffer , &SRVDesc, &m_pResourceView ));	

		}
	}
	~CIndexBuffer() {
		SAFE_RELEASE( m_pIndexBuffer );
		SAFE_RELEASE( m_pResourceView );
	}

};



#endif