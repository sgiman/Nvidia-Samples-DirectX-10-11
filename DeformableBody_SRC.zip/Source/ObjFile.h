//----------------------------------------------------------------------------------
// File:   ObjFile.h
// Author: Nuttapong Chentanez
// Email:  sdkfeedback@nvidia.com
//
// Deformable Physics is based on Meshless Deformations Based on Shape Matching by M. Mueller, B. Heidelberger, M. Teschner, M. Gross.
// Collision detection and response is done with cube map look up.
// All run-time computation is done on the GPU.
// 
// Copyright (c) 2007 NVIDIA Corporation. All rights reserved.
//
// TO  THE MAXIMUM  EXTENT PERMITTED  BY APPLICABLE  LAW, THIS SOFTWARE  IS PROVIDED
// *AS IS*  AND NVIDIA AND  ITS SUPPLIERS DISCLAIM  ALL WARRANTIES,  EITHER  EXPRESS
// OR IMPLIED, INCLUDING, BUT NOT LIMITED  TO, IMPLIED WARRANTIES OF MERCHANTABILITY
// AND FITNESS FOR A PARTICULAR PURPOSE.  IN NO EVENT SHALL  NVIDIA OR ITS SUPPLIERS
// BE  LIABLE  FOR  ANY  SPECIAL,  INCIDENTAL,  INDIRECT,  OR  CONSEQUENTIAL DAMAGES
// WHATSOEVER (INCLUDING, WITHOUT LIMITATION,  DAMAGES FOR LOSS OF BUSINESS PROFITS,
// BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION, OR ANY OTHER PECUNIARY LOSS)
// ARISING OUT OF THE  USE OF OR INABILITY  TO USE THIS SOFTWARE, EVEN IF NVIDIA HAS
// BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
//

#ifndef __OBJFILE_H__
#define __OBJFILE_H__

#pragma warning(disable: 4995)

#include "DXUT.h"
#include <fstream>
#include <string>
#include "textures.h"
#include <vector>
#include <sstream>
#include <map>
using namespace std;

//--------------------------------------------------------------------------------------------------------------------------
//	Class for loading the OBJ file, 
//	Limitted support, many settings are ignored
//  Designed to load Maya's OBJ exporter output with no normal (because normal is computed in GPU)
//  Support a single material.
//  Store indices for position and texture coordinates seperately
//--------------------------------------------------------------------------------------------------------------------------

class CObjFile{
public:
	// Member functions
	CObjFile(LPCWSTR fileName, ID3D10Device* pd3dDevice);
	~CObjFile();

	void OutToSurf(string& name);
	void LoadMaterial(string& name, ID3D10Device* pd3dDevice);

	// Member variables
	ID3D10Texture2D				*m_pTexture;			// Texture
	ID3D10ShaderResourceView	*m_pTextureRV;			// Resource View for the texture	
	vector<D3DXVECTOR3>			 m_position;			// Vertices' positions
	vector<D3DXVECTOR2>			 m_texCoord;			// Vertices' texture coordinates
	vector<DWORD>				 m_positionIndices;		// Position indices for the triangles
	vector<DWORD>				 m_texCoordIndices;		// Texture coordinate indices for the triangles
};
#endif