//----------------------------------------------------------------------------------
// File:   KDTree.h
// Author: Nuttapong Chentanez
// Email:  sdkfeedback@nvidia.com
//
// Deformable Physics is based on Meshless Deformations Based on Shape Matching by M. Mueller, B. Heidelberger, M. Teschner, M. Gross.
// Collision detection and response is done with cube map look up.
// All run-time computation is done on the GPU.
// 
// Copyright (c) 2007 NVIDIA Corporation. All rights reserved.
//
// TO  THE MAXIMUM  EXTENT PERMITTED  BY APPLICABLE  LAW, THIS SOFTWARE  IS PROVIDED
// *AS IS*  AND NVIDIA AND  ITS SUPPLIERS DISCLAIM  ALL WARRANTIES,  EITHER  EXPRESS
// OR IMPLIED, INCLUDING, BUT NOT LIMITED  TO, IMPLIED WARRANTIES OF MERCHANTABILITY
// AND FITNESS FOR A PARTICULAR PURPOSE.  IN NO EVENT SHALL  NVIDIA OR ITS SUPPLIERS
// BE  LIABLE  FOR  ANY  SPECIAL,  INCIDENTAL,  INDIRECT,  OR  CONSEQUENTIAL DAMAGES
// WHATSOEVER (INCLUDING, WITHOUT LIMITATION,  DAMAGES FOR LOSS OF BUSINESS PROFITS,
// BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION, OR ANY OTHER PECUNIARY LOSS)
// ARISING OUT OF THE  USE OF OR INABILITY  TO USE THIS SOFTWARE, EVEN IF NVIDIA HAS
// BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
//

//--------------------------------------------------------------------------------------------------------------------------
//      READ THIS FIRST
// See the "READ THIS FIRST" section in the deformableObjects.h
//--------------------------------------------------------------------------------------------------------------------------
#ifndef __KD_TREE_H__
#define __KD_TREE_H__

#include "DXUT.h"
#include "DXUTgui.h"
#include "deformableObjects.h"

#pragma warning(disable: 4995)
#include <vector>

class CKDNode;

#define MAX_DEPTH 8
#define CUT_OFF 4

//--------------------------------------------------------------------------------------------------------------------------
//
//	KD Tree for accelerating the computation of finding what surface vertices lie in a given control mesh's tetrahedron 
//
//--------------------------------------------------------------------------------------------------------------------------
class CKDTree{

public:
	// Member functions
	CKDTree(D3DXVECTOR3* points, DWORD numPts);  // Constructor just take the list of points and put them in tree
	~CKDTree();

	void PointsInTet(D3DXVECTOR3& t0, D3DXVECTOR3& t1, D3DXVECTOR3& t2, D3DXVECTOR3& t3, vector<DWORD>& points, vector<D3DXVECTOR4>& barys);

private:

	// Partition the list of points, by pushing vertices whose a coordinate is less than mean to the left and the remaining to the right
	void Partition(vector<DWORD>& ids, vector<DWORD>& left, vector<DWORD>& right, int depth, unsigned char& axis, float& value);

	// Inverse the 3x3 matrix
	inline void Inverse3x3(float* in, float* out);

	// Build the KD tree's subtree
	void BuildTree(CKDNode*& ptr, vector<DWORD>& ids, int depth);

	// Helper function for exploring node
	void FindPoints(CKDNode*& ptr);
	

	// Member variables 
	D3DXVECTOR3					*m_nodes;		// Array of the position of the surface vertices
	CKDNode						*m_root;		// The root of the KD tree

	// Storage for storing the information about the surface vertices that lie in the given tetrahedron
	vector<DWORD>				*m_pPoints;		// The indices of the points
	vector<D3DXVECTOR4>			*m_pBarys;		// Barycentric coordinates of the points

	// Information about the current tetrahedral in consideration
	D3DXVECTOR3					 m_origin;		// Origin of the tetrahedron
	float						 m_baryMat[9];	// A barycentric matrix to map the world space to bary centric coordinate of tetrahedron
	D3DXVECTOR3					 m_mins;
	D3DXVECTOR3					 m_maxs;		// Mins and Maxs along axis of the tetrahedrons


};

//--------------------------------------------------------------------------------------------------------------------------
//
//  KD Tree node class for storing KD Tree' nodes
//
//--------------------------------------------------------------------------------------------------------------------------
class CKDNode{
public:
	// Member Functions
	~CKDNode();				 	// Just destructor
	
	bool						 m_leaf;		// Whether this is a leaf or not
	unsigned char				 m_axis;		// Axis
	float						 m_value;		// Mean value to partition
	union {
		DWORD					*m_ids;			// ID of the vertices stored in the leaf
		CKDNode				    *m_left;		// Left sub tree
	};
	union {
		DWORD					 m_numNodes;	// Number of vertices stored in the leaf
		CKDNode					*m_right;		// Right sub tree
	};
};

#endif