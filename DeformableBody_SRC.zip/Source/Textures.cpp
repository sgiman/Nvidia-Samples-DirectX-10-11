//----------------------------------------------------------------------------------
// File:   Textures.cpp
// Author: Nuttapong Chentanez
// Email:  sdkfeedback@nvidia.com
//
// Deformable Physics is based on Meshless Deformations Based on Shape Matching by M. Mueller, B. Heidelberger, M. Teschner, M. Gross.
// Collision detection and response is done with cube map look up.
// All run-time computation is done on the GPU.
// 
// Copyright (c) 2007 NVIDIA Corporation. All rights reserved.
//
// TO  THE MAXIMUM  EXTENT PERMITTED  BY APPLICABLE  LAW, THIS SOFTWARE  IS PROVIDED
// *AS IS*  AND NVIDIA AND  ITS SUPPLIERS DISCLAIM  ALL WARRANTIES,  EITHER  EXPRESS
// OR IMPLIED, INCLUDING, BUT NOT LIMITED  TO, IMPLIED WARRANTIES OF MERCHANTABILITY
// AND FITNESS FOR A PARTICULAR PURPOSE.  IN NO EVENT SHALL  NVIDIA OR ITS SUPPLIERS
// BE  LIABLE  FOR  ANY  SPECIAL,  INCIDENTAL,  INDIRECT,  OR  CONSEQUENTIAL DAMAGES
// WHATSOEVER (INCLUDING, WITHOUT LIMITATION,  DAMAGES FOR LOSS OF BUSINESS PROFITS,
// BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION, OR ANY OTHER PECUNIARY LOSS)
// ARISING OUT OF THE  USE OF OR INABILITY  TO USE THIS SOFTWARE, EVEN IF NVIDIA HAS
// BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
//

//--------------------------------------------------------------------------------------------------------------------------
//      READ THIS FIRST
// See the "READ THIS FIRST" section in the deformableObjects.h
//--------------------------------------------------------------------------------------------------------------------------
#include "DXUT.h"
#include "textures.h"

static HRESULT hr;

CTexture2D::CTexture2D(LPCWSTR fileName, ID3D10Device* pd3dDevice, D3DX10_IMAGE_LOAD_INFO* loadInfo) {
	// Initialize pointers to NULL
	m_pRes = NULL;
	m_pTexture = NULL;
	m_pTextureRV = NULL;
	m_pRTV = NULL;
	m_createRTV = false;   

	// Create the texture from a file
	V(D3DX10CreateTextureFromFile( pd3dDevice, fileName, loadInfo, NULL, &m_pRes, &hr ));

	// Query the texture interface
	V(m_pRes->QueryInterface( __uuidof( ID3D10Texture2D ), (LPVOID*)&m_pTexture ));
	
	// Release the resource
	SAFE_RELEASE(m_pRes);

	// Obtain the description and create the shader resource view
	D3D10_TEXTURE2D_DESC desc;
	m_pTexture->GetDesc( &desc );
	if ((!loadInfo) || ((loadInfo) && (loadInfo->BindFlags & D3D10_BIND_SHADER_RESOURCE))) {

		D3D10_SHADER_RESOURCE_VIEW_DESC SRVDesc;
		ZeroMemory( &SRVDesc, sizeof(SRVDesc) );
		SRVDesc.Format = desc.Format;
		SRVDesc.ViewDimension = D3D10_SRV_DIMENSION_TEXTURE2D;
		SRVDesc.Texture2D.MipLevels = desc.MipLevels;
		V(pd3dDevice->CreateShaderResourceView( m_pTexture, &SRVDesc, &m_pTextureRV ));	
	}

	// Cache the width and height
	m_width = desc.Width;
	m_height = desc.Height;
}

CTexture2D::CTexture2D(ID3D10Device* pd3dDevice, UINT width, UINT height, float* data, DXGI_FORMAT format, D3D10_USAGE usage, D3D10_BIND_FLAG bindFlag, bool createRTV, D3D10_CPU_ACCESS_FLAG cpuAccessFlag, D3D10_RESOURCE_MISC_FLAG miscFlags, UINT arraySize, bool isTextureArray ) {
	
	// Create texture + optionally some initialization
	m_pRes = NULL;
	m_createRTV = createRTV;
	m_width = width;
	m_height = height;

	// Assume 1 mip level, start to fill the description
	const UINT MIPLEVELS = 1;
    D3D10_TEXTURE2D_DESC dstex;
    dstex.Width = width;
	dstex.Height = height;
    dstex.MipLevels = MIPLEVELS;
    dstex.ArraySize = arraySize;
    dstex.Format = format;
    dstex.Usage = usage;
    dstex.BindFlags = bindFlag;
    dstex.CPUAccessFlags = cpuAccessFlag;
    dstex.MiscFlags = miscFlags;
	dstex.SampleDesc.Count = 1;
	dstex.SampleDesc.Quality = 0;

	UINT pitch = 0;

	// Compute the pitch depending on the 
	switch (format) {
		case DXGI_FORMAT_R32_UINT: pitch = width*sizeof(unsigned int); break;
		case DXGI_FORMAT_R16G16_SINT: pitch = 2*width*sizeof(unsigned short); break;
		case DXGI_FORMAT_R16G16_UINT: pitch = 2*width*sizeof(unsigned short); break;
		case DXGI_FORMAT_R32G32B32A32_FLOAT: pitch = 4*width*sizeof(float); break;
		case DXGI_FORMAT_R32G32B32A32_UINT: pitch = 4*width*sizeof(unsigned int); break;
		case DXGI_FORMAT_R32G32_FLOAT: pitch = 2*width*sizeof(float); break;
		default: throw "Error invalid texture format.";
	};

	// Check if there is initial data or not
	if (data) {
		// If so, fill in the descriptions depending on the arraySize
		D3D10_SUBRESOURCE_DATA* srd = new D3D10_SUBRESOURCE_DATA[arraySize];
		for (DWORD i = 0; i < arraySize; i++) {
			srd[i].pSysMem = (void*)&data[pitch*height*i / sizeof(float)];
			srd[i].SysMemPitch = pitch;
			srd[i].SysMemSlicePitch = pitch*height;
		}

		pd3dDevice->CreateTexture2D(&dstex, srd, &m_pTexture);
		delete [] srd;
	} else {
		// If not, just pass in NULL pointer 
		pd3dDevice->CreateTexture2D(&dstex, NULL, &m_pTexture);
	}

	// Check if it is meant to be binded to anything
	if (dstex.BindFlags) {
		D3D10_SHADER_RESOURCE_VIEW_DESC SRVDesc;
		ZeroMemory( &SRVDesc, sizeof(SRVDesc) );

		if (miscFlags & D3D10_RESOURCE_MISC_TEXTURECUBE) {
			// Cube
			SRVDesc.Format = dstex.Format;
			SRVDesc.ViewDimension = D3D10_SRV_DIMENSION_TEXTURECUBE;
			SRVDesc.TextureCube.MipLevels = MIPLEVELS;
			SRVDesc.TextureCube.MostDetailedMip = 0;
		} else {
			// Just 2D Texture
			SRVDesc.Format = dstex.Format;

			// Check if we should treat it as array or not (because array could be of size 1)
			if (!isTextureArray) {			
				// No, this is just a texture 2D
				SRVDesc.ViewDimension = D3D10_SRV_DIMENSION_TEXTURE2D;
				SRVDesc.Texture2D.MipLevels = dstex.MipLevels;
			} else {
				// Yes, this is a a texture array
				SRVDesc.ViewDimension = D3D10_SRV_DIMENSION_TEXTURE2DARRAY;
				SRVDesc.Texture2DArray.MipLevels = dstex.MipLevels;
				SRVDesc.Texture2DArray.ArraySize = arraySize;
				SRVDesc.Texture2DArray.FirstArraySlice = 0;
				SRVDesc.Texture2DArray.MostDetailedMip = 0;
			}
		}

		// Create the resource view of the texture	
		V(pd3dDevice->CreateShaderResourceView( m_pTexture, &SRVDesc, &m_pTextureRV ));	

		// Check if we should create a rendertarget view or not
		if (createRTV) {
			
			D3D10_RENDER_TARGET_VIEW_DESC RTVDesc;
			RTVDesc.Format = dstex.Format;

			// Need to check if it's a texture array or not
			if (!isTextureArray) {				
				RTVDesc.Texture2D.MipSlice = 0;
				RTVDesc.ViewDimension = D3D10_RTV_DIMENSION_TEXTURE2D;
			} else {
				RTVDesc.ViewDimension =  D3D10_RTV_DIMENSION_TEXTURE2DARRAY;
				RTVDesc.Texture2DArray.ArraySize = arraySize;
				RTVDesc.Texture2DArray.FirstArraySlice = 0;
				RTVDesc.Texture2DArray.MipSlice = 0;
			}

			V(pd3dDevice->CreateRenderTargetView(m_pTexture, &RTVDesc, &m_pRTV));
		}
	} else {
		// If this is not for binding, eg staging texture, just set the pointers to NULL
		m_pTextureRV = NULL;
		m_pRTV = NULL;
	}
}

CTexture2D::~CTexture2D() {

	if (m_createRTV) {
		SAFE_RELEASE( m_pRTV);
	}
	SAFE_RELEASE(m_pRes);
    SAFE_RELEASE( m_pTexture );
	SAFE_RELEASE( m_pTextureRV );

}
